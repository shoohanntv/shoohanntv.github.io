<?php
include("_@configs.php");



$channelID = "";
if (isset($_REQUEST['play'])) {
    $channelID = trim($_REQUEST['play']);
}

if (!empty($channelID)) {
    $tvname = getChannelName($channelID);
    $tvplayurl = "stream.m3u8?id=" . $channelID;
?>

<head>
    <link rel="icon" href="https://bokulsports.com/upload/Sider/Picsart_24-09-07_18-04-27-652.jpg"> 
<title>bokul Sports</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="https://ssl.p.jwpcdn.com/player/v/8.26.0/jwplayer.js"></script>
<script>jwplayer.key = "XSuP4qMl+9tK17QNb+4+th2Pm9AWgMO/cYH8CI0HGGr7bdjo";</script>
<script src="https://content.jwplatform.com/libraries/IDzF9Zmk.js"></script></script>
</script>

</head>
<body>
<div id="myElement"></div>
  <script type="text/javascript">
    jwplayer("myElement").setup({
      width: '100%',
      height:'100%',
      autostart: "true",
      fullscreen: true,
      controls: true,
      pipIcon: "enabled",
      volume: "50",
      preload: "auto",
      file : "<?php print($tvplayurl); ?>",
      aspectratio: "16:9",
      stretching: "exactfit",
      aboutlink: "/#",
      logo: {"file":"Logo","margin":"15px", "position":"top-right","link":"#"},
      captions: {color: '#ffb800',fontSize: 30,backgroundOpacity: 0},
      type: "hls",
      primary: "html5",
      hlshtml: true,
    })
  </script>
</div>

<script>
setTimeout(videovisible, 3000)

function videovisible() {
    document.getElementById('loading').style.display = 'none'
}
document.addEventListener("DOMContentLoaded", () => {
    const e = document.querySelector("video"),
        n = e.getElementsByTagName("source")[0].src,
        o = {};
    if (Hls.isSupported()) {
        var config = {
            maxMaxBufferLength: 100,
        };
        const t = new Hls(config);
        t.loadSource(n), t.on(Hls.Events.MANIFEST_PARSED, function(n, l) {
            const s = t.levels.map(e => e.height);
            o.quality = {
                default: s[0],
                options: s,
                forced: !0,
                onChange: e => (function(e) {
                    window.hls.levels.forEach((n, o) => {
                        n.height === e && (window.hls.currentLevel = o)
                    })
                })(e)
            };
            new Plyr(e, o)
        }), t.attachMedia(e), window.hls = t
    } else {
        new Plyr(e, o)
    }
});
</script>
</body>
<?php
} else {
    echo "No Channel Selected.";
}
?>
