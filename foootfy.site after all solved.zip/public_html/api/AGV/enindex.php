<?php
include("_@configs.php");
?>

<!doctype html>
<html>
<head>
    <title>Home - Play | Footfy Live</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="icon" href="https://footfy.net/wp-content/uploads/2024/09/fav4.png"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <style>
        body {
            font-family: "Montserrat", sans-serif;
            background-color: black;
        }
        .card {
            color: #FFFFFF;
            border-radius:2rem .3rem ;
            background-color: #202020 !important;
            text-align: center;
            justify-content: center;
            item-align: center;
            border:2px solid black;
        }
        .card:hover {
            background-color: rgba(165, 42, 42, 0.521);
            border-color:white;
            border:2px solid white;
        }
        .card:hover .card-text {
            color:white;
        }
        .card a {
            text-decoration: none;
            color: #FFFFFF;
        }
        .tvimage {
            border-radius: 28px;
        }
        .boldbtn { font-weight: bold; }
        .prvselect { -webkit-user-select: none; -ms-user-select: none; user-select: none; }
        .toast-body { font-weight: bold; color: #067964; }
    </style>
</head>
<body>
    <nav class="navbar bg-body-dark">
        <div class="container-fluid">
            <a class="navbar-brand mt-4 mb-2 px-5">
                <img src="https://footfy.net/wp-content/uploads/2024/09/Footfy-Logo-Final.png" alt="<?php print($APP_CONFIGS['APP_NAME']); ?>" width="200"/>
            </a>
            <form class="d-flex" role="search"></form>
        </div>
    </nav>
    
    <div class="card bg-body-secondary mt-2 mb-4 px-4 pt-3 pb-3">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Footfy Live" id="inpSearchTV" autocomplete="off"/>
            <button class="btn btn-success boldbtn" type="button" id="btnInitTVSearch" title="Search Channels">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>
            <button class="btn btn-danger boldbtn" type="button" id="btnIPTVlist" title="Click To Download IPTV M3U-Playlist">
                <i class="fa-solid fa-download"></i>
            </button>
        </div>
    </div>
    
    <div class="container">
        <div align="center" class="mt-4" id="tvsGrid">
            <div style="margin-top: 150px;">
                <div class="spinner-border text-light" style="width: 3rem; height: 3rem;" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 start-50 translate-middle-x p-3"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
    $(document).ready(function(){
        loadTVlist();
    });

    $("#btnIPTVlist").on("click", function(){
        window.location = "service.php?action=m3u_playlist";
    });

    $("#btnInitTVSearch").on("click", function() {
        searchTVlist();
    });

    $("#inpSearchTV").on('keydown', function(event) {
        if (event.key === 'Enter' || event.keyCode === 13) {
            event.preventDefault();
            searchTVlist();
        }
    });

    function toaster(text) {
        $(".toast-container").html(`<div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-body">` + text + `</div></div>`);
        $(".toast").toast("show");
    }

    function loadTVlist() {
        toaster(" Welcome To Footfy Live");
        $.ajax({
            "url": "service.php",
            "type": "POST",
            "data": "action=getChannels",
            "success":function(data) {
                try { data = JSON.parse(data); } catch(err){}
                if(data.status == "success") {
                    let lmtl = '';
                    lmtl += '<div class="row mt-3">';
                    $.each(data.data.list, function(k, v) {
                        lmtl += '<div class="col-lg-2 col-md-6 col-sm-6 col-6 mb-4" data-tvid="' + v.id + '" onclick="playlivetv(this)" title="Watch ' + v.title + ' Live" id="livetvCard">';
                        lmtl += '<div class="card">';
                        lmtl += '<div class="card-body">';
                        lmtl += '<img class="card-img-top tvimage" src="assets/daddylive.png" width="160" height="100" alt=""/>';
                        lmtl += '<div class="mt-2 prvselect">';
                        lmtl += '<b>' + v.title + '</b>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                    });
                    lmtl += '</div>';
                    $("#tvsGrid").html(lmtl);
                } else {
                    toaster("Error: No Channels Found");
                    $("#tvsGrid").html('<div class="text-white" style="margin: 100px;">No Channels Found</div>');
                }
            },
            "error":function() {
                toaster("Error: Server Error or Network Failed");
                $("#tvsGrid").html('<div class="text-white" style="margin: 100px;">Server Error or Network Failed</div>');
            }
        });
    }

    function playlivetv(e) {
        let tv_id = $(e).attr("data-tvid");
        window.location = "play.php?play=" + tv_id;
    }

    function searchTVlist() {
        let orgbtnID = "btnInitTVSearch";
        let orgbtnTx = $("#" + orgbtnID).html();
        $("#" + orgbtnID).html('<span class="spinner-border spinner-border-sm" aria-hidden="true"></span>');
        let query = $("#inpSearchTV").val();
        $.ajax({
            "url": "service.php",
            "type": "POST",
            "data": "action=searchChannels&query=" + query,
            "success":function(data) {
                try { data = JSON.parse(data); } catch(err){}
                if(data.status == "success") {
                    let lmtl = '';
                    lmtl += '<div class="row mt-3">';
                    $.each(data.data.list, function(k, v) {
                        lmtl += '<div class="col-lg-2 col-md-6 col-sm-6 col-6 mb-4" data-tvid="' + v.id + '" onclick="playlivetv(this)" title="Watch ' + v.title + ' Live" id="livetvCard">';
                        lmtl += '<div class="card">';
                        lmtl += '<div class="card-body">';
                        lmtl += '<img class="card-img-top tvimage" src="assets/daddylive.png" width="160" height="90" alt=""/>';
                        lmtl += '<div class="mt-2 prvselect">';
                        lmtl += '<b>' + v.title + '</b>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                        lmtl += '</div>';
                    });
                    lmtl += '</div>';
                    $("#tvsGrid").html(lmtl);
                    toaster("Displaying Search Results - " + data.data.query);
                    $("#" + orgbtnID).html(orgbtnTx);
                } else {
                    toaster("Error: No Channels Found");
                    window.setTimeout(function(){ loadTVlist(); }, 4000);
                    $("#" + orgbtnID).html(orgbtnTx);
                }
            },
            "error":function() {
                $("#" + orgbtnID).html(orgbtnTx);
                loadTVlist();
                alert("Error: Server Error or Network Failed");
            }
        });
    }
    </script>
</body>
</html>
