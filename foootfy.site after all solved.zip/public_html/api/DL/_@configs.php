<?php

// Coded by WingyCodes

error_reporting(0);

$APP_CONFIGS['APP_NAME'] = "Daddy HD";
$APP_CONFIGS['APP_FAVICON'] = "files/logo.png";
$APP_CONFIGS['APP_LOGO'] = "files/banner.png";
$APP_CONFIGS['CHANNEL_LOGO'] = "files/tvLogo.png";
$APP_CONFIGS['API_BASE_URL'] = "https://daddylive.mp/";
$APP_CONFIGS['APP_POWEREDBY'] = "";

$APP_CONFIGS['STREAM_TOKEN_SECURITY'] = "ON"; //"ON" or "OFF"
$APP_CONFIGS['USE_ADDITIONAL_PROXY'] = "OFF"; //"ON" or "OFF"
$APP_CONFIGS['ADDITIONAL_PROXY'] = array("HOST" => "",
                                         "PORT" => "",
                                         "USERNAME" => "",
                                         "PASSWORD" => "");

// Coded by WingyCodes

//---------------------------------------------------------------------------//

$APP_CONFIGS['APP_DATA_FOLDER'] = "__AppData__";
if(!isset($APP_CONFIGS['APP_DATA_FOLDER']) || empty($APP_CONFIGS['APP_DATA_FOLDER'])){ $APP_CONFIGS['APP_DATA_FOLDER'] = "__SecureData__"; }
if(!is_dir($APP_CONFIGS['APP_DATA_FOLDER'])) { mkdir($APP_CONFIGS['APP_DATA_FOLDER']); }
if(!file_exists($APP_CONFIGS['APP_DATA_FOLDER']."/index.html")) { @file_put_contents($APP_CONFIGS['APP_DATA_FOLDER']."/index.html", ""); }
if(!file_exists($APP_CONFIGS['APP_DATA_FOLDER']."/.htaccess")) { @file_put_contents($APP_CONFIGS['APP_DATA_FOLDER']."/.htaccess", "deny from all"); }

$_SERVER['HTTP_HOST'] = strtok($_SERVER['HTTP_HOST'], ':'); $_SERVER['HTTP_HOST'] = str_ireplace('localhost', '127.0.0.1', $_SERVER['HTTP_HOST']);
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") { $streamenvproto = "https"; } elseif (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == "https") { $streamenvproto = "https"; } else { $streamenvproto = "http"; } $plhoth = ($_SERVER['SERVER_ADDR'] !== "127.0.0.1") ? $_SERVER['HTTP_HOST'] : getHostByName(php_uname('n'));
if(isset($_SERVER['HTTP_CF_VISITOR']) && !empty($_SERVER['HTTP_CF_VISITOR'])){ $htcfs = @json_decode($_SERVER['HTTP_CF_VISITOR'], true); if(isset($htcfs['scheme']) && !empty($htcfs['scheme'])){ $streamenvproto = $htcfs['scheme']; }}

//---------------------------------------------------------------------------//

function response($status, $code, $message, $data)
{
    header("Content-Type: application/json");
    $respo = array("status" => $status, "code" => $code, "message" => $message, "data" => $data);
    exit(json_encode($respo));
}

function enc_dec($action, $data)
{
    $output = ""; $ky = $iv = "q3ph6bcQ18xAuncD";
    if($action == "encrypt")
    {
        $encrypted = openssl_encrypt($data, "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
        if(!empty($encrypted)) { $output = bin2hex($encrypted); }
    }
    if($action == "decrypt")
    {
        if(strlen($data) % 2 == 0) {
            $dexBinary = hex2bin($data);
            $decrypted = openssl_decrypt($dexBinary, "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
            if(!empty($decrypted)) { $output = $decrypted; }
        }
    }
    return $output;
}

function getRootBase($url)
{
    $output = "";
    $purl = parse_url($url);
    if(isset($purl['host'])) {
        $output = $purl['scheme']."://".$purl['host'];
    }
    return $output;
}

function getRelBase($url)
{
    $output = "";
    if(stripos($url, "?") !== false) {
        $drl = explode("?", $url);
        if(isset($drl[0]) && !empty($drl[0])) {
            $url = trim($drl[0]);
        }
    }
    $output = str_replace(basename($url), "", $url);
    return $output;
}

function getRelBasedot($url)
{
    $output = "";
    if(stripos($url, "?") !== false) {
        $drl = explode("?", $url);
        if(isset($drl[0]) && !empty($drl[0])) {
            $url = trim($drl[0]);
        }
    }
    $output = str_replace(basename($url), "", $url);
    $output = str_replace(basename($output)."/", "", $output);
    return $output;
}

// Coded by WingyCodes

function getXPURI($string)
{
    $output = '';
    $pattern = '/URI="(.*?)"/';
    preg_match($pattern, $string, $matches);
    if (isset($matches[1])) {
        $output = $matches[1];
    }
    return $output;
}

function getRequest__fget($url, $headers)
{
    global $APP_CONFIGS;
    $contextOptions = array('http' => array('method'  => 'GET', 'header'  => implode("\r\n", $headers), 'ignore_errors' => true));
    $context = stream_context_create($contextOptions);
    $response = @file_get_contents($url, false, $context);
    $responseHeaders = $http_response_header;
    $httpCode = 200;
    if (isset($responseHeaders[0])) {
        preg_match('/HTTP\/\d\.\d (\d{3})/', $responseHeaders[0], $matches);
        if(isset($matches[1])) { $httpCode = intval($matches[1]); }
    }
    return array('url' => $url,'data' => $response,'code' => $httpCode);
}

function getRequest($url, $headers)
{
    global $APP_CONFIGS;
    if(empty($headers)){ $headers = array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"); }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
    if(!empty($headers)) { curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); }
    if(isset($APP_CONFIGS['USE_ADDITIONAL_PROXY']) && $APP_CONFIGS['USE_ADDITIONAL_PROXY'] == "ON")
    {
        $APP_CONFIGS['ADDITIONAL_PROXY']['CREDS'] = $APP_CONFIGS['ADDITIONAL_PROXY']['USERNAME'].":".$APP_CONFIGS['ADDITIONAL_PROXY']['PASSWORD'];
        curl_setopt($ch, CURLOPT_PROXY, $APP_CONFIGS['ADDITIONAL_PROXY']['HOST']);
        curl_setopt($ch, CURLOPT_PROXYPORT, $APP_CONFIGS['ADDITIONAL_PROXY']['PORT']);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $APP_CONFIGS['ADDITIONAL_PROXY']['CREDS']);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
    }
    $response = curl_exec($ch);
    $info = curl_getinfo($ch);
    $xerror = curl_error($ch);
    curl_close($ch);
    if(!isset($info['effective_url'])){ $info['effective_url'] = $url; }
    $result = ['data' => $response, 'error' => $xerror, 'url' => $info['effective_url'], 'code' => $info['http_code'], 'content_type' => $info['content_type'] ];
    return $result;
}

function isWebBrowser()
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $browsers = ['Chrome','Firefox','Opera','Edge','Brave','Safari','MSIE','Trident','Vivaldi','SamsungBrowser','Chromium','UCBrowser','Epic','FirefoxFocus'];
    foreach ($browsers as $browser) {
        if (strpos($userAgent, $browser) !== false) {
            return true;
        }
    }
    return false;
}

// Coded by WingyCodes

function isGETParamAttached($url)
{
    $output = false;
    if(stripos($url, "?") !== false)
    {
        $output = true;
    }
    return $output;
}

function streamTokenValidation($action, $data) 
{
    $tokenKey = "tuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY";
    if ($action == "generate")
    {
        $exptime = time() + 10800;
        $hmac = hash_hmac('sha256', $exptime . $tokenKey . $data . $_SERVER['HTTP_USER_AGENT'], $tokenKey);
        return $hmac.'-'.$exptime;
    }
    if ($action == "validate")
    {
        $token = $data['token'];
        $cid = $data['cid'];
        list($hmac, $exp) = explode('-', $token, 2);
        if (!$hmac || !$exp || !is_numeric($exp)) {
            return "ERR_INVFMT";
        }
        if (time() > (int)$exp) {
            return "ERR_EXPIRED";
        }
        $expectedHmac = hash_hmac('sha256', $exp . $tokenKey . $cid. $_SERVER['HTTP_USER_AGENT'], $tokenKey);
        if (!hash_equals($expectedHmac, $hmac)) {
            return "ERR_INVALID";
        }
        return "OK";
    }
    return "ERR_ACTION";
}

include("_@upstrm.php");

class HunterObfuscator
{
    private $code;
    private $mask;
    private $interval;
    private $option = 0;
    private $expireTime = 0;
    private $domainNames = array();

    function __construct($Code, $html = false)
    {
        if ($html) {
            $Code = $this->cleanHtml($Code);
            $this->code = $this->html2Js($Code);
        } else {
            $Code = $this->cleanJS($Code);
            $this->code = $Code;
        }

        $this->mask = $this->getMask();
        $this->interval = rand(1, 50);
        $this->option = rand(2, 8);
    }

    private function getMask()
    {
        $charset = str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
        return substr($charset, 0, 9);
    }

    private function hashIt($s)
    {
        for ($i = 0; $i < strlen($this->mask); ++$i)
            $s = str_replace("$i", $this->mask[$i], $s);
        return $s;
    }

    private function prepare()
    {
        if (count($this->domainNames) > 0) {
            $code = "if(window.location.hostname==='" . $this->domainNames[0] . "' ";
            for ($i = 1; $i < count($this->domainNames); $i++)
                $code .= "|| window.location.hostname==='" . $this->domainNames[$i] . "' ";
            $this->code = $code . "){" . $this->code . "}";
        }
        if ($this->expireTime > 0)
            $this->code = 'if((Math.round(+new Date()/1000)) < ' . $this->expireTime . '){' . $this->code . '}';
    }

    private function encodeIt()
    {
        $this->prepare();
        $str = "";
        for ($i = 0; $i < strlen($this->code); ++$i)
            $str .= $this->hashIt(base_convert(ord($this->code[$i]) + $this->interval, 10, $this->option)) . $this->mask[$this->option];
        return $str;
    }

    public function Obfuscate()
    {
		$rand = rand(0,99);
		$rand1 = rand(0,99);
        return "var _0xc{$rand}e=[\"\",\"\x73\x70\x6C\x69\x74\",\"\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7A\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5A\x2B\x2F\",\"\x73\x6C\x69\x63\x65\",\"\x69\x6E\x64\x65\x78\x4F\x66\",\"\",\"\",\"\x2E\",\"\x70\x6F\x77\",\"\x72\x65\x64\x75\x63\x65\",\"\x72\x65\x76\x65\x72\x73\x65\",\"\x30\"];function _0xe{$rand1}c(d,e,f){var g=_0xc{$rand}e[2][_0xc{$rand}e[1]](_0xc{$rand}e[0]);var h=g[_0xc{$rand}e[3]](0,e);var i=g[_0xc{$rand}e[3]](0,f);var j=d[_0xc{$rand}e[1]](_0xc{$rand}e[0])[_0xc{$rand}e[10]]()[_0xc{$rand}e[9]](function(a,b,c){if(h[_0xc{$rand}e[4]](b)!==-1)return a+=h[_0xc{$rand}e[4]](b)*(Math[_0xc{$rand}e[8]](e,c))},0);var k=_0xc{$rand}e[0];while(j>0){k=i[j%f]+k;j=(j-(j%f))/f}return k||_0xc{$rand}e[11]}eval(function(h,u,n,t,e,r){r=\"\";for(var i=0,len=h.length;i<len;i++){var s=\"\";while(h[i]!==n[e]){s+=h[i];i++}for(var j=0;j<n.length;j++)s=s.replace(new RegExp(n[j],\"g\"),j);r+=String.fromCharCode(_0xe{$rand1}c(s,e,10)-t)}return decodeURIComponent(escape(r))}(\"" . $this->encodeIt() . "\"," . rand(1, 100) . ",\"" . $this->mask . "\"," . $this->interval . "," . $this->option . "," . rand(1, 60) . "))";
    }

    public function setExpiration($expireTime)
    {
        if (strtotime($expireTime)) {
            $this->expireTime = strtotime($expireTime);
            return true;
        }
        return false;
    }

    public function addDomainName($domainName)
    {
        if ($this->isValidDomain($domainName)) {
            $this->domainNames[] = $domainName;
            return true;
        }
        return false;
    }

    private function isValidDomain($domain_name)
    {
        return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain_name)
            && preg_match("/^.{1,253}$/", $domain_name)
            && preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain_name));
    }

    private function html2Js($code)
    {
        $search = array(
            '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
            '/[^\S ]+\</s',     // strip whitespaces before tags, except space
            '/(\s)+/s',         // shorten multiple whitespace sequences
            '/<!--(.|\s)*?-->/' // Remove HTML comments
        );
        $replace = array(
            '>',
            '<',
            '\\1',
            ''
        );
        $code = preg_replace($search, $replace, $code);
        $code = "document.write('" . addslashes($code . " ") . "');";
        return $code;
    }

    private function cleanHtml($code)
    {
        return preg_replace('/<!--(.|\s)*?-->/', '', $code);
    }

    private function cleanJS($code)
    {
        $pattern = '/(?:(?:\/\*(?:[^*]|(?:\*+[^*\/]))*\*+\/)|(?:(?<!\:|\\\|\')\/\/.*))/';
        $code = preg_replace($pattern, '', $code);
        $search = array(
            '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
            '/[^\S ]+\</s',     // strip whitespaces before tags, except space
            '/(\s)+/s',         // shorten multiple whitespace sequences
            '/<!--(.|\s)*?-->/' // Remove HTML comments
        );
        $replace = array(
            '>',
            '<',
            '\\1',
            ''
        );
        return preg_replace($search, $replace, $code);
    }
}

// Coded by WingyCodes

?>