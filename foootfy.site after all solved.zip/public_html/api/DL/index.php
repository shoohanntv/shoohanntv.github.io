<?php

// Coded by WingyCodes

include("_@configs.php");

$channelID = "";
if(isset($_REQUEST['play'])) { $channelID = trim($_REQUEST['play']); }
if(isset($_REQUEST['fid'])) { $channelID = trim($_REQUEST['fid']); }

if(!empty($channelID))
{
?>
<!doctype html>
<html>
<head>
<title>[LiveStream] - <?php print($APP_CONFIGS['APP_NAME']); ?> | <?php print($APP_CONFIGS['APP_POWEREDBY']); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" />
<link rel="icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
<link rel="shortcut icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
<link rel="stylesheet" href="files/jwplayer.css"/>
<style>
body{font-family:"Montserrat",sans-serif;background-color:#000}#serverList { font-size: 20px !important; }  #vplayer { position: absolute; width: 100% !important; height: 100% !important; }.top-right-button{position:absolute;top:10px;left:10px;padding:10px 20px;background-color:#ffffff;color:#000000;border:none;border-radius:5px;cursor:pointer;font-size:16px;z-index:9999}.custom-modal{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgb(0 0 0 / .5);display:none;justify-content:center;align-items:center;z-index:9999;justify-content:center;align-items:center}.custom-modal-content{background-color:#222;padding:20px;border-radius:8px;width:200px;max-width:70%;box-shadow:0 4px 8px rgb(0 0 0 / .2);z-index:10000}.custom-modal-header{font-size:20px;font-weight:700;margin-bottom:15px;text-align:center}.server-list{list-style:none;padding:0;margin:0}.server-list li{color:#FFF;padding-left:25px;padding-top:10px;padding-bottom:10px;border:1px solid #ddd;border-radius:22px;margin-bottom:5px;cursor:pointer;transition:background-color 0.3s}.server-list li:hover{background-color:#f0f0f0;color:#525252}.close-modal{text-align:right;cursor:pointer;color:#333;font-size:18px}.close-modal:hover{color:red}.toast-container{position:fixed;top:0;left:50%;transform:translateX(-50%);z-index:9999;display:none;padding:10px 20px;background-color:#333;color:#fff;font-size:16px;border-radius:5px;box-shadow:0 4px 6px rgb(0 0 0 / .2);animation:slideDown 0.3s ease,fadeOut 0.5s ease 2.5s}@keyframes slideDown{from{top:-50px;opacity:0}to{top:0;opacity:1}}@keyframes fadeOut{from{opacity:1}to{opacity:0}}#closeModal{font-size:28px;color:#fff;font-weight:700;margin-bottom:10px}
</style>
</head>
<body>

<button class="top-right-button" id="openModal">Servers</button>

<div class="custom-modal" id="modal">
    <div class="custom-modal-content">
        <div class="close-modal" id="closeModal">&times;</div>
        <ul class="server-list" id="serverList"></ul>
    </div>
</div>

<div class="toast-container" id="toast"></div>

<div id="vplayer"></div>

<script src="https://content.jwplatform.com/libraries/KB5zFt7A.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
<?php $jsCode = 'let playerInstance; let TV_ID = "'.$channelID.'"; let c3ihnf = "'.streamTokenValidation("generate", $channelID).'";';
$jsCode .= '$(document).ready(function(){ getStreamServer(); });
function getStreamServer()
{
    toaster("Fetching Servers ...");
    $.ajax({
        "url": "service.php",
        "type": "POST",
        "data": "action=get_detail_fidserver&id=" + TV_ID + "&server=1",
        "success": function(data)
        {
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                document.title = document.title.replace("[LiveStream]", data.data.title);
                toaster("Streaming via Server 1");
                attachPlayer(data["data"]["servers"][0]["url"]);
                sessionStorage.setItem("channelName", data.data.title);
                sessionStorage.setItem("sserver", JSON.stringify(data["data"]["servers"]));
            }
            else
            {
                if(data.status == "error")
                {
                    toaster(data.message);
                }
                else
                {
                    toaster("Error: Unknown Error Occured");
                }
            }
        },
        "error": function(data) {
            toaster("Error: Network or Server Failure Server Occured");
        }
    });
}
function attachPlayer(playurl)
{
    playerInstance = jwplayer("vplayer").setup({
        controls: true,
        sharing: true,
        displaytitle: true,
        autoplay: true,
        displaydescription: true,
        skin: {
            name: "netflix"
        },
        captions: {
            color: "#FFF",
            fontSize: 14,
            backgroundOpacity: 0,
            edgeStyle: "raised"
        },
        playlist: [
            {
                title: sessionStorage.getItem("channelName"),
                description: "You are Watching",
                sources: [
                    {
                        file: jRtZrmn(playurl),
                        type: "hls",
                        default: true
                    }
                ]
            }
        ]
    });
    playerInstance.on("error", function(){
        toaster("Playback Error Occured ...");
        
        window.setTimeout(function(){
           toaster("Please Reload The Page/Frame !");
        }, 5000);
    });
}
function jRtZrmn(url)
{
    if(c3ihnf === undefined || c3ihnf === null || c3ihnf === "")
    {
        return url;
    }
    else
    {
        let bn48 = "";
        if(url.includes("?")){ bn48 = "&"; } else { bn48 = "?"; }
        let ujY6hx = url + bn48 + "vtoken=" + c3ihnf;
        return ujY6hx;
    }
}
function toaster(message)
{
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.style.display = "block";
    setTimeout(() => {
        toast.style.display = "none";
    }, 4000);
}
$("#openModal").click(function () {
    $("#serverList").empty();
    const servers = JSON.parse(sessionStorage.getItem("sserver"));
    servers.forEach(server => {
        $("#serverList").append(
            `<li data-url="${server.url}" data-sid="${server.id}">${server.id}</li>`
        );
    });
    $("#modal").fadeIn();
});
$("#closeModal").click(function () {
    $("#modal").fadeOut();
});
$("#serverList").on("click", "li", function () {
    const playUrl = $(this).data("url");
    let serverUQID = $(this).data("sid");
    playerInstance.stop();
    $("#player").empty();
    attachPlayer(playUrl);
    $("#modal").fadeOut();
    toaster("Streaming via " + serverUQID);
});';
$hunter = new HunterObfuscator($jsCode);
$obsfucated = $hunter->Obfuscate();
print($obsfucated);
?>
</script>
</body>
</html>
<?php
// Coded by WingyCodes
}
else
{
// Coded by WingyCodes
?>
<!doctype html>
<html>
<head>
<title>Home - <?php print($APP_CONFIGS['APP_NAME']); ?> | <?php print($APP_CONFIGS['APP_POWEREDBY']); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
<link rel="shortcut icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
<style>
body { font-family: "Montserrat", sans-serif; background-color: black; }
.card { color: #FFFFFF; border-radius:2rem .3rem; background-color: #202020 !important; text-align: center; justify-content: center; item-align: center; border:2px solid black; }
#inpSearchTV { border-top-left-radius: 22px; border-bottom-left-radius: 22px; padding-left: 26px; }
#btnIPTVlist { border-top-right-radius: 22px; border-bottom-right-radius: 22px; }
.card:hover { background-color: rgba(165, 42, 42, 0.521); border-color:white; border:2px solid white; }
.card:hover .card-text { color:white; }
.card a { text-decoration: none; color: #FFFFFF; }
.tvimage { border-radius: 28px; }
.boldbtn { font-weight: bold; }
.prvselect { -webkit-user-select: none; -ms-user-select: none; user-select: none; }
.toast-body { font-weight: bold; color: #067964; }
.modal, .list-group, .list-group-flush, .list-group-item { background-color: black !important; color: white; }
.modal-content { background-color: #202020 !important; color: white; }
</style>
</head>
<body>

    <nav class="navbar bg-body-dark">
      <div class="container-fluid">
        <a class="navbar-brand mt-4 mb-2 px-5"><img src="<?php print($APP_CONFIGS['APP_LOGO']); ?>" alt="<?php print($APP_CONFIGS['APP_NAME']); ?>" width="200"/></a>
        <form class="d-flex" role="search"></form>
      </div>
    </nav>
    
    <div class="card bg-body-secondary mt-2 mb-4 px-4 pt-3 pb-3">
    <div class="input-group">
        <input type="text" class="form-control" placeholder="Type Channel Name To Search ..." id="inpSearchTV" autocomplete="off"/>
        <button class="btn btn-dark boldbtn" type="button" id="btnInitTVSearch" title="Search Channels">&nbsp;<i class="fa-solid fa-magnifying-glass"></i>&nbsp;</button>
        <button class="btn btn-secondary boldbtn" type="button" id="btnIPTVlist" title="Click To Download IPTV M3U-Playlist"><i class="fa-solid fa-download"></i></button>
    </div>
    </div>
    
    <div class="container">
        <div align="center" class="mt-4" id="tvsGrid">
            <div style="margin-top: 150px;"><div class="spinner-border text-light" style="width: 3rem; height: 3rem;" role="status"><span class="visually-hidden">Loading...</span></div></div>
        </div>
    </div>

    <div class="toast-container position-fixed p-3 top-0 start-50 translate-middle-x"></div>

    <div class="modal fade" id="addnlModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="addnlModalLabel"></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addnlModalBody"><div class="spinner-border text-light" role="status"><span class="visually-hidden">Loading...</span></div></div>
            </div>
        </div>
    </div>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
let OPEN_PLAYER_IN_FULL = "OFF";
$(document).ready(function(){
    loadTVlist();
});
$("#btnIPTVlist").on("click", function(){
    window.location = "service.php?action=m3u_playlist";
});
$("#btnInitTVSearch").on("click", function() {
    searchTVlist();
});
$("#inpSearchTV").on('keydown', function(event) {
    if (event.key === 'Enter' || event.keyCode === 13) {
        event.preventDefault();
        searchTVlist();
    }
});
$("#inpSearchTV").on('input', function() {
    searchTVlist();
});
function toaster(text) {
    $(".toast-container").html(`<div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-body">` + text + `</div></div>`);
    $(".toast").toast("show");
}
function loadTVlist()
{
    $.ajax({
        "url": "service.php",
        "type": "POST",
        "data": "action=getChannels",
        "success":function(data)
        {
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                let lmtl = '';
                lmtl += '<div class="row mt-3">';
                $.each(data.data.list, function(k, v) {
                    lmtl += '<div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-4" data-tvid="' + v.id + '" data-tvname="' + v.title + '" onclick="playlivetv(this)" title="Watch ' + v.title + ' Live" id="livetvCard">';
                    lmtl += '<div class="card">';
                    lmtl += '<div class="card-body">';
                    lmtl += '<img class="card-img-top tvimage" src="' + v.logo + '" width="120" height="100" alt="' + v.title + '"/>';
                    lmtl += '<div class="mt-2 prvselect">';
                    lmtl += '<b>' + v.title + '</b>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                });
                lmtl += '</div>';
                $("#tvsGrid").html(lmtl);
            }
            else
            {
                if(data.message !== "" && data.message !== null && data.message !== undefined) {
                    toaster("Error: " + data.message);
                }
                else {
                    toaster("Error: No Channels Found");
                }
                
                $("#tvsGrid").html('<div class="text-white" style="margin: 100px;">No Channels Found</div>');
            }
        },
        "error":function(data)
        {
            toaster("Error: Server Error or Network Failed");
            $("#tvsGrid").html('<div class="text-white" style="margin: 100px;">Server Error or Network Failed</div>');
        }
    });
}

function playlivetv(e)
{
    let tv_id = $(e).attr("data-tvid");
    let tv_name = $(e).attr("data-tvname");
    if(OPEN_PLAYER_IN_FULL == "ON")
    {
        $.ajax({
            "url": "service.php",
            "type": "POST",
            "data": "action=get_detail&id=" + tv_id,
            "success": function(data) {
                try { data = JSON.parse(data); }catch(error){}
                if(data.status == "success")
                {
                    let vtn = ``;
                    vtn = vtn + `<ul class="list-group list-group-flush">`;
                    $.each(data.data.servers, function(k,v){
                        vtn = vtn + `<li class="list-group-item"><i class="fa-solid fa-circle-play"></i>&nbsp;&nbsp;&nbsp;<a href="?fid=` + tv_id + `&server=` + extractNumbers(v.id) + `" style="text-decoration: none; color: #00FFFF; font-weight: bold;" target="_blank">` + v.id + `</a></li>`;
                    });
                    vtn = vtn + `</ul>`;
                    $("#addnlModalBody").html(vtn);
                }
                else
                {
                    if(data.status == "error")
                    {
                        $("#addnlModalBody").html('<div style="text-align: center;" class="text-warning">' + data.message + '</div>');
                    }
                    else
                    {
                        $("#addnlModalBody").html('<div style="text-align: center;" class="text-warning">Something Went Wrong</div>');
                    }
                }
            },
            "error": function(data)
            {
                $("#addnlModalBody").html('<div style="text-align: center;" class="text-warning">Server Error or Network Failure</div>');
            }
        });
        $("#addnlModalLabel").html(`` + tv_name);
        $("#addnlModal").modal("show");
    }
    else
    {
        window.location = "?play=" +tv_id;
    }
}

function searchTVlist()
{
    let orgbtnID = "btnInitTVSearch";
    let orgbtnTx = $("#" + orgbtnID).html();
    $("#" + orgbtnID).html('<span class="spinner-border spinner-border-sm" aria-hidden="true"></span>');
    let query = $("#inpSearchTV").val();
    $.ajax({
        "url": "service.php",
        "type": "POST",
        "data": "action=searchChannels&query=" + query,
        "success":function(data)
        {
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                let lmtl = '';
                lmtl += '<div class="row mt-3">';
                $.each(data.data.list, function(k, v) {
                    lmtl += '<div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-4" data-tvid="' + v.id + '" data-tvname="' + v.title + '" onclick="playlivetv(this)" title="Watch ' + v.title + ' Live" id="livetvCard">';
                    lmtl += '<div class="card">';
                    lmtl += '<div class="card-body">';
                    lmtl += '<img class="card-img-top tvimage" src="' + v.logo + '" width="120" height="100" alt="' + v.title + '"/>';
                    lmtl += '<div class="mt-2 prvselect">';
                    lmtl += '<b>' + v.title + '</b>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                    lmtl += '</div>';
                });
                lmtl += '</div>';
                $("#tvsGrid").html(lmtl);
                toaster("Displaying Search Results - " + data.data.query);
                $("#" + orgbtnID).html(orgbtnTx);
            }
            else
            {
                if(data.message !== "" && data.message !== null && data.message !== undefined) {
                    toaster("Error: " + data.message);
                }
                else {
                    toaster("Error: No Channels Found");
                }
                window.setTimeout(function(){ loadTVlist(); }, 4000);
                $("#" + orgbtnID).html(orgbtnTx);
            }
        },
        "error":function(data)
        {
            $("#" + orgbtnID).html(orgbtnTx);
            loadTVlist();
            alert("Error: Server Error or Network Failed");
        }
    });
}
function extractNumbers(str)
{
    const numbers = str.match(/-?\d+(\.\d+)?/g);
    return numbers ? numbers.map(Number) : [];
}
</script>
</body>
</html>
<?php

// Coded by WingyCodes

}
?>