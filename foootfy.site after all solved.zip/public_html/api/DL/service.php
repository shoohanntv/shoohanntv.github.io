<?php

include("_@configs.php");

$action = "";
if(isset($_REQUEST['action'])) { $action = trim($_REQUEST['action']); }

// Coded by WingyCodes
//=============================================================//

$tvlist = get_channels();

if($action == "getChannels")
{
    $outlist = array();
    if(!isset($tvlist[0])) { response("error", 404, "No Channels Found", ""); }
    foreach($tvlist as $dhdl) {
        $dhdl['logo'] = $APP_CONFIGS['CHANNEL_LOGO'];
        $outlist[] = $dhdl;
    }
    response("success", 200, "Channels List", array("count" => count($tvlist), "list" => $outlist));
}
elseif($action == "get_detail")
{
    $id = ""; $strmServers = array();
    if(isset($_REQUEST['id'])) { $id = trim($_REQUEST['id']); }
    if(empty($id)) {
        response("error", 400, "Error: Stream or Channel Identifier Missing", "");
    }
    $x = getChannelServers($id);
    if(empty($x)) {
        response("error", 404, "Error: Streaming Servers are Unavailable", "");
    }
    foreach($x as $rsv)
    {
        $serverSrl = implode('', array_filter(preg_split('/\D+/', $rsv['name'])));
        $strmServers[] = array("id" => "Server ".$serverSrl, "url" => "stream.php?id=".$id."&srv=".$serverSrl."&vtoken=&e=.m3u8");
    }
    response("success", 200, "Streaming Servers List", array("id" => $id, "title" => get_channel_name($id), "servers" => $strmServers));
}
elseif($action == "get_detail_fidserver")
{
    $id = ""; $server = ""; $strmServers = array();
    if(isset($_REQUEST['id'])){ $id = trim($_REQUEST['id']); }
    if(isset($_REQUEST['server'])){ $server = trim($_REQUEST['server']); }
    if(empty($id)) {
        response("error", 400, "Error: Channel Identifier Missing", "");
    }
    if(empty($server)) {
        response("error", 400, "Error: Server ID Missing", "");
    }
    //- - - - - - - - - - - - - - - - - - - - - - - - - -//
    $streamTitle = get_channel_name($id);
    if(empty($streamTitle))
    {
        $daddyHDEvent = get_special_event_servers($id);
        if(!empty($daddyHDEvent)) {
            foreach($daddyHDEvent['servers'] as $odr)
            {
                $tflsr = implode('', array_filter(preg_split('/\D+/', $odr['name'])));
                $strmServers[] = array("id" => "Server ".$tflsr, "url" => "stream.php?id=".$id."&srv=".$tflsr."&format=.m3u8");
            }
            response("success", 200, "Streaming Servers List (Events API)", array("id" => $id, "title" => $daddyHDEvent['title'], "stream_url" => "stream.php?id=".$id."&srv=".$server."&vtoken=&e=.m3u8", "servers" => $strmServers));
        }
        response("error", 404, "Error: Stream Does Not Exist [1]", "");
    }
    $ttlServerC = count(getChannelServers($id));
    if($server > $ttlServerC) {
        response("error", 404, "Error: Server Does Not Exist [2]", "");
    }
    $xSS = getChannelServers($id);
    foreach($xSS as $rsv)
    {
        $serverSrl = implode('', array_filter(preg_split('/\D+/', $rsv['name'])));
        $strmServers[] = array("id" => "Server ".$serverSrl, "url" => "stream.php?id=".$id."&srv=".$serverSrl."&format=.m3u8");
    }
    response("success", 200, "Streaming Servers List", array("id" => $id, "title" => get_channel_name($id), "stream_url" => "stream.php?id=".$id."&srv=".$server."&vtoken=&e=.m3u8", "servers" => $strmServers));
}
elseif($action == "searchChannels")
{
    $query = ""; $resdata = array();
    if(isset($_REQUEST['query'])){ $query = trim($_REQUEST['query']); }
    if(empty($query)){ response("error", 400, "Please Enter Channel Name To Search", ""); }
    if(!isset($tvlist[0])) { response("error", 404, "No Channels Exist", ""); }
    foreach($tvlist as $vtl) {
        $vtl['logo'] = $APP_CONFIGS['CHANNEL_LOGO'];
        if(stripos($vtl['title'], $query) !== false) { $resdata[] = $vtl; }
    }
    if(!isset($resdata[0])){ response("error", 404, "No Matching Results Found", ""); }
    response("success", 200, "Total ".count($resdata)." Results Found", array("count" => count($resdata), "query" => $query, "list" => $resdata));
}
elseif($action == "m3u_playlist")
{
    if(isset($tvlist[0]))
    {
        if($_SERVER['SERVER_PORT'] !== "80" && $_SERVER['SERVER_PORT'] !== "443") { $playUrlBase = $streamenvproto."://".$plhoth.":".$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); } else { $playUrlBase = $streamenvproto."://".$plhoth.str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); }
        $logoURL = $playUrlBase."assets/daddylive.png";
        $playlistData = "#EXTM3U\n";
        $c = 0;
        foreach($tvlist as $otv)
        {
            $c++;
            $playlistData .= '#EXTINF:-1 tvg-id="'.$c.'" tvg-name="'.$otv['title'].'" tvg-country="US" tvg-logo="'.$logoURL.'" tvg-chno="'.$c.'" group-title="",'.$otv['title']."\n";
            $playlistData .= $playUrlBase."stream.m3u8?id=".$otv['id']."\n";
        }
        $file = str_replace(" ", "", $APP_CONFIGS['APP_NAME'])."_(WingyCodes)-".time().".m3u";
        header('Content-Disposition: attachment; filename="'.$file.'"');
        header("Content-Type: application/vnd.apple.mpegurl");
        exit($playlistData);
    }
    http_response_code(404); exit();

}
else
{
    response("error", 400, "Bad Request", "");
}

// Coded by WingyCodes

?>