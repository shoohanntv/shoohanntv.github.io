<?php

include("_@configs.php");

// Coded by WingyCodes

header("Access-Control-Allow-Origin: *");

$id = ""; $cid = ""; $srv = ""; $key = ""; $chunks = ""; $segment = "";
$vtoken = ""; $streamURL = ""; $refererURL = ""; $originURL = ""; $detail = array();
if(isset($_REQUEST['id'])) { $id = trim($_REQUEST['id']); }
if(isset($_REQUEST['cid'])) { $cid = trim($_REQUEST['cid']); }
if(isset($_REQUEST['srv'])) { $srv = trim($_REQUEST['srv']); }
if(isset($_REQUEST['key'])) { $key = trim($_REQUEST['key']); }
if(isset($_REQUEST['chunks'])) { $chunks = trim($_REQUEST['chunks']); }
if(isset($_REQUEST['segment'])) { $segment = trim($_REQUEST['segment']); }
if(isset($_REQUEST['vtoken'])) { $vtoken = trim($_REQUEST['vtoken']); }

$irlid = ""; if(!empty($id) && empty($cid)) { $irlid = $id;  } if(empty($id) && !empty($cid)) { $irlid = $cid;  }

if(isset($APP_CONFIGS['STREAM_TOKEN_SECURITY']) && $APP_CONFIGS['STREAM_TOKEN_SECURITY'] == "ON")
{
    $tknFW = streamTokenValidation("validate", array("cid" => $irlid, "token" => $vtoken));
    if($tknFW !== "OK") { header("X-FW-Error: ".$tknFW); http_response_code(401); exit(); }
}

//Validate Server Input
if (!preg_match('/^[0-9]+$/', $srv)) { $srv = 1; } if($srv < 1) { $srv = 1; }

$detail = get_stream_url($irlid, $srv);
if(!empty($detail))
{
    $streamURL = $detail['streamurl'];
    $refererURL = $detail['referer'];
    $originURL = rtrim($detail['referer'], "/");
    $strmHeader = array("Referer: ".$refererURL, "Origin: ".$originURL, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
}
else
{
    $strmHeader = array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
}

if(stripos($_SERVER['REQUEST_URI'], ".php?") !== false){ $HLS_EXT = $KEY_EXT = $TS_EXT = ".php"; } else { $HLS_EXT = ".m3u8"; $KEY_EXT = ".key"; $TS_EXT = ".ts"; }
$CSTRMFILE = str_replace(".php", "", basename($_SERVER['SCRIPT_NAME']));

// Coded by WingyCodes

//================================================//

if(!empty($id))
{
    if(!filter_var($streamURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest($streamURL, $strmHeader);
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") === false)
    {
        $fetch = getRequest__fget($streamURL, $strmHeader);
        $return = $fetch['data'];
    }
    if(stripos($return, "#EXTM3U") !== false)
    {
        $tine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, 'URI="') !== false)
            {
                $orgURL = getXPURI($vine);
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($orgURL, "http://") !== false || stripos($orgURL, "https://") !== false){ $iBaseURL = ""; }
                if(stripos($orgURL, "key") !== false)
                {
                    $norgURL = $CSTRMFILE.$KEY_EXT."?cid=".$id."&srv=".$srv."&key=".enc_dec('encrypt', $iBaseURL.$orgURL)."&vtoken=".$vtoken;
                }
                else
                {
                    $norgURL = $CSTRMFILE.$HLS_EXT."?cid=".$id."&srv=".$srv."&chunks=".enc_dec('encrypt', $iBaseURL.$orgURL)."&vtoken=".$vtoken;
                }
                $tine .= str_replace($orgURL, $norgURL, $vine)."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                $tine .= $CSTRMFILE.$HLS_EXT."?cid=".$id."&srv=".$srv."&chunks=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".md") !== false || stripos($vine, ".xml") !== false || stripos($vine, ".eot") !== false || stripos($vine, ".csv") !== false || stripos($vine, ".rtf") !== false || stripos($vine, ".webp") !== false || stripos($vine, ".doc") !== false || stripos($vine, ".txt") !== false || stripos($vine, ".ogg") !== false || stripos($vine, ".gif") !== false || stripos($vine, ".js") !== false ||  stripos($vine, ".aspx") !== false || stripos($vine, ".jsp") !== false || stripos($vine, ".asp") !== false || stripos($vine, ".php") !== false || stripos($vine, ".ico") !== false || stripos($vine, ".bmp") !== false || stripos($vine, ".tif") !== false || stripos($vine, ".svg") !== false || stripos($vine, ".jar") !== false || stripos($vine, ".html") !== false || stripos($vine, ".xls") !== false || stripos($vine, ".webm") !== false || stripos($vine, ".exe") !== false || stripos($vine, ".apk") !== false || stripos($vine, ".ejs") !== false || stripos($vine, ".ts") !== false || stripos($vine, ".png") !== false || stripos($vine, ".css") !== false || stripos($vine, ".woff") !== false || stripos($vine, ".ttf") !== false || stripos($vine, ".zip") !== false || stripos($vine, ".rar") !== false || stripos($vine, ".pdf") !== false || stripos($vine, ".jpg") !== false || stripos($vine, ".jpeg") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                if(isWebBrowser())
                {
                    $tine .= $CSTRMFILE.$TS_EXT."?cid=".$id."&srv=".$srv."&segment=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
                }
                else
                {
                    $tine .= $iBaseURL.$vine."\n";
                }
            }
            else
            {
                $tine .= $vine."\n";
            }
        }
        header("Content-Type: application/vnd.apple.mpegurl");
        print(trim($tine));
        exit();
    }
    if(stripos($fetch['error'], '407') !== false || stripos($fetch['error'], 407) !== false) {
        exit("ERROR: PROXY AUTHENTICATION REQUIRED");
    }
    header("Location: ".$streamURL);
    exit();
}
elseif(!empty($chunks))
{
    $playURL = enc_dec('decrypt', $chunks);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest($playURL, $strmHeader);
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") === false)
    {
        $fetch = getRequest__fget($playURL, $strmHeader);
        $return = $fetch['data'];
    }
    if(stripos($return, "#EXTM3U") !== false)
    {
        $tine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, 'URI="') !== false)
            {
                $orgURL = getXPURI($vine);
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($orgURL, "http://") !== false || stripos($orgURL, "https://") !== false){ $iBaseURL = ""; }
                $norgURL = $CSTRMFILE.$KEY_EXT."?cid=".$cid."&srv=".$srv."&key=".enc_dec('encrypt', $iBaseURL.$orgURL)."&vtoken=".$vtoken;
                $tine .= str_replace($orgURL, $norgURL, $vine)."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                $tine .= $CSTRMFILE.$HLS_EXT."?cid=".$id."&srv=".$srv."&chunks=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".md") !== false || stripos($vine, ".xml") !== false || stripos($vine, ".eot") !== false || stripos($vine, ".csv") !== false || stripos($vine, ".rtf") !== false || stripos($vine, ".webp") !== false || stripos($vine, ".doc") !== false || stripos($vine, ".txt") !== false || stripos($vine, ".ogg") !== false || stripos($vine, ".gif") !== false || stripos($vine, ".js") !== false ||  stripos($vine, ".aspx") !== false || stripos($vine, ".jsp") !== false || stripos($vine, ".asp") !== false || stripos($vine, ".php") !== false || stripos($vine, ".ico") !== false || stripos($vine, ".bmp") !== false || stripos($vine, ".tif") !== false || stripos($vine, ".svg") !== false || stripos($vine, ".jar") !== false || stripos($vine, ".html") !== false || stripos($vine, ".xls") !== false || stripos($vine, ".webm") !== false || stripos($vine, ".exe") !== false || stripos($vine, ".apk") !== false || stripos($vine, ".ejs") !== false || stripos($vine, ".ts") !== false || stripos($vine, ".png") !== false || stripos($vine, ".css") !== false || stripos($vine, ".woff") !== false || stripos($vine, ".ttf") !== false || stripos($vine, ".zip") !== false || stripos($vine, ".rar") !== false || stripos($vine, ".pdf") !== false || stripos($vine, ".jpg") !== false || stripos($vine, ".jpeg") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                if(isWebBrowser())
                {
                    $tine .= $CSTRMFILE.$TS_EXT."?cid=".$cid."&srv=".$srv."&segment=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
                }
                else
                {
                    $tine .= $iBaseURL.$vine."\n";
                }
            }
            else
            {
                $tine .= $vine."\n";
            }
        }
        header("Content-Type: application/vnd.apple.mpegurl");
        print(trim($tine));
        exit();
    }
    // Coded by WingyCodes
}
elseif(!empty($key))
{
    $playURL = enc_dec('decrypt', $key);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $aesKeyLicURL = modifyKeyURL($playURL);
    $fetch = getRequest($aesKeyLicURL, $strmHeader);
    $return = $fetch['data'];
    if(!empty($return) && strlen($return) == 16)
    {
        header("Content-Type: application/binary");
        print($return);
        exit();
    }
    else
    {
        $fetch = getRequest__fget($aesKeyLicURL, $strmHeader);
        $return = $fetch['data'];
        if(!empty($return) && strlen($return) == 16)
        {
            header("Content-Type: application/binary");
            print($return);
            exit();
        }
        else
        {
            header("X-Kafka-Error: Key Fetch Failed");
            http_response_code(403);
            exit();
        }
    }
}
elseif(!empty($segment))
{
    $playURL = enc_dec('decrypt', $segment);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest($playURL, $strmHeader);
    $return = $fetch['data'];
    header("Content-Type: video/m2ts");
    print($return);
    exit();
}
else
{
    http_response_code(400); exit();
}

// Coded by WingyCodes

?>