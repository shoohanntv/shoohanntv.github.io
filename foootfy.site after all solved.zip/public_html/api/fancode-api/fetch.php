<?php
header("Content-Type: application/json");

// Fetch Fancode JSON
$json_url = "https://raw.githubusercontent.com/drmlive/fancode-live-events/refs/heads/main/fancode.json";
$json_data = file_get_contents($json_url);

if (!$json_data) {
    echo json_encode(["error" => "Failed to fetch JSON data"]);
    exit;
}

$matches = json_decode($json_data, true);
if (!$matches) {
    echo json_encode(["error" => "Invalid JSON format"]);
    exit;
}

// Fetch M3U File
$m3u_url = "https://raw.githubusercontent.com/drmlive/fancode-live-events/refs/heads/main/fancode.m3u";
$m3u_data = file_get_contents($m3u_url);

if (!$m3u_data) {
    echo json_encode(["error" => "Failed to fetch M3U file"]);
    exit;
}

// Extract Links from M3U File
$m3u_lines = explode("\n", $m3u_data);
$streams = [];
$match_index = -1;

foreach ($m3u_lines as $line) {
    if (strpos($line, "#EXTINF") !== false) {
        $match_index++;
    } elseif (strpos($line, "http") === 0) {
        $streams[$match_index] = trim($line);
    }
}

// Combine JSON Matches with M3U Streams
foreach ($matches as $index => $match) {
    $matches[$index]['stream_url'] = $streams[$index] ?? null;
}

// Output merged JSON
echo json_encode($matches, JSON_PRETTY_PRINT);
?>
