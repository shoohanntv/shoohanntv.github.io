<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FanCode Matches & Streams</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #111; color: #fff; text-align: center; }
        .container { max-width: 800px; margin: auto; padding: 20px; }
        .match-card { background-color: #222; border-radius: 10px; padding: 15px; margin: 15px 0; text-align: left; }
        .match-card img { width: 100%; border-radius: 10px; }
        .match-card h3 { margin-top: 10px; }
        .watch-btn { display: block; background-color: #ff5500; color: white; padding: 10px; margin-top: 10px; text-align: center; border-radius: 5px; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>FanCode Live & Upcoming Matches</h1>
        
        <h2>Live Matches</h2>
        <div id="live-matches"></div>

        <h2>Upcoming Matches</h2>
        <div id="upcoming-matches"></div>
    </div>

    <script>
        async function fetchEvents() {
            try {
                const response = await fetch("fetch.php");
                const data = await response.json();
                
                console.log("Fetched Data:", data); // Debugging output

                if (!data || data.length === 0) {
                    document.body.innerHTML += `<p style="color:red;">No matches found</p>`;
                    return;
                }

                displayMatches(data);
            } catch (error) {
                console.error("Error fetching API data:", error);
                document.body.innerHTML += `<p style="color:red;">Error loading data</p>`;
            }
        }

        function displayMatches(data) {
            let liveContainer = document.getElementById("live-matches");
            let upcomingContainer = document.getElementById("upcoming-matches");
            liveContainer.innerHTML = "";
            upcomingContainer.innerHTML = "";

            data.forEach(event => {
                console.log("Event Data:", event); // Debugging each event

                let matchDiv = document.createElement("div");
                matchDiv.classList.add("match-card");

                let imgSrc = event.image || "https://via.placeholder.com/800x400"; 
                let streamLink = event.stream_url ? `<a href="${event.stream_url}" target="_blank" class="watch-btn">Watch Now</a>` : `<p style="color:red;">No Stream Available</p>`;

                let matchHTML = `
                    <img src="${imgSrc}" alt="Match Image">
                    <h3>${event.name || "Unknown Match"}</h3>
                    <p>Status: ${event.status || "N/A"}</p>
                    <p>Category: ${event.category || "N/A"}</p>
                    <p>Start Time: ${event.start_time || "N/A"}</p>
                    ${streamLink}
                `;

                matchDiv.innerHTML = matchHTML;

                if (event.status && event.status.toLowerCase() === "live") {
                    liveContainer.appendChild(matchDiv);
                } else if (event.status && event.status.toLowerCase() === "upcoming") {
                    upcomingContainer.appendChild(matchDiv);
                }
            });
        }

        // Fetch matches when page loads
        fetchEvents();
    </script>
</body>
</html>
