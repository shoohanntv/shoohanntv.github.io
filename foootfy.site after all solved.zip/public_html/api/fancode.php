<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HLS Video Player with Quality Selector and Loading Poster</title>
    <style>
        /* Ensures video player covers the full width and height */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #000;
        }
        #videoPlayer {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        /* Styling for the gear icon button (40% smaller) */
        .quality-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.7);
            padding: 6px; /* 40% smaller */
            border-radius: 50%;
            cursor: pointer;
            z-index: 10;
        }
        .quality-button img {
            width: 15px; /* 40% smaller */
            height: 15px; /* 40% smaller */
        }
        /* Styling for the quality dropdown */
        .quality-selector {
            display: none;
            position: absolute;
            top: 60px;
            right: 20px;
            background: rgba(0, 0, 0, 0.8);
            color: #fff;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            z-index: 10;
        }
        .quality-selector select {
            background: transparent;
            color: #fff;
            border: none;
            outline: none;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <!-- Video Player Element with Loading Poster -->
    <video id="videoPlayer" controls autoplay muted poster="https://play.footfy.net/f/loading.gif"></video>

    <!-- Gear Icon for Quality Selector -->
    <div class="quality-button" id="qualityButton">
        <img src="https://img.icons8.com/ios-filled/50/ffffff/settings.png" alt="Quality Settings">
    </div>

    <!-- Quality Selector Dropdown -->
    <div class="quality-selector" id="qualitySelector">
        <select id="qualityLevels">
            <option value="auto">Auto</option>
        </select>
    </div>

    <!-- hls.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>

    <script>
        const m3u8Url = 'https://vsd144.okcdn.ru/hls/6965915421318.m3u8/sig/unaORKU6uWk/expires/1730976930398/srcIp/103.213.38.37/urls/45.136.21.80/clientType/0/srcAg/CHROME_ANDROID/mid/7325411516038/video.m3u8?p';
        const video = document.getElementById('videoPlayer');
        const qualitySelector = document.getElementById('qualitySelector');
        const qualityLevels = document.getElementById('qualityLevels');
        const qualityButton = document.getElementById('qualityButton');
        let hls;

        // Toggle display of the quality selector on button click
        qualityButton.addEventListener('click', () => {
            qualitySelector.style.display = qualitySelector.style.display === 'none' ? 'block' : 'none';
        });

        if (video.canPlayType('application/vnd.apple.mpegurl')) {
            // Native support for HLS
            video.src = m3u8Url;
        } else if (Hls.isSupported()) {
            hls = new Hls();
            hls.loadSource(m3u8Url);
            hls.attachMedia(video);

            // Populate quality levels once the manifest is loaded
            hls.on(Hls.Events.MANIFEST_PARSED, function () {
                const levels = hls.levels;
                qualityLevels.innerHTML = '<option value="auto">Auto</option>'; // Reset with 'Auto' option
                
                // Add available quality levels
                levels.forEach((level, index) => {
                    const option = document.createElement('option');
                    option.value = index;
                    option.text = `${level.height}p`;  // Display quality as resolution (e.g., 720p)
                    qualityLevels.appendChild(option);
                });

                // Automatically start playing once quality options are loaded
                video.play();
            });

            // Handle quality change from the selector
            qualityLevels.addEventListener('change', (event) => {
                const selectedLevel = event.target.value;
                if (selectedLevel === 'auto') {
                    hls.currentLevel = -1;  // -1 enables "auto" quality mode in HLS.js
                } else {
                    hls.currentLevel = parseInt(selectedLevel);  // Set to selected quality level
                }
            });
        } else {
            console.error("This browser does not support HLS streaming.");
        }

        // Unmute the video once it starts playing
        video.addEventListener('play', () => {
            video.muted = false;
        });
    </script>

</body>
</html>
