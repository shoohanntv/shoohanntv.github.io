<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fullscreen Landscape Video</title>
  <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css">
</head>
<body>
  <video id="player" playsinline controls>
    <source src="https://pulselink.biz/live/1/chunks.m3u8?bongls.com" type="application/x-mpegURL">
  </video>
  <script src="https://cdn.plyr.io/3.7.8/plyr.polyfilled.js"></script>
  <script>
    const player = new Plyr('#player');

    // Add fullscreen orientation change
    player.on('enterfullscreen', () => {
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(err => {
          console.error('Orientation lock failed:', err);
        });
      }
    });

    player.on('exitfullscreen', () => {
      if (screen.orientation && screen.orientation.unlock) {
        screen.orientation.unlock(); // Unlock orientation when exiting fullscreen
      }
    });
  </script>
</body>
</html>
