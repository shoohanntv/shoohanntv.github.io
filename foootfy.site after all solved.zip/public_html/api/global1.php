
<!DOCTYPE html>
<html>
<head>
    <script src="//cdn.jsdelivr.net/npm/@clappr/player@0.8/dist/clappr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swarmcloud-hls@latest/dist/p2p-engine.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swarmcloud-hls@latest/dist/clappr-p2p-plugin.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/cssm.css">
    <style>body,html{margin:0;padding:0;width:100%;height:100%;overflow:hidden}#player{position:absolute;top:0;left:0;width:100%;height:100%}.media-control[data-media-control] .media-control-layer[data-controls] .bar-container[data-seekbar] .bar-background[data-seekbar]{height:5px!important}.media-control[data-media-control] .media-control-layer[data-controls] .bar-container[data-seekbar]:hover .bar-background[data-seekbar]{height:7px!important}.media-control[data-media-control] .media-control-layer[data-controls] .bar-container[data-seekbar] .bar-background[data-seekbar] .bar-fill-1[data-seekbar]{background-color:red!important}.media-control[data-media-control] .media-control-layer[data-controls] .bar-container[data-seekbar] .bar-background[data-seekbar]{background-color:rgba(255,255,255,0.2)!important}body,html{margin:0;padding:0;width:100%;height:100%;overflow:hidden}#player{position:absolute;top:0;left:0;width:100%;height:100%}.sound-button{position:absolute;top:10px;right:10px;padding:10px 20px;background-color:#002cec;color:#fff;border:none;border-radius:5px;font-size:14px;cursor:pointer;transition:background-color .3s}.sound-button:hover{background-color:#001f4d}</style>
</head>
<body>
<div id="player"></div>
<script>
var playbackURL = "https://cbado.pricesaskeloadsc.com:443/global/live/index.m3u8?token=02252542f2483400e24c0b6df78a2f3b9c66d4f9-cf-1743643162-1743610762";
var player;
var p2pConfig = {
    trackerZone: 'us',
    sourceUrl: playbackURL
};
P2PEngineHls.tryRegisterServiceWorker(p2pConfig).then(() => {
    player = new Clappr.Player({
        source: playbackURL,
        parentId: "#player",
        poster: '',
        width: '100%',
        height: '100%',
        autoPlay: false,
        playsinline: true, 
        mute: true,
        plugins: [SwarmCloudClapprPlugin],
        playback: {
            hlsjsConfig: {
                maxBufferSize: 0,
                maxBufferLength: 12,
                liveSyncDurationCount: 3,
                p2pConfig: p2pConfig
            }
        }
    });
});
function unmutePlayer() {
    if (player) {
        player.setVolume(100); 
        player.configure({ mute: false });
        document.getElementById('soundButton').style.display = 'none'; 
    }
}
</script>
<script id="aclib" type="text/javascript" src="https://alwaysdomain01.online/ads/lib7.js"></script>
<script type="text/javascript">
    aclib.runPop({
        zoneId: '9191366',
    });
</script>
<script>!function(){try{var t=["sandbox","hasAttribute","frameElement","data","indexOf","href","domain","","plugins","undefined","namedItem","object","createElement","onerror","type","application/pdf","setAttribute","style","visibility:hidden;width:0;height:0;position:absolute;top:-99px;","appendChild","body","removeChild","parentElement","/block.html?referer=","substring","referrer"];function e(){try{if(config.ampallow){var e=window.location.ancestorOrigins;if(e[e.length-1].endsWith("google.com"))return}}catch(n){}setTimeout(function(){location[t[5]]="/block.html"},500)}!function e(n){try{if(window[t[2]][t[1]](t[0])){n();return}}catch(r){}if(0!=location[t[5]][t[4]](t[3])&&document[t[6]]==t[7]){n();return}if(typeof navigator[t[8]]!=t[9]&&typeof navigator[t[8]][t[10]]!=t[9]&&null!=navigator[t[8]][t[10]](t[11])){var i=document[t[13]](t[12]);i[t[14]]=function(){n()},i[t[17]](t[15],t[16]),i[t[17]](t[18],t[19]),i[t[17]](t[3],t[20]),document[t[22]][t[21]](i),setTimeout(function(){i[t[24]][t[23]](i)},150)}}(e),function t(){try{document.domain=document.domain}catch(e){try{if(-1!=e.toString().toLowerCase().indexOf("sandbox"))return!0}catch(n){}}return!1}()&&e(),function t(){if(window.parent===window)return!1;try{var e=window.frameElement}catch(n){e=null}return null===e?""===document.domain&&"data:"!==location.protocol:e.hasAttribute("sandbox")}()&&e()}catch(n){}}();</script>
</body>
</html>
