<?php
// Function to fetch and clean content by removing known ad scripts/popunder elements
function fetch_and_clean_content($iframe_url) {
    // Initialize a cURL session to fetch the external content
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $iframe_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Skip SSL verification for HTTPS content
    $content = curl_exec($ch);
    curl_close($ch);

    // Selectively block popunder ads and ad-related scripts
    // 1. Remove specific scripts that contain known ad-related sources (use patterns if available)
    $content = preg_replace('/<script\b[^>]*src=".*ads.*"\b[^>]*>(.*?)<\/script>/is', "", $content); // Remove scripts with "ads" in the URL
    $content = preg_replace('/<script\b[^>]*src=".*popunder.*"\b[^>]*>(.*?)<\/script>/is', "", $content); // Remove scripts with "popunder" in the URL

    // 2. Optionally, remove specific elements by class or ID (e.g., known ad containers)
    $content = preg_replace('/<div class="ads\b[^>]*>(.*?)<\/div>/is', "", $content); // Remove divs with class "ads"
    $content = preg_replace('/<div id="ad-container\b[^>]*>(.*?)<\/div>/is', "", $content); // Remove divs with ID "ad-container"

    // Return the cleaned content
    return $content;
}

// Get the 'url' parameter (the URL of the iframe content you want to display)
$iframe_url = isset($_GET['url']) ? $_GET['url'] : 'https://example.com'; // Replace 'https://example.com' with your default URL

// Fetch and clean the content from the external source
$cleaned_content = fetch_and_clean_content($iframe_url);

// Output the cleaned content
echo $cleaned_content;
?>
