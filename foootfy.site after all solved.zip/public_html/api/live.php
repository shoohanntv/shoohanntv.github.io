<!DOCTYPE html>
<html>
<head>
    <title>Video Player</title>
    <meta content="noindex, nofollow, noarchive" name="robots"/>
    <meta name="referrer" content="no-referrer" />
        <link rel="stylesheet" type="text/css" href="/players/jw.css">
<script src="https://content.jwplatform.com/libraries/KB5zFt7A.js"></script>
<script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool'></script>
</head>
<body>
    <div id="player" class="ViostreamIframe"></div>

    <script>
        function getParameterByName(name) {
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(window.location.href);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

        var ConfiguracionCanales = {
            
            "USANETWORK": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_OL1-CTR-4s/Live/channel(usa-west)/master.mpd",
                k1: "252a671825ba31ec8433f978c32ccf6d",
                k2: "ee560759ecc8d2274df2e63fcef56915"
            },
            "UNIVERSO": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_OL1-CTR-4s/Live/channel(universo-east)/master.mpd",
                k1: "232d71bb013d39ffb92ee8c576fb7e8e",
                k2: "087408a48be8d57046c3868b37ea90ba"
            },
            "ASTRO_FOOTBALL": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/2506/default_ott.mpd",
                k1: "79f4028730acca9ab8b00f26158ddb10",
                k2: "91febe843c08c7cc523efd827292e40e"
            },
            "ASTRO_SUPERSPORT": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/5076/default_primary.mpd",
                k1: "89c10c7ef0af145be7d6e88dec090b10",
                k2: "80558606a13a99d2c543872d8899ced0"
            },
            "ASTRO_SPORTS": {
                url: "https://linear05-playback.sooka.my/CH2/masterCH2.mpd",
                k1: "4a267ba09b3a43969364ee77f76dd622",
                k2: "5b00d4341e90b3022b5e57139ae8ab16"
            },
            "FANCODE": {
                url: "https://a39aivottlinear-a.akamaihd.net/OTTB/sin-nitro/live/clients/dash/enc/l8j2xgwt32/out/v1/fe72171ab2684ab8b9ee3e2ffcc9cff2/cenc.mpd",
                k1: "159a2b4e1d2d7f16892d35d935a2fb34",
                k2: "07809840dd0f511221ca78459167d1b3"
            },
            "TELEMUNDO_USA": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_OL1-CTR-4s/Live/channel(kvea)/master.mpd",
                k1: "dfb59142ce523a6c900758d5ee4c7997",
                k2: "bd2d684e590815190eda056a6d9618bc"
            },
            "BBC_THREE": {
                url: "https://wp1-obc1112-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV09093/manifest.mpd",
                k1: "4a50525c66084589983d260a52808f59",
                k2: "04ebf492aec2c867560092a956bf51b6"
            },
            "BBC_FOUR": {
                url: "https://wp1-obc1112-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV09095/manifest.mpd",
                k1: "d96572a0a9dd440b88c27268dc133399",
                k2: "4c1facad62ea4d7dd3ac59047520aa78"
            },
            "NFL": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_CTR-4s/Live/channel(lc107a1ddy)/master.mpd",
                k1: "002007110c69a23803173b50eab05f23",
                k2: "590d6e8f4ca81319f9bb29104f571990"
            },
            "NBC_SPORTS": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_CTR-4s/Live/channel(vc122ycnuy)/master.mpd",
                k1: "0020d88a6713159839743f655c5da7de",
                k2: "ba9f34226301f69a4f0f13f65a1f92ec"
            },
            "PREMIER_LEAGUE_TV": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_CTR-4s/Live/channel(vc1021n07j)/master.mpd",
                k1: "002046c9a49b9ab1cdb6616bec5d26c3",
                k2: "d2f92f6b7edc9a1a05d393ba0c20ef9e"
            },
            "WWE": {
                url: "https://akam.stream.peacocktv.com/Content/CMAF_CTR-4s/Live/channel(vc106wh3yw)/master.mpd",
                k1: "00208c93f4358213b52220898b962385",
                k2: "8ae6063167228e350dd132d4a1573102"
            },
             "WWE_NETWORK": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/2603/default.mpd",
                k1: "0cbc4d3b4fbd9af512acb2488bb42910",
                k2: "30528c4ef882954e5707cd1001d66121"
            },
             "SPOTV": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/5058/default.mpd",
                k1: "c0e1804aa1d9fd9c41c41bf0f61a5f10",
                k2: "758823e4eabb6e4c8c036d073db46b8c"
            },
             "SPOTV_2": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv:443/PLTV/88888888/224/3221227608/3221227608.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawWP5a6lzyDPJ57LXeuC05Cs44sM6v4Pb96oLcepTGODErcymHBIhx5oJP4jv2fPK0%3D%3A20230206101724%3AUTC%2C1003663983%2C115.164.187.20%2C20230206101724%2Curn:Huawei:liveTV:XTV100000161%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWOy27CMBRE_8ZLK3YehIVXIKRKVahE6Laa2NcmihODHZD695A2bGfmjM4coeljr1B2dV7Zqsu1LeoS2EhRk611tu2MFYYlujVBSabhfT-5JpgF-z7tfkTGMy6l4EKydrk7eLh12dzHjqLK39iJ4qPXpEyy_IHE4Vwkh7kPE__y-D1Hv04YtauaqDZltc0KKQuZs3lJW6Th1bAL0i6MV0Qyn8H9AcrCJ2JX6AGOGoykprv3_9wxmpfNEzpVq7L0AAAA&tenantId=6001",
                k1: "7de0fa3c35f52f8a8517f1600dd11ed7",
                k2: "2d59cf94d10020aeee01a97cd0716eea"
            },
            "SPOTV_3": {
                url: "https://atemecdnbalancer-voe.sysln.id/live/eds/SPOTVHD/mpd/SPOTVHD.mpd",
                k1: "e60ece8f0d9042fcb52508055ec48e5e",
                k2: "213f438bd4961cda987d41b7f154f1e5"
            },
            "SPOTV2": {
                url: "https://atemecdnbalancer-voe.sysln.id/live/eds/SPOTV2HD/mpd/SPOTV2HD.mpd",
                k1: "e6ed3fdf6e9f491d9ead109fc0b00cfc",
                k2: "3bc6c45722eb5fa7b343de9bffc4f7c7"
            },
            "SPOTV2_2": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv:443/PLTV/88888888/224/3221227726/3221227726.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawRjfkMvdAX9TZ5I%2BbsmfrUeOV6Zn1IaYCsVySN%2F6aTU0rcymHBIhx5oJP4jv2fPK0%3D%3A20230206102855%3AUTC%2C1003663983%2C115.164.187.20%2C20230206102855%2Curn:Huawei:liveTV:XTV100000162%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWOwY6CMBiE36bHpi0I9tCTGxOTDbuJrFczhZ9KLNRt0cS3X1D2NpmZbzJTREOHD5PZwoqt0IXSXZ7JEnqWCp2WFhtlBUv0WwWjWAPv-9FVoV2w03F3loILrpTkUrF6mdt7uLVZ3QdL0WT_2JHio2_ItKnjDyQO5yI5TH0Y-bfH8yf6tcKoXq_JotwUWuSlyvOSTYtbI13nhF2QdmG4IVL7GdwLMB18InZDc4WjCgOZ8e79m_uK7fzmD_CkDoH0AAAA&tenantId=6001",
                k1: "7c67cb7de9465062c06ac94e8e065462",
                k2: "5931fc07f285ffe40eb98e130bb090f9"
            },
            "SSC1": {
                url: "https://ssc-1-enc.edgenextcdn.net/out/v1/c696e4819b55414388a1a487e8a45ca1/index.mpd",
                k1: "d84c325f36814f39bbe59080272b10c3",
                k2: "550727de4c96ef1ecff874905493580f"
            },
            "SSC2": {
                url: "https://ssc-2-enc.edgenextcdn.net/out/v1/a16db2ec338a445a82d9c541cc9293f9/index.mpd",
                k1: "8bcfc55359e24bd7ad1c5560a96ddd3c",
                k2: "b5dcf721ab522af92a9d3bf0bd55b596"
            },
            "SSC3": {
                url: "https://ssc-3-enc.edgenextcdn.net/out/v1/42e86125555242aaa2a12056832e7814/index.mpd",
                k1: "7de5dd08ad8041d586c2f16ccc9490a1",
                k2: "5e1503f3398b34f5099933fedab847ef"
            },
            "SSC4": {
                url: "https://ssc-4-enc.edgenextcdn.net/out/v1/5267ea5772874b0db24559d643eaad93/index.mpd",
                k1: "5c672f6b85a94638872d0214f7806ed4",
                k2: "bf8756fbb866ee2d5c701c2289dd8de3"
            },
            "SSC5": {
                url: "https://ssc-5-enc.edgenextcdn.net/out/v1/99289eac5a7b4319905da595afbd792b/index.mpd",
                k1: "c88b512b17ab4f6cb09eb0ff4a1056ed",
                k2: "adc08ee1c20a734972a55c9aebbd1888"
            },
            "SSC_EXTRA1": {
                url: "https://ssc-extra-1-enc.edgenextcdn.net/out/v1/647c58693f1d46af92bd7e69f17912cb/index.mpd",
                k1: "ecbc9e6fe6b145efb6658fb5cf7427f8",
                k2: "03c17e28911f71221acbc0b11f900401"
            },
            "SSC_EXTRA2": {
                url: "https://ssc-extra-2-enc.edgenextcdn.net/out/v1/8b70de2b70d447ba8a7450ba90926a2d/index.mpd",
                k1: "4d89249bd4ca4ebc9e70443265f9507d",
                k2: "cf074ffd2646c9c2f8513b47fa57bc30"
            },
            "SSC_EXTRA3": {
                url: "https://ssc-extra-3-enc.edgenextcdn.net/out/v1/8f1c6c3f05ef4284a64b342891bd85ae/index.mpd",
                k1: "98cfd6fd4812497fb24dc75f7545f2ee",
                k2: "d3006ee69e77b25939728ebf30d3180a"
            },
            "SSC_NEWS": {
                url: "https://ssc-news-enc.edgenextcdn.net/out/v1/ef466f43623c4bbaa3f905b566ec35ea/index.mpd",
                k1: "3d04975236a44f62857d181597705ee6",
                k2: "362133e9cb13189ad4fe095ced216f60"
            },
            "ESPN_NL": {
                url: "https://da-d436234320010b88000103020000000000000005.id.cdn.upcbroadband.com/wp/wp1-vxtoken-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000107_019441/_shared_05e8c13b39b3f30524c26012f903ed7f/NL_000107_019441.mpd",
                k1: "3e999e38253834baa63881ea451f2839",
                k2: "99b88d9cde1d8986decbc5985da87187"
            },
            "ESPN_NL_2": {
                url: "https://da-d436234420010b88000103020000000000000006.id.cdn.upcbroadband.com/wp/wp2-vxtoken-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000108_019561/_shared_05e8c13b39b3f30524c26012f903ed7f/NL_000108_019561.mpd",
                k1: "3e999e38253834baa63881ea451f2839",
                k2: "99b88d9cde1d8986decbc5985da87187"
            },
            "ESPN_NL_3": {
                url: "https://da-d436234320010b88000103020000000000000005.id.cdn.upcbroadband.com/wp/wp3-vxtoken-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000109_019464/_shared_05e8c13b39b3f30524c26012f903ed7f/NL_000109_019464.mpd",
                k1: "3e999e38253834baa63881ea451f2839",
                k2: "99b88d9cde1d8986decbc5985da87187"
            },
            "ESPN_NL_4": {
                url: "https://wp4-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000110_019562/_shared_05e8c13b39b3f30524c26012f903ed7f/NL_000110_019562.mpd",
                k1: "3e999e38253834baa63881ea451f2839",
                k2: "99b88d9cde1d8986decbc5985da87187"
            },
            "SKY_SPORT_1_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-1.mpd",
                k1: "96be5ca21f087c8cb1d7630457e20000",
                k2: "53cb495864a442f4b7e7df8b540e035d"
            },
            "SKY_SPORT_2_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-2.mpd",
                k1: "ef909acce1f53f5db2a1cdafd2e90000",
                k2: "aba1269d685f474fbddf97ce2b45c725"
            },
            "SKY_SPORT_3_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-3.mpd",
                k1: "79553de34321f11972a72b1e34620000",
                k2: "6f134b10fed345c8be29ab4b318ce502"
            },
            "SKY_SPORT_4_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-4.mpd",
                k1: "79553de34321f11972a72b1e34620000",
                k2: "6f134b10fed345c8be29ab4b318ce502"
            },
            "SKY_SPORT_5_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-5.mpd",
                k1: "5492033ac2dc11141cd5c1d1d7a80000",
                k2: "ed8219b7064849d385d26151c90bd306"
            },
            "SKY_SPORT_6_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-6.mpd",
                k1: "a1c36ae483b44fc78025fae101030000",
                k2: "e4ea0adb660139309ab060cfed1a9d3a"
            },
             "SKY_SPORT_7_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-7.mpd",
                k1: "e2fcb4139149486facbfa3192ae00000",
                k2: "f72cfa3a2c1b1f5575421e835ca2a59b"
            },
             "SKY_SPORT_8_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-8.mpd",
                k1: "c8997f53b7494072bdc5c8d1c5f30000",
                k2: "bde3d1054eea001d0693bb846e124e75"
            },
             "SKY_SPORT_9_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-9.mpd",
                k1: "ac3615431ccb4a14aedc75dbea7c0000",
                k2: "b50ae9ebd7274c90244989fed8061e7b"
            },
             "SKY_SPORT_SELECT_NZ": {
                url: "https://linear-s.media.skyone.co.nz/sky-sport-select.mpd",
                k1: "aea66cdd9fea4096a81c9640c22f0000",
                k2: "c6a0d6507a25539719272484c7764742"
            },
            "SKY_FOOTBALL": {
                url: "https://linear019-gb-dash1-prd-ak.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(skysportsfootball)/manifest_720-120.mpd",
                k1: "0005c37ab85893a379c1e1e5ed60fcf0",
                k2: "b60a9aa6c55026adfc3f47136ce64924"
            },
            "SKY_EPL": {
                url: "https://linear015-gb-dash1-prd-ll.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(skysportspremierleague)/manifest_720.mpd",
                k1: "00058832b1c058c3de8b5d118cc775d4",
                k2: "721345f25729d236d6bb317fce797b77"
            },
            "SKY_MAIN": {
                url: "https://linear015-gb-dash1-prd-ll.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(skysportsmainevent)/manifest_720.mpd",
                k1: "000546476256963bd054ded3b6ae5800",
                k2: "1e497068bcc078fdb2f4296bc400ca2b"
            },
            "SKY_NEWS": {
                url: "https://linear030-gb-dash1-prd-ak.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(skysportsnews)/manifest_720.mpd",
                k1: "00057bfb9cf2fc40b5ed61f9c8a41d54",
                k2: "cb9908093e35e3c3f7db06f55913cce0"
            },
            "SKY_SPORTS_F1": {
                url: "https://linear034-gb-dash1-prd-cf.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsf1)/manifest_720.mpd",
                k1: "0005c0635a06a943911f666abcef3923",
                k2: "749cae7fc7f350be6ba7400f11150ea9"
            },
            "SKY_SPORT_F1_IT": {
                url: "https://linear304-it-dash1-prd-akg0.cdn13.skycdp.com/31478/FHD/skysportf1/master.mpd",
                k1: "00366649eb2eb82ee172e1bd310e4136",
                k2: "27e85c17d97722288ffa5970389d8baf"
            },
            "SKY_SPORTS_ARENA": {
                url: "https://linear028-gb-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsarena)/manifest_720.mpd",
                k1: "00057b3ded07f870751d40e6d0fe116e",
                k2: "12ef5b135d7ac0f6fb9018b74374586a"
            },
            "SKY_SPORTS_ACTION": {
                url: "https://linear037-gb-dash1-prd-cf.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsaction)/manifest_720.mpd",
                k1: "000397ec797bffa6a7d2f5f14bf3f90b",
                k2: "644bb73f541fb127d218ddfc0fccb38f"
            },
            "SKY_SPORTS_MIX": {
                url: "https://linear036-gb-dash1-prd-cf.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsmix)/manifest_720.mpd",
                k1: "00052237a76cdb0eb5fcbccf4c16f658",
                k2: "4e42c0a0ecf6e534426fbb21525c1911"
            },
            "SKY_SPORTS_GOLF": {
                url: "https://linear034-gb-dash1-prd-cf.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsgolf)/manifest_720.mpd",
                k1: "0005f065b6b710a9d4769fb357e2027b",
                k2: "f26593b44feb0a043b1d6e090ce27a75"
            },
            "SKY_SPORTS_TENNIS": {
                url: "https://linear014-gb-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportstennis)/manifest_720.mpd",
                k1: "000364189270b77b298a752a45f5cba3",
                k2: "387bbc9ca6e34310f3581ad047272c9c"
            },
            "SKY_SPORTS_CRICKET": {
                url: "https://linear017-gb-dash1-prd-cf.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsmainevent)/manifest_720.mpd",
                k1: "000546476256963bd054ded3b6ae5800",
                k2: "1e497068bcc078fdb2f4296bc400ca2b"
            },
            "SKY_SPORTS_RACING": {
                url: "https://linear036-gb-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsracing)/manifest_720.mpd",
                k1: "00050e1ce745004e9193899c091d7aae",
                k2: "35c88cb4ab2d667b08aa082124803d39"
            },
            "SKY_SPORTS_NEWS": {
                url: "https://linear030-gb-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(skysportsnews)/manifest_720.mpd",
                k1: "00057bfb9cf2fc40b5ed61f9c8a41d54",
                k2: "cb9908093e35e3c3f7db06f55913cce0"
            },
            "BEIN_SPORTS": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv/PLTV/88888888/224/3221227927/3221227927.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawgQY43Tg5eLk6%2BKHkOBbkVIq%2FzwD5xYAe8dI3PltEQ%2BUrcymHBIhx5oJP4jv2fPK0%3D%3A20230206101746%3AUTC%2C1003663983%2C115.164.187.20%2C20230206101746%2Curn:Huawei:liveTV:XTV55456338%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWOQY_CIBSE_w1HApSqPXByY2Jiqol1r-YBD2xKi0I18d_brt25vZn5XmZMYHD_o4oNc9pVVsvSSF45raWoDCvEdBQlSpLxUUcliIEQ2sHX0c7Y73l75YwyKgSnXJBmfrcL4Jdm_ew1JlX8Y2dMr9agstnRF2QK3if0MLZxoKcA70sKS4Vgs0zjq3W5qpicJNZknN0Gcjcl5AZ5G_s7JLSH6P8A5SBkJHcwHXisoUc1PEP4csdkpzUfwVvnv_QAAAA&tenantId=6001",
                k1: "8e5c88c1ad411ce4aa1fcd3e63fa9448",
                k2: "fb4e6d3c2a444c3711477438bcc0b5fc"
            },
            "BEIN_SPORTS_2": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv:443/PLTV/88888888/224/3221227971/3221227971.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawgQY43Tg5eLk6%2BKHkOBbkVv%2FaciHRqnNnDuZfWMEk6l0rcymHBIhx5oJP4jv2fPK0%3D%3A20230206101746%3AUTC%2C1003663983%2C115.164.187.20%2C20230206101746%2Curn:Huawei:liveTV:XTV59922231%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWPQU-EMBSE_02PDX2LUA49rdnExKDJolcztI9KttC1ZTfx3wuKc3wz38vMkmD56dEMKEB1rQlDX6raNWh6TfqAinRflVZk_mqjIWERwjj7NroNez8fP1QhC0mkpCLRbe9OAX5Ptrep52QO_9iZ0320bFwe5B1ZwvvEHssYZ_ka8P2Wwh4R3O3VVFU_VE1RriItlu3aIV9WR3wiH-N0RWL3HP0vsC4JmcUV9gLPLSY28y2EP-4lubXND5_xMYT0AAAA&tenantId=6001",
                k1: "1c983e5a03b0f8adde686ef20497e2b4",
                k2: "f7b1d6556850b472f4f683519f4e41f7"
            },
            "BEIN_SPORTS_3": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv:443/PLTV/88888888/224/3221227892/3221227892.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawRjfkMvdAX9TZ5I%2BbsmfrUDhVRD65aYf%2BjyDsSSHpLfkrcymHBIhx5oJP4jv2fPK0%3D%3A20230206102855%3AUTC%2C1003663983%2C115.164.187.20%2C20230206102855%2Curn:Huawei:liveTV:XTV55456355%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWOwQ6CMBBE_6bHhpYCeuhJY2Ji0AT0atbtUomFagsm_r2ieJ2ZN3lDAKTtWjeXQmUyRcpypVCYJaIiVAmmgFlDgkV6lF5LhuBc29vSmwk7VauzSHjCpRRcSFZPdxsHdl6WY3ehoNM_VlF4tkjaxIY_IXKwNpCFofU9Pzh4HYObJ4zqWU3kRZYvE1VIpRZsmNIa4u3TsCvEle_uEMjsvP0CugEXid0Bb2CphI50Pzr34_bBfGzeA19EPPQAAAA&tenantId=6001",
                k1: "0d2418cc6a29a3516d1854ab2973f25f",
                k2: "4979b73603b430465aa4e7bbdefbc4cc"
            },
            "USA_NETWORK": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_OL1-CTR-4s/Live/channel(usa-east)/master.mpd",
                k1: "882c9f5613b43b47adc70aa968a308ce",
                k2: "de534ef8914bfe62ba3cdd6bdb9e1c04"
            },
            "BEIN_SPORTS_4_TH": {
                url: "https://pop5clustera00de07172379a62d6189.hypp.tv:443/PLTV/88888888/224/3221227937/3221227937.mpd?rrsip=web.hypp.tv:443&zoneoffset=0&servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&accountinfo=U0v281lovZMLWzqtXjPtYuOXwQCoIQRk449J%2BBUCcawRjfkMvdAX9TZ5I%2BbsmfrU7%2B8kYXzOcpo3wc%2BwgB1By0rcymHBIhx5oJP4jv2fPK0%3D%3A20230206102855%3AUTC%2C1003663983%2C115.164.187.20%2C20230206102855%2Curn:Huawei:liveTV:XTV57682031%2C1003663983%2C-1%2C0%2C1%2C%2C%2C2%2C593%2C%2C%2C2%2C1343117%2C0%2C248412%2C47562943%2C%2C%2C2%2C1%2CEND&GuardEncType=2&it=H4sIAAAAAAAAADWOwY6CMBRF_6bLpn10wC660piYTHASGbfmUR6VWKi2QDJ_P6K4vfeemzNGtHTYGRKbPMu0shsAVdu2FlDkYNtMo4RaS5boUQYDzKL33eDK0CzY-bS9SMEFB5BcAquWu71Hty7Lqa8pmuyDnSjOnSXTpJbPmDg6F8nh2IWB_3j8-41-nTCqVjWZF1-5FqoApTQbl7TCdHs27IppG_o7Rmq-g3sBpkWfiN3R3tBRiT2ZYfL-zR1j87T5B0NkEFD0AAAA&tenantId=6001",
                k1: "94663e64ef81e90a9deeb0f1993ce11c",
                k2: "9d6f78876677b543cd4e18c846aa2481"
            },
            "BEIN_SPORTS_ASTRO": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/408/default.mpd",
                k1: "1a655189ab5c49eb235308c2b1a9e710",
                k2: "3c4508af348844107f5e026a4fd6b16e "
            },
            "BEIN_SPORTS_2_ASTRO": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/5066/default.mpd",
                k1: "39c175581e237eff9559607eb9b23c10",
                k2: "5102b12aac7756c65dcb46a101d960d3"
            },
            "BEIN_SPORTS_3_ASTRO": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/2705/default.mpd",
                k1: "20c884ef8ed26b2762f8b1a78f2d1910",
                k2: "042a21bf236ca729b1e343ed6e0a6337"
            },
            "BEIN_SPORTS_RUGBY_ASTRO": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/5125/default.mpd",
                k1: "b722d956bfc6a4508cd91de689c9b810",
                k2: "7237ff08b36e13aea3d35f4f2572fa39"
            },
            "PREMIER_SPORTS_1_ASTRO": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/2601/default_primary.mpd",
                k1: "9bfeb5068725617dbad6338473da6d10",
                k2: "06577ffcc4935ba24aff4c4c9dd6846d"
            },
            "RTL_HD": {
                url: "https://pnowlive-a.akamaized.net/live/rtlhd/dash/rtlhd.mpd",
                k1: "57e48b99f3f6d4f13f5c5afdcca084ca",
                k2: "29379a5e2d3405fad2f5d9cbe92586c3"
            },
            "DAS_ERSTE": {
                url: "https://p7s1-live-001-prod.akamaized.net/28df258a/t_009/daserste-de-hd/cenc-default.mpd",
                k1: "667f821486adfa6df62b53e41fe60c65",
                k2: "be65cc2c378180153cbac97bc6ab8625"
            },
            "ZDF": {
                url: "https://p7s1-live-001-prod.akamaized.net/45371d5a/t_009/zdf-de-hd/cenc-default.mpd",
                k1: "7757d3fa8cdab673a2dd9f3ed7b41360",
                k2: "96e498b70eeecfc0164ed4e0a78e36f3"
            },
            "TIPIK": {
                url: "https://daiconnect.com/live/dash/rtbf/tipik-premium-drm-2/.mpd",
                k1: "2f794d3c19854f4fa6f0183b993b86fa",
                k2: "37077d010758ce2cb85ca46720884b01"
            },
            "SPOTV_STADIA_HD": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/dashiso/5148/default.mpd",
                k1: "e7c650ac72dcd0311411832a8271bb10",
                k2: "ea8fa43cc7102e481cd441c58b2ecb08"
            },
            "SPOTV_STADIA_2": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/dashiso/5149/default.mpd",
                k1: "f7ae1dc71cc58fb876b4e659174f9c10",
                k2: "d6739aee6c76741763992d37cc66f1b8"
            },
            "ZIGGO_SPORT_2": {
                url: "https://da-d436234620010b88000103020000000000000008.id.cdn.upcbroadband.com/wp/wp2-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000095_019371/go-dash-fhd-avc/NL_000095_019371.mpd?p=web",
                k1: "16bf72dc22743d929c4318e193408373",
                k2: "eae51a1e3904124963074cbf432c7c8e"
            }, 
            "ZIGGO_SPORT": {
                url: "https://da-d436236420010b88000103030000000000000006.id.cdn.upcbroadband.com/wp/wp7-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000014_019661/go-dash-fhd-avc/NL_000014_019661.mpd?p=web",
                k1: "0be3d503dba13fc9a9c8ad4b89f599e6",
                k2: "578c2231c526c5e9eb415411e36871bf"
            },
            "ZIGGO_SPORT_3": {
                url: "https://da-d436234920010b8800010302000000000000000b.id.cdn.upcbroadband.com/wp/wp3-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000096_019382/go-dash-fhd-avc/NL_000096_019382.mpd?p=web",
                k1: "16bf72dc22743d929c4318e193408373",
                k2: "eae51a1e3904124963074cbf432c7c8e"
            },
            "ZIGGO_4_TENNIS": {
                url: "https://da-d436236420010b88000103030000000000000006.id.cdn.upcbroadband.com/wp/wp4-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000097_019370/go-dash-fhd-avc/NL_000097_019370.mpd?p=web",
                k1: "16bf72dc22743d929c4318e193408373",
                k2: "eae51a1e3904124963074cbf432c7c8e"
            },
            "ZIGGO_SPORT_5": {
                url: "https://da-d436234420010b88000103020000000000000006.id.cdn.upcbroadband.com/wp/wp5-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000098_019255/go-dash-fhd-avc/NL_000098_019255.mpd?p=web",
                k1: "16bf72dc22743d929c4318e193408373",
                k2: "eae51a1e3904124963074cbf432c7c8e"
            },
            "ZIGGO_SPORT_6": {
                url: "https://da-d436234a20010b8800010302000000000000000c.id.cdn.upcbroadband.com/wp/wp6-anp-g05060506-hzn-nl.t1.prd.dyncdn.dmdsdp.com/live/disk1/NL_000099_019256/go-dash-fhd-avc/NL_000099_019256.mpd?p=web",
                k1: "16bf72dc22743d929c4318e193408373",
                k2: "eae51a1e3904124963074cbf432c7c8e"
            },
            "PREMIER_SPORTS_1": {
                url: "https://linear001-ie-dash1-prd-cf.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(premiersports1)/manifest_720.mpd",
                k1: "0005b3dba78ae0fe7a9288022d3b3736",
                k2: "d2827df80dd7e9243ba6b5bbda5dfa82"
            },
            "PREMIER_SPORTS_2": {
                url: "https://linear033-ie-dash1-prd-ak.cdn.skycdp.com/Content/DASH_003_720_120/Live/channel(premiersports2)/manifest_720.mpd",
                k1: "0005d61a0ac86aca28176591b21ae2d9",
                k2: "f87ad1430a7a38fd0ac248fc9a8389b1"
            },
            "ESPN_DEPORTES_USA_VPN": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/1166/dash/cenc/ESPNDHD_13667/manifest.mpd",
                k1: "be65e5985fa04a49af310f0a92a0260a",
                k2: "1acb5ff7b0dbfdf19c4dca1aabfaaa11"
            },
            "DAZN_LALIGA": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/wjgklbtvhh/out/v1/659736a1e24c40e4865a80ffd75e7de7/cenc.mpd",
                k1: "43d1c3b25207ff38b22ccfe17d302367",
                k2: "7b1f85f6e81059473b114c16a25c829a"
            },
            "LALIGA_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/dub-nitro/live/clients/dash/enc/fpndxmzw6o/out/v1/70a50b1bda944628b8e7e66ab4069419/cenc.mpd",
                k1: "fc12a94c41e0885dbea8a8d94f0a277d",
                k2: "fc045df077e7669666b1b230e9aa3901"
            },
            "TUDN_USA_VPN": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/1131/dash/cenc/TUDNUH_8283/manifest.mpd",
                k1: "85c8956b207c44a693d89984803c908b",
                k2: "8d8ff21c464506ef396356dd761f5ccd"
            },
            "SPORT_TV_1PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV1_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "SPORT_TV_2PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV2_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "SPORT_TV_3PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV3_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "SPORT_TV_4PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV4_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "SPORT_TV_5PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV5_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "SPORT_TV_6PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$SPORTTV6_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ONETORO": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$MundotoroTV_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "TV_LA_1_ES": {
                url: "https://cache3.zapitv.com/live/eds_c2/la1_4k/dash_live_enc/la1_4k.mpd",
                k1: "a3abc44525eef3b0a7af9138a9dbe34a",
                k2: "7740f8ae4223ce5ba293028f7f78f1c1"
            },
            "TRUE_PREMIER_1_IN": {
                url: "https://edge2.laotv.la/live/TSport1/index.m3u8"
            },
            "TRUE_PREMIER_2_IN": {
                url: "https://edge2.laotv.la/live/TSport2/index.m3u8"
            },
            "VSPORTS_1_NO": {
                url: "https://rikstv-live-scalstrm.telenorcdn.net/live/rikstv/644bb6e91dbc891fd422efc9/manifest.mpd",
                k1: "4d808f2b9a74536cadbd95be141888ed",
                k2: "9dd89f67b8885dc65721a8b1fbeae700"
            },
            "VSPORTS_2_NO": {
                url: "https://rikstv-live-scalstrm.telenorcdn.net/live/rikstv/644bb6e91dbc891fd422efef/manifest.mpd",
                k1: "0d3ff38c34985fdd81a37567646322b9",
                k2: "6b4504297769acefae2e50920b7c8a77"
            },
            "VSPORTS_3_NO": {
                url: "https://rikstv-live-scalstrm.telenorcdn.net/live/rikstv/644bb6ea1dbc891fd422f01e/manifest.mpd",
                k1: "fdcb8ee4623458e5832a92801fc723b1",
                k2: "634a67c44b7b7030872043df95c1a55e"
            },
            "TV2_SPORT_PREMIUM_NO": {
                url: "https://ch11-hls-live.akamaized.net/out/u/433127.mpd",
                k1: "d12e4c9dc52f4cbab7ac9b2278317e47",
                k2: "a7987e5b6ec42db68a25486e108ca9f2"
            },
            "TV2_SPORT_1_NO": {
                url: "https://rikstv-live-scalstrm.telenorcdn.net/live/rikstv/64393bf81dbc891fd41f53ac/manifest.mpd",
                k1: "0c6212056d2f51fcbf569f9a1a8517d1",
                k2: "d07b404deb7c958347d742e6d1d2f3f9"
            },
            "BEIN_XTRA_N_ES": {
                url: "https://d35j504z0x2vu2.cloudfront.net/v1/master/0bc8e8376bd8417a1b6761138aa41c26c7309312/bein-sports-xtra-en-espanol/playlist.m3u8"
            },
            "TNT_1_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/lhr-nitro/live/clients/dash/enc/wf8usag51e/out/v1/bd3b0c314fff4bb1ab4693358f3cd2d3/cenc.mpd",
                k1: "ae26845bd33038a9c0774a0981007294",
                k2: "63ac662dde310cfb4cc6f9b43b34196d"
            },
            "TNT_1_GB_2": {
                url: "https://linear001-ie-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(tntsport1)/manifest_720.mpd",
                k1: "00051ad8db73a944abe9ec83ad88987b",
                k2: "100c985696718d923c4b1289c1cf0d7d"
            },
            "TNT_2_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/lhr-nitro/live/clients/dash/enc/f0qvkrra8j/out/v1/f8fa17f087564f51aa4d5c700be43ec4/cenc.mpd",
                k1: "6d1708b185c6c4d7b37600520c7cc93c",
                k2: "1aace05f58d8edef9697fd52cb09f441"
            },
            "TNT_2_GB_2": {
                url: "https://linear014-ie-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(tntsport2)/manifest_720.mpd",
                k1: "00050654545edbcf400de7c11a3ace78",
                k2: "7fc6cab788206f4b2c10fe5225def411"
            },
            "TNT_3_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/lhr-nitro/live/clients/dash/enc/lsdasbvglv/out/v1/bb548a3626cd4708afbb94a58d71dce9/cenc.mpd",
                k1: "4e993aa8c1f295f8b94e8e9e6f6d0bfe",
                k2: "86a1ed6e96caab8eb1009fe530d2cf4f"
            },
            "TNT_3_GB_2": {
                url: "https://linear001-ie-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(tntsport3)/manifest_720.mpd",
                k1: "000540adbb30871d80550825b28bc4c3",
                k2: "402edc50e9288aadc551bceaf347a517"
            },
            "TNT_4_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/lhr-nitro/live/clients/dash/enc/i2pcjr4pe5/out/v1/912e9db56d75403b8a9ac0a719110f36/cenc.mpd",
                k1: "e31a5a81caff5d07ea2411a571fc2e59",
                k2: "96c5ef69479732ae734f962748c19729"
            },
            "TNT_4_GB_2": {
                url: "https://linear014-ie-dash1-prd-ak.cdn.skycdp.com/016a/Content/DASH_003_720_120/Live/channel(tntsport4)/manifest_720.mpd",
                k1: "0005091188d73981c2bbd51bbe4a81ab",
                k2: "2ee68af747c05c250b6a1c80abe57d2d"
            },
            "TNT_5_GB": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/lhr-nitro/live/clients/dash/enc/gesdwrdncn/out/v1/79e752f1eccd4e18b6a8904a0bc01f2d/cenc.mpd",
                k1: "60c0d9b41475e01db4ffb91ed557fbcc",
                k2: "36ee40e58948ca15e3caba8d47b8f34b"
            },
            "TV2_Sport_1_NO": {
                url: "https://live-aws-scalstrm-cdn.rikstv.no/live/rikstv/64393bf81dbc891fd41f53ac/manifest.mpd",
                k1: "0c6212056d2f51fcbf569f9a1a8517d1",
                k2: "d07b404deb7c958347d742e6d1d2f3f9"
            },
            "SBT_BR": {
                url: "https://0006-bbc.dtvott.com/dash_live_0035/manifest.mpd",
                k1: "3ad3dca103185934acff7a0e9000c112",
                k2: "3f396659d841a55cd1381e6735ecfa1d"
            },
             "CLUB_1_BE": {
                url: "https://origin2-rtlbe.live.6cloud.fr/pool_z6h2o6qd/clubrtl/rtlbesd/dash_short_cenc10_clubrtl/index.mpd",
                k1: "b53316f32fc93b51a61ba6fdf0bce6c1",
                k2: "d752d66843a48a6fed64eed8f87adc3e"
            },
            "CANALE_5_IT": {
                url: "https://live03p-seg.msf.cdn.mediaset.net/live/ch-c5/c5-dash-widevine.isml/manifest.mpd",
                k1: "00f9f3c0783536b8ce4a30a01a52e082",
                k2: "e926f7d45af4f7d154c990eae6a2d937"
            },
            "ITV1_GB": {
                url: "https://wp2-obc1112-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV09212/manifest.mpd",
                k1: "5d9937d586414096948337ac314d79c1",
                k2: "22ca2e250b729982c97209e0ff3f7e9b"
            }, 
            "ITV2_GB": {
                url: "https://wp1-obc0910-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV09214/manifest.mpd",
                k1: "cf2957d9327e42eebde873dcb48a7b7f",
                k2: "4ef5e263bbaf80d8daa9593d420d33d0"
            }, 
            "ITV3_GB": {
                url: "https://wp1-obc0910-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV00305/manifest.mpd",
                k1: "272e9f1e2c83412cab74056d9d53bab3",
                k2: "8d1e6569c78dd567db5f69c84e776285"
            }, 
            "ITV4_GB": {
                url: "https://wp1-obc0910-live-ch-prod.prod.cdn.dmdsdp.com/dash/SV00306/manifest.mpd",
                k1: "2b169fb2c3214e429b66eb2e19fcafdf",
                k2: "90a98753d8f41ad08906243230975ff1"
            }, 
            "FOX_DEPORTES_USA": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/1106/dash/cenc/FXDEPHD/manifest.mpd",
                k1: "c9231d5e7a99429382e6a5c2e588e141",
                k2: "ca08ab407ab9393a814d720f1f41c6cf"
            },
            "BandSports_BR": {
                url: "https://0055-jbc.dtvott.com/dash_live_0054/manifest.mpd?da=1&country=BR&accountType=DTH&deviceType=web",
                k1: "bd1af42db82f5a17a0d75246f25f5201",
                k2: "a9edd4e2c410923e9cbcb261102e5008"
            },
            "TV2_Sport_NO": {
                url: "https://ch11-hls-live.akamaized.net/out/u/433127.mpd",
                k1: "d12e4c9dc52f4cbab7ac9b2278317e47",
                k2: "a7987e5b6ec42db68a25486e108ca9f2"
            },
            "FUTV": {
                url: "https://cdn02.teletica.com/StreamFutv/Streamfutv04122023/playlist.m3u8",
            },
            "ITALIA_1": {
                url: "https://live03p-seg.msf.cdn.mediaset.net/live/ch-i1/i1-dash-widevine.isml/manifest.mpd",
                k1: "00f9f3c0783536b8ee91704e23b78016",
                k2: "bfd04d6f544c9cc4d35cb13ab6778587"
            },
            "CANAL_5": {
                url: "https://channel05.akamaized.net/hls/live/2033783/event01/index.m3u8",
            },
            "SPORT_PLUS_DE": {
                url: "https://ac-009.live.p7s1video.net/c5c609cf/t_009/sport1plus-de-hd/cenc-default.mpd",
                k1: "c1c11c3844b0dffdb9d9831900f1a1da",
                k2: "a2c31e15346f339ca2b47bdd8591553f"
            },
            "HRT_2": {
                url: "https://cdn1oiv.akamaized.net/hrtliveorigin/hrt2.smil/1/manifest.mpd",
                k1: "994c79af863838109e7f3503bcd2aff9",
                k2: "d2c19650ad2a2ac77a95453b941a6f0e"
            },
            "INFINITY_PLUS_1": {
                url: "https://live03p-seg.msf.cdn.mediaset.net/live/ch-u1/u1-dash-widevine.isml/manifest.mpd",
                k1: "00f9f3c0783536b832a8f0326fbdc02e",
                k2: "ade0533ba667bb7e9847d8f215f03076"
            },
            "INFINITY_PLUS": {
                url: "https://live03p-seg.msf.cdn.mediaset.net/live/ch-u2/u2-dash-widevine.isml/manifest.mpd",
                k1: "00f9f3c0783536b834b0f0c2bfee80ac",
                k2: "76b3afbf163f9c3feb6204b8fcf0ff53"
            },
            "Astro_Bola": {
                url: "https://d1fk7kbmz4il3.cloudfront.net/CH1/masterCH1.mpd",
                k1: "7481d3e3738c46768f138e208fee9076",
                k2: "e1d428c7f1ca82339a6cfa1d0757428e"
            },
            "Astro_Bola_2": {
                url: "https://d1fk7kbmz4il3.cloudfront.net/CH5/masterCH5.mpd",
                k1: "99685545491d40b493b3a4b263c7245e",
                k2: "7939e335bf8cbbd6882f9f5c9cdebe19"
            },
            "Astro_Bola_3": {
                url: "https://d1fk7kbmz4il3.cloudfront.net/CH3/masterCH3.mpd",
                k1: "ca4f5ff4e4694d54bdfdc9bd34384290",
                k2: "1100fe297146f7d024b59944f09e6d1a"
            },
            "Astro_Supersport_UHD": {
                url: "https://staging-linearjitp-playback.astro.com.my/dash-wv/linear/1601/default_primary.mpd",
                k1: "22fbef1c1cd725e9397ec16455f08210",
                k2: "7aea43cd93c24aa9834ecb4984f7fd5a"
            },
            "Astro_Sports_1": {
                url: "https://staging-linearjitp-playback.astro.com.my/dash-wv/linear/601/default.mpd",
                k1: "ead0335d60401225727a6d531e9c2710",
                k2: "1ee3b252227c5c2ec9378c833d2e14ff"
            },
            "Astro_Sports_2": {
                url: "https://d3j4fjrwclc3o8.cloudfront.net/CH4/masterCH4.mpd",
                k1: "0d6d2a1ac8d14e19b17455650770cd99",
                k2: "ff65174f8ec5d4c88e8d8a21968563cf"
            },
            "Astro_Sports_3": {
                url: "https://d3j4fjrwclc3o8.cloudfront.net/CH5/masterCH5.mpd",
                k1: "0d6d2a1ac8d14e19b17455650770cd99",
                k2: "ff65174f8ec5d4c88e8d8a21968563cf"
            },
            "Astro_cricket": {
                url: "https://psliveapp.site/ps_mpd_api/channel(astrocricket)/ps_manifest.mpd",
                k1: "03c2e0af2f8159f9f0ce9b5dbc865f10",
                k2: "cd84ed136b0cc71f8ab8cd4d4f6a2e4c"
            },
            "Astro_Sports_4": {
                url: "https://linearjitp-playback.astro.com.my/dash-wv/linear/2506/default.mpd",
                k1: "79f4028730acca9ab8b00f26158ddb10",
                k2: "91febe843c08c7cc523efd827292e40e"
            },
            "Willow": {
                url: "https://a82aivottevtad-a.akamaihd.net/IAD/fe62c1dc4e584c69b75f266179818dcd/v1/dash/746463508834/willowtvus_live_amzn1_dv_live_csid_cdba9dc9-16cb-4554-b437-aff80f005802_us-east-1_iad_dash_h264_none_stereo/live/clients/dash/enc/9qm8cdsm2s/out/v1/4494fa62448741c2820f3502f4acf742/cenc.mpd?aws.sessionId=72c5577a-bf2c-4abd-bf68-ee1dbeee5bc4&amznDtid=AOAGZA014O5RE&encoding=segmentBase",
                k1: "b20ec7907eec46e71316614ee2e81a9d",
                k2: "078e5a3f8474928fd0847b50cd99814e"
            },
            "Willow_Pro": {
                url: "https://mhdsports.nl/miniproxie.php/https://linear-novi.stvacdn.spectrum.com/LIVE/5248/bpk-tv/10364/drm/manifest.mpd",
                k1: "b9e69652984f5d3ba16ada75794c9d42",
                k2: "ba35f32093f5da7352d8aaead4712b8e"
            },
            "VSport_1": {
                url: "https://andi-cors-proxy-service-k8s.andisearch.com/https://director.streaming.telia.com/tvm-packager-prod/group1/6089c17d47a23d76645ceaf4/manifest.mpd",
                k1: "04c5eaf62cd75f2d947ab4d621f39256",
                k2: "76967598962e7a7314a2b251e9070725"
            },
            "VSport_Extra": {
                url: "https://andi-cors-proxy-service-k8s.andisearch.com/https://director.streaming.telia.com/tvm-packager-prod/group3/60ae4f5e1522bd739f6959a1/manifest.mpd",
                k1: "bc972382f04c531983b7aab6bf642ad8",
                k2: "ddfd212680eb891b755610eac5becf85"
            },
            "Vsport_Football": {
                url: "https://andi-cors-proxy-service-k8s.andisearch.com/https://director.streaming.telia.com/tvm-packager-prod/group1/60896dfd47a23d7c065cd68c/manifest.mpd",
                k1: "ce37e20374e55be6bb4d26837af27605",
                k2: "52cc532f748fcbf2b806dad4289bf84c"
            },
            "VSPORTS_ULTRA_HD": {
                url: "https://andi-cors-proxy-service-k8s.andisearch.com/https://director.streaming.telia.com/tvm-packager-prod/group3/60b76e87baa9d5ddc9262457/manifest.mpd",
                k1: "c02b1c0a644d5aa4b7176ae585c572dc",
                k2: "5a7799ea89ea65e3bac9a10684e616bc"
            },
            "VSPORTS_PREMIUM_HD": {
                url: "https://andi-cors-proxy-service-k8s.andisearch.com/https://director.streaming.telia.com/tvm-packager-prod/group1/60896c3647a23d7f115cd57a/manifest.mpd",
                k1: "eab13e69793756eda77d8d71fda90d5d",
                k2: "cd022e9bffa6a0d1523ee5d9fcda9ed4"
            },
            "TYC_International": {
                url: "https://edge-live15-hr.cvattv.com.ar/live/c3eds/TyC_Internacional/SA_Live_dash_enc/TyC_Internacional.mpd",
                k1: "58e1ebe75d944f6a98ea67b1c7c0a572",
                k2: "1c311b069dbce31ce8e62a6e7e2433eb"
            },
            "TEN_CRICKET": {
                url: "https://edge3-moblive.yuppcdn.net/drm/smil:tencricketdrm.smil/manifest.mpd",
                k1: "9872e439f21f4a299cab249c6554daa3",
                k2: "0cdfcfe0d0f1fbe100554ce3ef4c4665"
            },
            "SKY_SPORT_24_IT": {
                url: "https://linear301-it-dash1-prd.selector.skycdn.it/016a/31035/FHD/skysport24/master_stereo.mpd",
                k1: "003618ccd7be22b6367207ed8d64d505",
                k2: "36e97f29ec5ea6126077cc040cc2ceeb"
            },
            "SKY_SPORT_251_IT": {
                url: "https://linear311-it-dash1-prd-akg0.cdn13.skycdp.com/31917/FHD/skysport251/master.mpd",
                k1: "0036422cf4293ae7cf1e7f7062cc29e8",
                k2: "37a223fcc17c087043bc837432fd25d8"
            },
            "SKY_SPORT_252_IT": {
                url: "https://linear311-it-dash1-prd-akg0.cdn13.skycdp.com/32951/FHD/skysport252/master.mpd",
                k1: "003643bc9d61268c987504fa93b397f6",
                k2: "b8d5767c73ff8bba68d955035b56f4c1"
            },
            "Sky_Sport_253": {
                url: "https://linear304-it-dash1-prd-akg0.cdn13.skycdp.com/32233/FHD/skysport253/master.mpd",
                k1: "0036077996d02761a9d4c29ddfac7466",
                k2: "e83d078779ae5b53e2eb999513d55682"
            },
            "Sky_Sport_254": {
                url: "https://linear311-it-dash1-prd-akg0.cdn13.skycdp.com/31234/FHD/skysport254/master.mpd",
                k1: "00369c14c20b78aadb1ec0e3c0e74979",
                k2: "e768767e2c7238d8069887bb36aed7fa"
            },
            "Sky_Sport_255": {
                url: "https://linear304-it-dash1-prd-akg0.cdn13.skycdp.com/32910/FHD/skysport255/master.mpd",
                k1: "0036b781a22ebb0c20c16ac27d5d1448",
                k2: "f309b94acfda720bf1ed5741489f8967"
            },
            "Sky_Sport_256": {
                url: "https://linear312-it-dash1-prd-akg0.cdn13.skycdp.com/31912/FHD/skysport256/master.mpd",
                k1: "00366f263859fc1cc82d2c4da6a66ef6",
                k2: "754ae922d113c54349002cd9a88694a4"
            },
            "Sky_Sport_257": {
                url: "https://linear304-it-dash1-prd-akg0.cdn13.skycdp.com/31775/FHD/skysport257/master.mpd",
                k1: "0036faeace9872d3ceeb8b1b63f0baa3",
                k2: "dbd41ee944243307d39b7b27f16615a8"
            },
            "SKY_258_IT": {
                url: "https://linear311-it-dash1-prd-akg0.cdn13.skycdp.com/32772/skysport258/master.mpd",
                k1: "0036fd8ccfddba47c8b40aeff63a797c",
                k2: "dfd5c9d0f4ac6f3a1bd89803399e7026"
            },
            "SKY_259_IT": {
                url: "https://linear311-it-dash1-prd-akg0.cdn13.skycdp.com/31613/skysport259/master.mpd",
                k1: "0036644f7699f43e401f88d920dc385c",
                k2: "e5b0cebdc3edd7996d283041535fce9c"
            },
            "SKY_SPORT_CALCIO_IT": {
                url: "https://linear301-it-dash1-prd-akg0.cdn13.skycdp.com/31209/FHD/skysportseriea/master.mpd",
                k1: "00369a2c69176d5a2deff777247b6637",
                k2: "e122d4bad34c1e430ee349f5aac0060b"
            },
            "SKY_SPORT_MAX_IT": {
                url: "https://linear305-it-dash1-prd-ll.cdn13.skycdp.com/016a/31248/FHD/skysportmax/master.mpd",
                k1: "0036ae9248d939e4e1cd2198d2593a42",
                k2: "efc6699e1756403916b0280ea63f4c28"
            },
             "SKY_SPORT_MOTOGP_IT": {
                url: "https://linear306-it-dash1-prd.selector.skycdn.it/016a/31483/FHD/skysportmotogp/master.mpd",
                k1: "0036ea2e908d4cc20ef08595da9ff991",
                k2: "08e1ae9fa0ee4d9ec2b194c4908613ae"
            },
            "SKY_SPORT_NBA_IT": {
                url: "https://linear301-it-dash1-prd.selector.skycdn.it/016a/31764/FHD/skysportnba/master_stereo.mpd",
                k1: "0036c4e453ae2a044f4c861ed73b560a",
                k2: "ea5626c0aa092c382ca58151b5f4b208"
            },
            "SKY_SPORT_UNO_IT": {
                url: "https://linear301-it-dash1-prd.selector.skycdn.it/016a/31023/FHD/skysportuno/master.mpd",
                k1: "0036dc70e4d659fe5ae57b52793a1ff3",
                k2: "55517f806b6be917c2bf0e9cf9acc44f"
            },
            "ESPN_AR": {
                url: "https://chromecast.cvattv.com.ar/live/c3eds/ESPN2HD/SA_Live_dash_enc_2A/ESPN2HD.mpd",
                k1: "e884b711ab111beb8a7ba1e7bcbdc9bf",
                k2: "cb89ee3961599e3e648a5aad60895f34"
            },
            "ESPN_2_AR": {
                url: "https://chromecast.cvattv.com.ar/live/c6eds/ESPN2_Arg/SA_Live_dash_enc_2A/ESPN2_Arg.mpd",
                k1: "65a5bfa3c7a72dde60be9b0c7406c8fc",
                k2: "0b40ae9f78a7bac3b57ecbf72d3c081e"
            },
            "ESPN_3_AR": {
                url: "https://chromecast.cvattv.com.ar/live/c3eds/ESPN3/SA_Live_dash_enc_2A/ESPN3.mpd",
                k1: "f4c9f97e2a36feab0e5077f2b44cbc4e",
                k2: "1743cd03dfe3736b2c95da91a783af38"
            },
             "ESPN_DEPORTES": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/1166/dash/cenc/ESPNDHD_13667/manifest.mpd",
                k1: "be65e5985fa04a49af310f0a92a0260a",
                k2: "1acb5ff7b0dbfdf19c4dca1aabfaaa11"
            },
            "ESPN_EXTRA": {
                url: "https://cdn.cvattv.com.ar/live/c3eds/ESPNHD/SA_Live_dash_enc/ESPNHD.mpd",
                k1: "cc8d44406ed6bf1898ad9f7a2d64f29e",
                k2: "fb85d059687ab0fc67805806204edbdf"
            },
            "FOX_DEPORTES_USA": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/1106/dash/cenc/FXDEPHD/manifest.mpd",
                k1: "c9231d5e7a99429382e6a5c2e588e141",
                k2: "ca08ab407ab9393a814d720f1f41c6cf"
            },
            "FOX_SPORTS_1_US": {
                url: "https://linear.stvacdn.spectrum.com/LIVE/5239/bpk-tv/00700/drm/manifest.mpd",
                k1: "ff18f095bc835e8d902be9420438729e",
                k2: "bbfdc8de223e8b33144d5c718f01f58b"
            },
             "FOX_SPORTS_2_AR": {
                url: "https://chromecast.cvattv.com.ar/live/c3eds/FoxSports2HD/SA_Live_dash_enc_2A/FoxSports2HD.mpd",
                k1: "c98ddffc470fe449ae1a8d6492116976",
                k2: "5086d370e840010232cf4532b16e197f"
            },
            "FOX_SPORTS_3_AR": {
                url: "https://chromecast.cvattv.com.ar/live/c3eds/FoxSports3HD/SA_Live_dash_enc_2A/FoxSports3HD.mpd",
                k1: "55b47390cf9e4997dae6dac85e057875",
                k2: "fa39e855543c5d70f30600d59e5e4c1b"
            },
            "CRICLIFE_1": {
                url: "https://ev-fast-mpd.starzplayarabia.com/live/eds/CricLife_Women/DASH/CricLife_Women.mpd",
                k1: "e96c353e4f34c2b22daddcb0ad19c500",
                k2: "914c21c58098682994b1b411acf1047f"
            },
            "CRICLIFE_2": {
                url: "https://criclive2.starzplayarabia.com/out/v1/1b232653e5254150a60a577cc8db682f/index.mpd",
                k1: "cf671610fa53cc56b07b1d235169fc81",
                k2: "50ac62719a1205fd08c01e368e27e3d4"
            },
            "CRICLIFE_2_2": {
                url: "https://live4.shoq.com.pk/live/eds/Criclife2/DASH/Criclife2.mpd",
                k1: "4301796d6d67374043c4a43c18dff7ea",
                k2: "96a3dc8766317aa169149a604928ebb6"
            },
            "CRICLIFE_3": {
                url: "https://cricmax.starzplayarabia.com/out/v1/6a04831479eb46efaaf840eb558371ef/index.mpd",
                k1: "b6045efd2889ce05f4800e2f7ac0d3ee",
                k2: "abf072f537b8f4872be45f971ba24503"
            },
            "PTV_SPORTS": {
                url: "https://live6.shoq.com.pk/live/eds/PTV_Sports/DASH/PTV_Sports.mpd",
                k1: "9ecad6c4413f8bdc54712ce6c072a2cf",
                k2: "442df559c369bdada8ba3abe97811575"
            },
             "CRIC_BUZZ": {
                url: "https://live6.shoq.com.pk/live/eds/Criclife2/DASH/Criclife2.mpd",
                k1: "4301796d6d67374043c4a43c18dff7ea",
                k2: "96a3dc8766317aa169149a604928ebb6"
            },
            "THE_PAPARE": {
                url: "https://bpcdn.dialog.lk/bpk-tv/Ch126/output/index.mpd",
                k1: "01b1bafc996378ec0a7cb804aedca646",
                k2: "e1669c99c646fbbe4d4ade8dfe3a3963"
            },
            "AIS_SPORTS_1": {
                url: "https://ais-s.ais-vidnt.com/ais/play/origin/live/eds/TL101/DASH/TL101.mpd",
                k1: "b6045efd2889ce05f4800e2f7ac0d3ee",
                k2: "abf072f537b8f4872be45f971ba24503"
            },
            "CRICLIFE_MAX": {
                url: "https://cmaxlive.starzplayarabia.com/out/v1/bebec73ea17b40b3bd0257ad8e97b531/index.mpd",
                k1: "ec2168a420478062ec89540dad862bdd",
                k2: "d6d63d7a1391d2a89fb12e5e1c5ced01"
            },
            "STARSPORTS_1": {
                url: "https://bpcdncs2.dialog.lk/bpk-token/2aa@3n3xdna4v5ourqi4d3l0c0ph0apl5qv0kc23d4ba/GlobalManifest.mpd",
                k1: "79b340b2b5f7c3c89951daabde7cdf97",
                k2: "3e22bc39d22a7f8c3516f6b58b144668"
            },
            "STARSPORTS_HINDI": {
                url: "https://rftv.wtf/ch.mpd?id=24",
                k1: "24fe8f3887e0550db02ca596fd480175",
                k2: "79a62f3a5f3fa324f4de420d370a05b5"
            },
            "STARSPORTS_2_SD": {
                url: "https://bpcdn.dialog.lk/bpk-tv/Ch069/output/index.mpd",
                k1: "79b340b2b5f7c3c89951daabde7cdf97",
                k2: "3e22bc39d22a7f8c3516f6b58b144668"
            },
             "STARSPORTS_2_HD": {
                url: "https://rftv.wtf/ch.mpd?id=235",
                k1: "e5b99f622ea0573d94470d22b340d6c0",
                k2: "0f3c040b86b1a7f731565d71cf676401"
            },
           "STAR_SELECT_1": {
                url: "https://rftv.wtf/ch.mpd?id=246",
                k1: "c6fc677428aa54f29ffca8ae9737a1db",
                k2: "9f95277e4dc789b864d5bcb09a7431d6"
            },
            "STAR_SELECT_2": {
                url: "https://rftv.wtf/ch.mpd?id=463",
                k1: "8b95761b0dc7572e825eae11bd37cca9",
                k2: "74e598c7e140bba6cb14dd2189bc4111"
            },
            "DAZN_1_ES": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/dub-nitro/live/clients/dash/enc/bmnelo5c7a/out/v1/3ce2cdc4589f46189322bd3717c77957/cenc.mpd",
                k1: "44dd9cd370b08a868ead115fe84ecfde",
                k2: "bff19ab0a51cf14e848389b152913fd0"
            },
            "DAZN_2_ES": {
                url: "https://ottb.live.cf.ww.aiv-cdn.net/dub-nitro/live/clients/dash/enc/xnk4m9bnxt/out/v1/4ced7b7329a54652b9bb0521ed38bd4d/cenc.mpd",
                k1: "0eab5a3f3e3b4ba5d42d40ca30d17571",
                k2: "f3f061ded9b70e8160590d5802ecda6d"
            },
            "DAZN_3_ES": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/zy1ee5sshp/out/v1/bdcffa69fa3b4f3bb3569c9c73ee1c01/cenc.mpd",
                k1: "bad8efff688c0dbb3711e4a7114c22a3",
                k2: "6ba800673b20776c0c850130d45e1920"
            },
            "DAZN_4_ES": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/up7qpwch9b/out/v1/a6d5d1a1287b4893b859c2d6ccf2c65d/cenc.mpd",
                k1: "d27104d427e4f87e75b19395a9f8796b",
                k2: "723593c70e2d4c4862754398e80168f8"
            },
            "DAZN_F1": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/cqbcvgkb83/out/v1/4dbe05ecfb1540448d82d68eeebfbb1c/cenc.mpd",
                k1: "1061be12d303247426ec25e8369b2647",
                k2: "bd622b0e610295de3b0bccb850ccaaaa"
            },
            "DAZN_WOMENS_FOOTBALL": {
                url: "https://dcj-ak-livedazn.akamaized.net/dash/dazn-linear-503/stream.mpd",
                k1: "cfb5e2b73bef4f3c878f25ab86a7451f",
                k2: "0d6712bf2a84edcc93d001a9613f6fec"
            },
            "DAZN_COMBET": {
                url: "https://dcj-ak-livedazn.akamaized.net/dash/dazn-linear-502/stream.mpd",
                k1: "cfb5e2b73bef4f3c878f25ab86a7451f",
                k2: "0d6712bf2a84edcc93d001a9613f6fec"
            },
            "DAZN_FAST": {
                url: "https://dcj-ak-livedazn.akamaized.net/dash/dazn-linear-504/stream.mpd",
                k1: "cfb5e2b73bef4f3c878f25ab86a7451f",
                k2: "0d6712bf2a84edcc93d001a9613f6fec"
            },
            "DAZN_RISE": {
                url: "https://dcj-ak-livedazn.akamaized.net/dash/dazn-linear-501/stream.mpd",
                k1: "cfb5e2b73bef4f3c878f25ab86a7451f",
                k2: "0d6712bf2a84edcc93d001a9613f6fec"
            },
            "DAZN_Golf": {
                url: "https://dzn.chanox97.workers.dev/https://dcj-ak-livedazn.akamaized.net/dash/dazn-linear-505/stream.mpd",
                k1: "cfb5e2b73bef4f3c878f25ab86a7451f",
                k2: "0d6712bf2a84edcc93d001a9613f6fec"
            },
            "DAZN_3": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/zy1ee5sshp/out/v1/bdcffa69fa3b4f3bb3569c9c73ee1c01/cenc.mpd",
                k1: "bad8efff688c0dbb3711e4a7114c22a3",
                k2: "6ba800673b20776c0c850130d45e1920"
            },
            "DAZN_4": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/up7qpwch9b/out/v1/a6d5d1a1287b4893b859c2d6ccf2c65d/cenc.mpd",
                k1: "d27104d427e4f87e75b19395a9f8796b",
                k2: "723593c70e2d4c4862754398e80168f8"
            },
            "EUROSPORT_1_ES": {
                url: "https://ott.zapitv.com/live/eds_c2/eurosport_1_hd/dash_live_enc/eurosport_1_hd.mpd",
                k1: "237be8ca9383755e9f5784dd23f545eb",
                k2: "15a723773c3b3cbce295c0aed0bc71c3"
            },
            "EUROSPORT_2_ES": {
                url: "https://ott.zapitv.com/live/eds_c2/eurosport_2_hd/dash_live_enc/eurosport_2_hd.mpd",
                k1: "15382879a9bcfa6f1a04a86d5b4324e9",
                k2: "664241133368ab039dc1fb15206ba54b"
            },
             "EUROSPORT_1_UK": {
                url: "https://linear311-it-dash1-prd.selector.skycdn.it/016a/313073/FHD/eurosport/master.mpd",
                k1: "0036bb3fa7e6f2c334d7cba5c28b6caf",
                k2: "217fa35739cd68e90b2cd23322c01312"
            },
            "EUROSPORT_2_UK": {
                url: "https://linear312-it-dash1-prd.selector.skycdn.it/016a/31150/FHD/eurosport2/master.mpd",
                k1: "003670a7034342a4a07c91173818c61c",
                k2: "7b90055c1a1ea34d9090e9ebf6c4db8a"
            },
            "ELEVEN_SPORTS_1_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_1_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ELEVEN_SPORTS_2_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_2_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ELEVEN_SPORTS_3_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_3_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ELEVEN_SPORTS_4_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_4_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ELEVEN_SPORTS_5_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_5_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "ELEVEN_SPORTS_6_PT": {
                url: "https://da-d50d12b5.online.meo.pt/wp/cdn-er-vspp-cvl2.online.meo.pt/shls/LIVE$Eleven_Sports_6_HD/index.m3u8/S!d2EGSU9TX0dhEgZU.v...wEWDJ8_/Level(5242880)",
            },
            "LALIGA_HYPE": {
                url: "https://live.ll.ww.aiv-cdn.net/OTTB/dub-nitro/live/clients/dash/enc/woujvkfnmn/out/v1/141b52f08a1e4e97850219729ee48dc8/cenc.mpd",
                k1: "0b1fdeaee3ffc51e9a66cf1938d57aaf",
                k2: "28e3cb88ab7b476b81ab8aa0624c4d71"
            },
            "WILLOWHD": {
                url: "https://a85aivottevtad-a.akamaihd.net/IAD/9a5a06f862bf4af8bb1635c0f476737d/v1/dash/746463508834/willowtvus_live_amzn1_dv_live_csid_73c68b6c-b7a9-4fdf-8181-508ecf267c91_us-east-1_iad_dash_h264_none_stereo/live/clients/dash/enc/ynxucyajep/out/v1/b80e68a5257a499aa444ef4621ddf74b/cenc.mpd?aws.sessionId=ca833647-3024-4442-b5b8-950944d0684e&amznDtid=AOAGZA014O5RE&encoding=segmentBase",
                k1: "b287683646d6a6767f7a1880b9d6773c",
                k2: "5db9bffe6e7e811e49fecc8333c9eee0"
            },
            "SPORTS18_KHEL": {
                url: "https://prod-sports-hin-fa.jiocinema.com/bpk-tv/Sports18_Khel_voot_MOB/Fallback/index.m3u8",
                k1: "8fa2127117f754ab9a74fb6be7949429",
                k2: "8797d5178620c79676ffccec41d2d3f6"
            },
             "SPORTS18_HD": {
                url: "https://jiolivestreaming.akamaized.net/bpk-tv/Sports18_1_HD_voot_MOB/output/index.mpd",
                k1: "d86185f50f5952589c280167ee8e45c5",
                k2: "6bff81346539e4bcc9abdb351f1c855e"
            },
             "CANALE_5_ITALY": {
                url: "https://live03p-seg.msf.cdn.mediaset.net/live/ch-c5/c5-dash-widevine.isml/manifest.mpd",
                k1: "00f9f3c0783536b8ce4a30a01a52e082",
                k2: "e926f7d45af4f7d154c990eae6a2d937"
            },
            "EUROSPORT_1_ITALY": {
                url: "https://linear301-it-dash1-prd-akg0.cdn13.skycdp.com/313073/FHD/eurosport/master.mpd",
                k1: "0036bb3fa7e6f2c334d7cba5c28b6caf",
                k2: "217fa35739cd68e90b2cd23322c01312"
            },
            "EUROSPORT_2_ITALY": {
                url: "https://linear301-it-dash1-prd-akg0.cdn13.skycdp.com/31150/FHD/eurosport2/master.mpd",
                k1: "003670a7034342a4a07c91173818c61c",
                k2: "7b90055c1a1ea34d9090e9ebf6c4db8a"
            },
            "ESPN_PREMIUM": {
                url: "https://clbpktstvdash-3.clarovideo.com/bpk-tv/FOXSPORTS1HD/dash_fk/index.mpd",
                k1: "93195148e6b1f97cdd31224d04db2e0d",
                k2: "dd7fcfad44d7e498daf1f5cb8c09d5e3"
            },
            "NBC_USA": {
                url: "https://fsly.stream.peacocktv.com/Content/CMAF_OL1-CTR-4s/Live/channel(knbc)/master.mpd",
                k1: "0045a118e231f1326bcdb45350b1ceaa",
                k2: "8c13afbfa54ea37a368b8b859021f6e3"
            },
            "NBC_GOLF": {
                url: "https://nrfkcdedge03.national-linear-ddtc-tve.tve.cox.net/GOLFD_HD_CX_DDTVE_61854_0_7746784456702405163.mpd",
                k1: "1ee2468acaaacb9ce2e99440231e7c36",
                k2: "2b090882f9d500aea436ab5aa12705c4"
            },
            "NBC_GOLF_2": {
                url: "https://live-oneapp-prd-news.akamaized.net/Content/CMAF_OL1-CTR-4s/Live/channel(golf)/master.mpd",
                k1: "d5c9203447ab38c5bf5b407cdd9de5e8",
                k2: "501464dfa2ac437098c35e1c4f16bb6b"
            },
            "TV_LA_1_ES": {
                url: "https://emt-fastly.live.pv-cdn.net/IAD/7a77200bf98444ac997a89ed83775793/v1/dash/487368008139/imdbtv_amzn1_dv_live_csid_d3b87ee1-7932-4dbc-96c9-7ed1e76d5229_us-east-1_iad_dash_h264_none_stereo/live/clients/dash/enc/f60kqesunw/out/v1/a435ed7a00f947deb4369b46d8f2fb70/cenc.mpd?aws.sessionId=ebdc7699-6e7a-4152-9bd0-29759a7cd793&amznDtid=AOAGZA014O5RE&encoding=segmentBase",
                k1: "1779c27b9d077a3ba0c9cc1bb9a94b9f",
                k2: "cc5cf3b7928fb9e0a1ee6a8b566f0a8e"
            },
            "FUBO_SPORTS": {
                url: "https://abm5x5xaaaaaaaamjgudev5k44qb3.otte.live.cf.ww.aiv-cdn.net/pdx-nitro/live/clients/dash/enc/3b7qwiqzk3/out/v1/9f14895badca43e6a716db021dcd0c31/cenc.mpd",
                k1: "dc69b6159a0f9f0a4e03b3ff91cbacd5",
                k2: "d0dcbcd7723bc40df0bf34c9c092d51f"
            },
"FUBO_SPORTS_2": {
                url: "https://abm5x5xaaaaaaaamcqsg3izt3pszd.otte.live.cf.ww.aiv-cdn.net/pdx-nitro/live/clients/dash/enc/uiffe4jhf0/out/v1/3534efafca8c4815adbb4d2e9a1fe003/cenc.mpd",
                k1: "3dcfbec0e7146928baa55210bf2cb62f",
                k2: "bc85f74f815d9be5ae1dd6defaa05135"
            },
        };

var id = getParameterByName('id');
var config = ConfiguracionCanales[id];

if (config) {
    var sources = [];

    if (config.url.includes('.m3u8')) {
        sources.push({
            file: config.url
        });
    }
    
    if (config.url.includes('.mpd') && config.k1 && config.k2) {
        sources.push({
            file: config.url,
            drm: {"clearkey": {"keyId": config.k1, "key": config.k2}}
        });
    }

 //JWWWWWW
    jwplayer("player").setup({
        playlist: [{
            sources: sources
        }],
        autostart: true,
        width: "100%", 
        height: "100%", 
        stretching: "exactfit",
        aspectratio: "16:9",
        cast: {}, 
                
        });
        }
    </script>
</body>
</html>