
    <body>
  <script src="https://use.fontawesome.com/20603b964f.js"></script>
      <script src="//content.jwplatform.com/libraries/IDzF9Zmk.js"></script>
		<script type="text/javascript">jwplayer.key = 'ypdL3Acgwp4Uh2/LDE9dYh3W/EPwDMuA2yid4ytssfI=';</script><div id="myElement"></div><script type="text/javascript">
					    jwplayer("myElement").setup({
					file: "",
          type: "hls",
         
          hlshtml: true,
                playbackRateControls: [0.75, 1, 1.25, 1.5], title: 'Watching Live DurbinLIVE', width: "100%", height: "100%", aspectratio: '16:9',repeat: 'true', autostart: true, primary: 'html5', setFullscreen: true, controls: true, showCode: true, responsive: true,

          abouttext: "DURBINLIVE", aboutlink: "", logo:

          {

            file: "http://tv.durbinlive.com/wp-content/uploads/2024/01/Durbin-2.png", link: "http://durbinlive.com/", position: "top-left", margin: "5", hide: true

          }, skin: {

            name: "glow", active: "red", inactive: "", background: ""

          }

        });
					</script>
  </div>
        
    </body>

