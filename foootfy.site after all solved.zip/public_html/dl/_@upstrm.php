<?php

// Coded by WingyCodes

function get_channels()
{
    global $APP_CONFIGS;
    $output = $old_output = array();
    $eazyCacheFile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_channels.enc";
    if(file_exists($eazyCacheFile)) {
        $eazyCacheData = @json_decode(file_get_contents($eazyCacheFile), true);
        if(isset($eazyCacheData['exp']) && isset($eazyCacheData['data']) && !empty($eazyCacheData['exp']) && !empty($eazyCacheData['data'])) {
            if(time() < $eazyCacheData['exp']) { $output = $eazyCacheData['data']; } else { $old_output = $eazyCacheData['data']; }
        }
    }
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
    if(empty($output))
    {
        $api = $APP_CONFIGS['API_BASE_URL']."24-7-channels.php";
        $fetch = getRequest($api, "");
        $return = $fetch['data'];
        if(stripos($return, '<div class="grid-item">') !== false)
        {
            $cnc = explode('<div class="grid-item">', $return);
            array_shift($cnc);
            foreach($cnc as $dnd)
            {
                $ene = explode('</a', $dnd);
                if(isset($ene[0]) && !empty($ene[0]))
                {
                    $streamID = ""; $streamTitle = trim(str_replace('"', '', str_replace("'", "", strip_tags($ene[0]))));
                    $fnf = explode('stream-', $ene[0]);
                    if(isset($fnf[1]) && stripos($fnf[1], '.php') !== false) {
                        $gng = explode('.php', $fnf[1]);
                        if(isset($gng[0]) && !empty($gng[0])) {
                            $streamID = trim(strip_tags($gng[0]));
                        }
                    }
                    if(!empty($streamID) && !empty($streamTitle)) {
                        $output[] = array("id" => $streamID, "title" => $streamTitle);
                    }
                }
            }
        }
        if(empty($output) && !empty(static__DaddyChannels())) { $output = static__DaddyChannels(); }
        if(isset($output[0])) { @file_put_contents($eazyCacheFile, json_encode(array("exp" => time() + (86400), "data" => $output))); }
    }
    if(empty($output) && !empty($old_output)){ $output = $old_output; }
    return $output;
}

function get_channel_name($id)
{
    $output = "";
    foreach(get_channels() as $gctv) {
        if(md5($id) == md5($gctv['id'])) {
            $output = $gctv['title'];
        }
    }
    return $output;
}

function get_special_event_servers($id)
{
    global $APP_CONFIGS;
    $ynb_frame = ""; $stm_title = ""; $stm_server = array(); $output = array();
    $cacheFile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_Spc-eSrv".$id.".enc";
    if(file_exists($cacheFile))
    {
        $getCache = @json_decode(file_get_contents($cacheFile), true);
        if(isset($getCache['exp']) && isset($getCache['data']) && !empty($getCache['data']) && time() < $getCache['exp']) { $output = $getCache['data']; return $output; }
        if(isset($getCache['exp']) && isset($getCache['data']) && !empty($getCache['data']) && time() > $getCache['exp']) { $old_output = $getCache['data']; }
    }
    if(empty($output))
    {
        $api = $APP_CONFIGS['API_BASE_URL']."stream/stream-".$id.".php";
        $fetch = getRequest($api, "");
        $return = $fetch['data'];
        $unb = explode('<iframe src="', $return);
        if(isset($unb[1])) {
            $onb = explode('"', $unb[1]);
            if(isset($onb[0])) { $ynb_frame = trim($onb[0]); }
        }
        if(!empty($ynb_frame))
        {
            $tuua = explode("<title>", $return);
            if(isset($tuua[1])) {
                $tuub = explode("</title", $tuua[1]);
                if(isset($tuub[0])) {
                    $tuuc = explode("-", $tuub[0]);
                    if(isset($tuuc[0]) && !empty($tuuc[0]))
                    {
                        $stm_title = trim(strip_tags($tuuc[0]));
                    }
                }
            }
            $ynb_header = array("Referer: ".$api, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
            $yfetch = getRequest($ynb_frame, $ynb_header);
            $yrespo = $yfetch['data'];
            $gnb = explode('href="', $yrespo);
            if(isset($gnb[1]))
            {
                $mh = 0;
                array_shift($gnb);
                foreach($gnb as $nnbo)
                {
                    $jrn = explode('"', $nnbo);
                    if(isset($jrn[0]) && !empty($jrn[0]))
                    {
                        $mh++;
                        $stm_server[] = array("name" => "Player ".$mh, "link" => $jrn[0]);
                    }
                }
            }
            if(isset($stm_server[0])) {
                $output = array("title" => $stm_title, "servers" => $stm_server, "stream_id" => $id);
                @file_put_contents($cacheFile, json_encode(array("exp" => time() + 3600, "data" => $output)));
            }
        }
    }
    if(empty($output) && !empty($old_output)) { $output = $old_output; }
    return $output;
}

// Coded by WingyCodes

function getChannelServers($id)
{
    global $APP_CONFIGS;
    $stm_server = $output = $old_output = $fhis = $siis = array();
    $cacheFile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_eSrv".$id.".enc";
    if(file_exists($cacheFile))
    {
        $getCache = @json_decode(file_get_contents($cacheFile), true);
        if(isset($getCache['exp']) && isset($getCache['data']) && !empty($getCache['data']) && time() < $getCache['exp']) { $output = $getCache['data']['list']; return $output; }
        if(isset($getCache['exp']) && isset($getCache['data']) && !empty($getCache['data']) && time() > $getCache['exp']) { $old_output = $getCache['data']['list']; }
    }
    //--------------------------------------------------//
    if(empty($output))
    {
        $api = $APP_CONFIGS['API_BASE_URL']."stream/stream-".$id.".php";
        $fetch = getRequest($api, "");
        $return = $fetch['data'];
        $hsif = explode('href="', $return);
        foreach($hsif as $sifh) {
            if(stripos($sifh, '</a') !== false) {
                $isfh = explode('</a', $sifh);
                if(isset($isfh[0])) {
                    $aref = $isfh[0];
                    if(stripos($aref, '/stream-') !== false && stripos($aref, 'Player') !== false && stripos($aref, 'button') !== false) {
                        $siis[] = $aref;
                    }
                }
            }
        }
        if(isset($siis[0]))
        {
            foreach($siis as $aksh)
            {
                $lak = explode('"', $aksh);
                if(isset($lak[0]) && !empty($lak[0])) { $oke_link = trim(strip_tags($lak[0])); }
                $tak = explode('">', $aksh);
                if(isset($tak[2]) && !empty($tak[2])) { $oke_name = trim(strip_tags($tak[2])); }
                if(!empty($oke_name) && !empty($oke_link)) {
                    $stm_server[] = array("name" => $oke_name, "link" => $oke_link);
                }
            }
        }
        if(isset($stm_server[0])) {
            $output = $stm_server;
            @file_put_contents($cacheFile, json_encode(array("exp" => time() + 3600, "data" => array("list" => $stm_server, "stream_id" => $id))));
        }
    }
    if(empty($output) && !empty($old_output)) { $output = $old_output; }
    return $output;
}

function get_main_iframe($id, $server)
{
    global $APP_CONFIGS;
    $output = $old_output = "";
    $dYCachefile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_ifrm".$id."-".$server.".enc";
    if(file_exists($dYCachefile))
    {
        $dYCacheData = @json_decode(file_get_contents($dYCachefile), true);
        if(isset($dYCacheData['exp']) && isset($dYCacheData['data']) && !empty($dYCacheData['exp']) && !empty($dYCacheData['data'])) {
            if(time() > $dYCacheData['exp']) { $old_output = $dYCacheData['data']; } else { $output = $dYCacheData['data']; }
        }
    }
    if(empty($output))
    {
        $apixEmbed = "";
        $getStrServers  = getChannelServers($id);
        if(empty($getStrServers)) { $getStrServers = get_special_event_servers($id); }
        if(!empty($getStrServers))
        {
            $onc_counter = $server - 1;
            if(isset($getStrServers[$onc_counter]['link'])) {
                $onc_servers = $getStrServers[$onc_counter]['link'];
                $apixEmbed = $APP_CONFIGS['API_BASE_URL'].ltrim($onc_servers, "/");
            }
            if(isset($getStrServers['servers'][$onc_counter]['link'])) {
                $onc_servers = $getStrServers['servers'][$onc_counter]['link'];
                $apixEmbed = $onc_servers;
            }
        }
        if(empty($apixEmbed)) { $apixEmbed = $APP_CONFIGS['API_BASE_URL']."stream/stream-".$id.".php"; }
        $fetch = getRequest($apixEmbed, "");
        $return = $fetch['data'];
        if(stripos($return, '<iframe src="') !== false) {
            $iii = explode('<iframe src="', $return);
            if(isset($iii[1]) && stripos($iii[1], '"') !== false) {
                $eee = explode('"', $iii[1]);
                if(isset($eee[0]) && !empty($eee[0])) { $embedo = trim($eee[0]); }
            }
        }
        if(empty($embedo)) {
            $onee = explode('<iframe class="video responsive"', $return);
            if(isset($onee[1])) {
                $ovee = explode('src="', $onee[1]);
                if(isset($ovee[1])) {
                    $ocee = explode('"', $ovee[1]);
                    if(isset($ocee[0]) && !empty($ocee[0])) { $embedo = trim($ocee[0]); }
                }
            }
        }
        if(!empty($embedo)) {
            $output = $embedo;
            @file_put_contents($dYCachefile, json_encode(array("exp" => time() + 86400,  "data" => $embedo)));
        }
    }
    if(empty($output) && !empty($old_output)){ $output = $old_output; }
    return $output;
}

function get_stream_url($id, $server)
{
    global $APP_CONFIGS;
    $output = $old_output = array();
    $dYCachefile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_lStm".$id."-".$server.".enc";
    if(file_exists($dYCachefile))
    {
        $dYCacheData = @json_decode(file_get_contents($dYCachefile), true);
        if(isset($dYCacheData['exp']) && isset($dYCacheData['data']) && !empty($dYCacheData['exp']) && !empty($dYCacheData['data'])) {
            if(time() > $dYCacheData['exp']) { $old_output = $dYCacheData['data']; } else { $output = $dYCacheData['data']; }
        }
    }
    if(empty($output))
    {
        $exReferer = ""; $exStrmURL = "";
        $aaIframe = get_main_iframe($id, $server);
        if(!empty($aaIframe))
        {
            $aaFrameReferer = getRootBase($APP_CONFIGS['API_BASE_URL'])."/";
            $aaFrameHeaders = array("Referer: ".$aaFrameReferer, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
            $wFetch = getRequest($aaIframe, $aaFrameHeaders);
            $wData = $wFetch['data']; $responx = $wFetch['data'];

            if(stripos($wData, 'iframe src="') !== false)
            {
                $nveti = explode('iframe src="', $wData);
                if(isset($nveti[1]))
                {
                    $AhWjjcwY = explode('"', $nveti[1]);
                    if(isset($AhWjjcwY[0]) && !empty($AhWjjcwY[0]))
                    {
                        $d2lAFgLP = trim(strip_tags($AhWjjcwY[0]));
                        $d2lAFgLP_head = array("Referer: ".getRootBase($aaIframe)."/", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
                        $d2fetch = getRequest($d2lAFgLP, $d2lAFgLP_head);
                        $dt3data = $d2fetch['data'];
                        $ybrdx = explode("source: '", $dt3data);
                        if(isset($ybrdx[1]))
                        {
                            $keon3 = explode("'", $ybrdx[1]);
                            if(isset($keon3[0]) && !empty($keon3[0]))
                            {
                                $urw4va3d = trim($keon3[0]);
                                if(filter_var($urw4va3d, FILTER_VALIDATE_URL))
                                {
                                    $exStrmURL = $urw4va3d;
                                    $exReferer = getRootBase($d2lAFgLP)."/";
                                }
                            }
                        }
                    }
                }
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if(empty($exStrmURL) && stripos($wData, 'fid="') !== false)
            {
                $exF = get_streamdata2($aaIframe, $wData);
                if(isset($exF['r'])) { $exReferer = $exF['r']; }
                if(isset($exF['s'])) { $exStrmURL = $exF['s']; }
            }
            if(empty($exStrmURL) && stripos($responx, "source: '") !== false) {
                $ddd = explode("source: '", $responx);
                if(isset($ddd[1]) && stripos($ddd[1], "'") !== false) {
                    $sss = explode("'", $ddd[1]);
                    if(isset($sss[0]) && !empty($sss[0])) {
                        $exStrmURL = trim($sss[0]);
                        $exReferer = getRootBase($aaIframe)."/";
                    } 
                }
            }
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //
            if(empty($exStrmURL) && stripos($wData, "server_lookup.php") !== false)
            {
                $ll__channelKey = ""; $ll_serverKey = ""; $ll__channelApi = ""; $ll__sreverLookupApi = "";

                //Extract Channel Key
                $appr = explode('var channelKey = "', $wData);
                if(isset($appr[1])) {
                    $bppr = explode('"', $appr[1]);
                    if(isset($bppr[0]) && !empty($bppr[0])) {
                        $ll__channelKey = trim($bppr[0]);
                    }
                }

                //Extract Channel Lookup API
                $cppr = explode("fetch('", $wData);
                if(isset($cppr[1])) {
                    $dppr = explode("'", $cppr[1]);
                    if(isset($dppr[0]) && !empty($dppr[0])) {
                        $ll__channelApi = trim($dppr[0]);
                    }
                }

                //Build Server Lookup Api
                if(!empty($ll__channelApi) && !empty($ll__channelKey)) {
                    $ll__serverLookupApi = getRootBase($aaIframe).$ll__channelApi.$ll__channelKey;
                }

                //Fetch Sever Channel Key
                if(!empty($ll__serverLookupApi))
                {
                    $ll__ftchChnKeyy = getRequest($ll__serverLookupApi, "");
                    $ll__ftcche = $ll__ftchChnKeyy['data'];
                    $ll__dataVCke = @json_decode($ll__ftcche, true);
                    if(isset($ll__dataVCke['server_key']) && !empty($ll__dataVCke['server_key'])) {
                        $ll_serverKey = $ll__dataVCke['server_key']; 
                    }
                }

                //Build Final Stream URL
                if(!empty($ll_serverKey))
                {
                    if(stripos($ll_serverKey, "top1/cdn") !== false)
                    {
                        $exStrmURL = "https://top1.newkso.ru/top1/cdn/".$ll__channelKey."/mono.m3u8";
                    }
                    else
                    {
                        $exStrmURL = "https://".$ll_serverKey."new.newkso.ru/".$ll_serverKey."/".$ll__channelKey."/mono.m3u8";
                    }
                }

                if(!empty($exStrmURL))
                {
                    $exReferer = getRootBase($aaIframe)."/";
                }
            }
            if(empty($exStrmURL))
            {
                $ye8n = explode(".m3u8", $wData);
                if(isset($ye8n[0])) {
                    $p19a = explode("http", $ye8n[0]);
                    $tre3 = count($p19a) - 1;
                    if(isset($p19a[$tre3]) && !empty($p19a[$tre3]))
                    {
                        $eZyl = $p19a[$tre3];
                        $est6 = 'http'.str_replace('\/', '/', $eZyl).'.m3u8';
                    }
                }
                if(filter_var($est6, FILTER_VALIDATE_URL))
                {
                    $exStrmURL = $est6;
                    $exReferer = getRootBase($aaIframe)."/";
                }
            }
        }
        if(!empty($exStrmURL) && !empty($exReferer)) {
            $output = array("referer" => $exReferer, "streamurl" => $exStrmURL);
            if(isGETParamAttached($exStrmURL)) { $dhc_exp = time() + 1800; } elseif(stripos($exStrmURL, "/hls/") !== false) { $dhc_exp = time() + 1500; } else { $dhc_exp = time() + 86400; }
            @file_put_contents($dYCachefile, json_encode(array("exp" => $dhc_exp, "data" => $output)));
        }
    }
    if(empty($output) && !empty($old_output)) { $output = $old_output; }
    return $output;
}

function get_streamdata2_JSD($url, $data)
{
    global $APP_CONFIGS;
    $output = $old_output = array();
    $dY2SCachefile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_SJSD-".md5($url).".enc";
    if(file_exists($dY2SCachefile))
    {
        $dY2SCachedata = @json_decode(file_get_contents($dY2SCachefile), true);
        if(isset($dY2SCachedata['exp']) && isset($dY2SCachedata['data']) && !empty($dY2SCachedata['exp']) && !empty($dY2SCachedata['data'])) {
            if(time() > $dY2SCachedata['exp']) { $old_output = $dY2SCachedata['data']; } else { $output = $dY2SCachedata['data']; }
        }
    }
    if(empty($output))
    {
        $jsApi = ""; $jsEmbed = "";  $jsReferer = "";
        $ale = explode('fid="', $data);
        if(isset($ale[1])) {
            $ble = explode('"', $ale[1]);
            if(isset($ble[0]) && !empty($ble[0])) { $chnID = trim($ble[0]); }
            //---_---_---_---_---_---_---_---_---_---//
            $cle = explode('src="', $ale[1]);
            if(isset($cle[1])) {
                $dle = explode('"', $cle[1]);
                if(isset($dle[0]) && !empty($dle[0])) {
                    $jsApi = trim($dle[0]);
                    if(stripos($jsApi, "http") === false){ $jsApi = "http:".$jsApi; }
                }
            }
        }
        //---_---_---_---_---_---_---_---_---_---//
        if(!empty($jsApi))
        {
            $fetchJ = getRequest($jsApi, array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"));
            $dataaJ = $fetchJ['data'];
            $raad = explode('ame src="', $dataaJ);
            if(isset($raad[1])) {
                $zaad = explode('.php', $raad[1]);
                if(isset($zaad[0])) {
                    $laad = $zaad[0].".php?player=desktop&live=".$chnID;
                    if(filter_var($laad, FILTER_VALIDATE_URL)) { $jsEmbed = $laad; }
                }
            }
        }
        //---_---_---_---_---_---_---_---_---_---//
        if(!empty($jsEmbed)) {
            $jsReferer = getRootBase($jsEmbed)."/";
            $output = array("embed" => $jsEmbed, "referer" => $jsReferer);
            @file_put_contents($dY2SCachefile, json_encode(array("exp" => time() + 86400, "data" => $output)));
        }
    }
    if(empty($output) && !empty($old_output)){ $output = $old_output; }
    return $output;
}

// Coded by WingyCodes

function get_streamdata2($url, $data)
{
    global $APP_CONFIGS;
    $output = $old_output = array();
    $dYStrmCachefile = $APP_CONFIGS['APP_DATA_FOLDER']."/dY_Strm-".md5($url).".enc";
    if(file_exists($dYStrmCachefile)) {
        $dYStreamData = @json_decode(file_get_contents($dYStrmCachefile), true);
        if(isset($dYStreamData['exp']) && isset($dYStreamData['data']) && !empty($dYStreamData['exp']) && !empty($dYStreamData['data'])) {
            if(time() > $dYStreamData['exp']){ $old_output = $dYStreamData['data']; }else{ $output = $dYStreamData['data']; }
        }
    }
    //-----------------------------------//
    if(empty($output))
    {
        $emzData = get_streamdata2_JSD($url, $data);
        if(!empty($emzData))
        {
            $ZemEapi = $emzData['embed'];
            $ZemReferer = $emzData['referer'];
            $ZemHeaders = array("Referer: ".$ZemReferer, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
            $Zfetch = getRequest($ZemEapi, $ZemHeaders);
            $Zdata = $Zfetch['data'];
            if(stripos($Zdata, 'player.load({source:') !== false)
            {
                $jsFuncxN = ""; $uStreamz = "";
                $oxoa = explode('player.load({source:', $Zdata);
                if(isset($oxoa[1])) {
                    $oxob = explode(',', $oxoa[1]);
                    if(isset($oxob[0])) { $jsFuncxN = trim($oxob[0]); }
                }
                if(!empty($jsFuncxN)) {
                    $oxoc = explode('function '.$jsFuncxN, $Zdata);
                    if(isset($oxoc[1])) {
                        $oxod = explode('return([', $oxoc[1]);
                        if(isset($oxod[1])) {
                            $oxoe = explode('].join', $oxod[1]);
                            if(isset($oxoe[0])) {
                                $uStreamz = str_replace("////", "//", str_replace("\/", "/", str_replace(',', '', str_replace('"', '', $oxoe[0]))));
                            }
                        }
                    }
                }
            }
            if(!empty($uStreamz))
            {
                $uStreamzRef = getRootBase($emzData['embed'])."/";
                $output = array("r" => $uStreamzRef, "s" => $uStreamz);
                @file_put_contents($dYStrmCachefile, json_encode(array("exp" => time() + 1800, "data" => $output)));
            }
        }
    }
    if(empty($output) && !empty($old_output)){ $output = $old_output; }
    return $output;
}

function modifyKeyURL($url)
{
    if(stripos($url, "/hls/") !== false) { return $url; }
    $output = "";
    $pxurl = parse_url($url);
    $pxhost = $pxurl['host'];
    $bksubd = explode(".", $pxhost);
    $bksubd[0] = str_replace("2", "", $bksubd[0]);
    $nwsubd = $bksubd[0].".".$bksubd[1].".".$bksubd[2];
    $output = str_replace($pxhost, $nwsubd, $url);
    return $output;
}

function static__DaddyChannels()
{
    $d = '[{"id":"51","title":"ABC USA"},{"id":"302","title":"A&E USA"},{"id":"303","title":"AMC USA"},{"id":"304","title":"Animal Planet"},{"id":"666","title":"ACC Network USA"},{"id":"123","title":"Astro SuperSport 1"},{"id":"124","title":"Astro SuperSport 2"},{"id":"125","title":"Astro SuperSport 3"},{"id":"126","title":"Astro SuperSport 4"},{"id":"134","title":"Arena Sport 1 Premium"},{"id":"135","title":"Arena Sport 2 Premium"},{"id":"139","title":"Arena Sport 3 Premium"},{"id":"429","title":"Arena Sport 1 Serbia"},{"id":"430","title":"Arena Sport 2 Serbia"},{"id":"431","title":"Arena Sport 3 Serbia"},{"id":"581","title":"Arena Sport 4 Serbia"},{"id":"432","title":"Arena Sport 1 Croatia"},{"id":"433","title":"Arena Sport 2 Croatia"},{"id":"434","title":"Arena Sport 3 Croatia"},{"id":"580","title":"Arena Sport 4 Croatia"},{"id":"781","title":"Alkass One"},{"id":"782","title":"Alkass Two"},{"id":"783","title":"Alkass Three"},{"id":"784","title":"Alkass Four"},{"id":"785","title":"ABS-CBN"},{"id":"579","title":"Arena Sport 1 BiH"},{"id":"600","title":"Abu Dhabi Sports 1 UAE"},{"id":"601","title":"Abu Dhabi Sports 2 UAE"},{"id":"609","title":"Abu Dhabi Sports 1 Premium"},{"id":"610","title":"Abu Dhabi Sports 2 Premium"},{"id":"370","title":"Astro Cricket"},{"id":"531","title":"Antena 3 Spain"},{"id":"664","title":"ACC Network USA"},{"id":"295","title":"Adult Swim"},{"id":"717","title":"AXN Movies Portugal"},{"id":"725","title":"Arte DE"},{"id":"742","title":"AXS TV USA"},{"id":"766","title":"ABCNY USA"},{"id":"61","title":"beIN Sports MENA English 1"},{"id":"90","title":"beIN Sports MENA English 2"},{"id":"46","title":"beIN Sports MENA English 3"},{"id":"91","title":"beIN Sports MENA 1"},{"id":"92","title":"beIN Sports MENA 2"},{"id":"93","title":"beIN Sports MENA 3"},{"id":"94","title":"beIN Sports MENA 4"},{"id":"95","title":"beIN Sports MENA 5"},{"id":"96","title":"beIN Sports MENA 6"},{"id":"97","title":"beIN Sports MENA 7"},{"id":"98","title":"beIN Sports MENA Premium 1"},{"id":"99","title":"beIN Sports MENA Premium 2"},{"id":"100","title":"beIN Sports MENA Premium 3"},{"id":"494","title":"beIN Sports MAX 4 France"},{"id":"495","title":"beIN Sports MAX 5 France"},{"id":"496","title":"beIN Sports MAX 6 France"},{"id":"497","title":"beIN Sports MAX 7 France"},{"id":"498","title":"beIN Sports MAX 8 France"},{"id":"499","title":"beIN Sports MAX 9 France"},{"id":"500","title":"beIN Sports MAX 10 France"},{"id":"116","title":"beIN SPORTS 1 France"},{"id":"117","title":"beIN SPORTS 2 France"},{"id":"118","title":"beIN SPORTS 3 France"},{"id":"62","title":"beIN SPORTS 1 Turkey"},{"id":"63","title":"beIN SPORTS 2 Turkey"},{"id":"64","title":"beIN SPORTS 3 Turkey"},{"id":"67","title":"beIN SPORTS 4 Turkey"},{"id":"578","title":"BeIN Sports HD Qatar"},{"id":"425","title":"BeIN SPORTS USA"},{"id":"372","title":"beIN SPORTS en Espa単ol"},{"id":"491","title":"beIN SPORTS Australia 1"},{"id":"492","title":"beIN SPORTS Australia 2"},{"id":"493","title":"beIN SPORTS Australia 3"},{"id":"522","title":"Barca TV Spain"},{"id":"380","title":"Benfica TV PT"},{"id":"648","title":"Boomerang"},{"id":"476","title":"BNT 1 Bulgaria"},{"id":"477","title":"BNT 2 Bulgaria"},{"id":"478","title":"BNT 3 Bulgaria"},{"id":"737","title":"BR Fernsehen DE"},{"id":"479","title":"bTV Bulgaria"},{"id":"481","title":"bTV Action Bulgaria"},{"id":"484","title":"bTV Lady Bulgaria"},{"id":"305","title":"BBC America (BBCA)"},{"id":"306","title":"BET USA"},{"id":"307","title":"Bravo USA"},{"id":"349","title":"BBC News Channel HD"},{"id":"356","title":"BBC One UK"},{"id":"357","title":"BBC Two UK"},{"id":"358","title":"BBC Three UK"},{"id":"359","title":"BBC Four UK"},{"id":"397","title":"BIG TEN Network (BTN USA)"},{"id":"535","title":"Cuatro Spain"},{"id":"354","title":"Channel 4 UK"},{"id":"355","title":"Channel 5 UK"},{"id":"308","title":"CBS Sports Network (CBSSN)"},{"id":"121","title":"Canal+ France"},{"id":"122","title":"Canal+ Sport France"},{"id":"463","title":"Canal+ Foot France"},{"id":"464","title":"Canal+ Sport360"},{"id":"540","title":"Canal 11 Portugal"},{"id":"48","title":"Canal+ Sport Poland"},{"id":"73","title":"Canal+ Sport 2 Poland"},{"id":"75","title":"CANAL+ SPORT 5 Poland"},{"id":"566","title":"Canal+ Premium Poland"},{"id":"567","title":"Canal+ Family Poland"},{"id":"570","title":"Canal+ Seriale Poland"},{"id":"486","title":"Canal+ Sport 1 Afrique"},{"id":"487","title":"Canal+ Sport 2 Afrique"},{"id":"488","title":"Canal+ Sport 3 Afrique"},{"id":"489","title":"Canal+ Sport 4 Afrique"},{"id":"490","title":"Canal+ Sport 5 Afrique"},{"id":"805","title":"CANAL9 Denmark"},{"id":"89","title":"Combate Brasil"},{"id":"747","title":"C More Football Sweden"},{"id":"622","title":"Cosmote Sport 1 HD"},{"id":"623","title":"Cosmote Sport 2 HD"},{"id":"624","title":"Cosmote Sport 3 HD"},{"id":"625","title":"Cosmote Sport 4 HD"},{"id":"626","title":"Cosmote Sport 5 HD"},{"id":"627","title":"Cosmote Sport 6 HD"},{"id":"628","title":"Cosmote Sport 7 HD"},{"id":"629","title":"Cosmote Sport 8 HD"},{"id":"630","title":"Cosmote Sport 9 HD"},{"id":"546","title":"Channel 9 Israel"},{"id":"547","title":"Channel 10 Israe"},{"id":"548","title":"Channel 11 Israel"},{"id":"549","title":"Channel 12 Israel"},{"id":"551","title":"Channel 13 Israel"},{"id":"552","title":"Channel 14 Israel"},{"id":"8111","title":"C More Stars Sweden"},{"id":"812","title":"C More First Sweden"},{"id":"813","title":"C More Hits Sweden"},{"id":"814","title":"C More Series Sweden"},{"id":"748","title":"COZI TV USA"},{"id":"647","title":"CMT USA"},{"id":"52","title":"CBS USA"},{"id":"300","title":"CW USA"},{"id":"309","title":"CNBC USA"},{"id":"310","title":"Comedy Central"},{"id":"339","title":"Cartoon Network"},{"id":"345","title":"CNN USA"},{"id":"374","title":"Cinemax USA"},{"id":"602","title":"CTV Canada"},{"id":"838","title":"CTV 2 Canada"},{"id":"669","title":"Crime+ Investigation USA"},{"id":"696","title":"Comet USA"},{"id":"697","title":"Cooking Channel USA"},{"id":"715","title":"Cleo TV"},{"id":"750","title":"C SPAN 1"},{"id":"767","title":"CBSNY USA"},{"id":"831","title":"Citytv"},{"id":"832","title":"CBC CA"},{"id":"426","title":"DAZN 1 Bar DE"},{"id":"427","title":"DAZN 2 Bar DE"},{"id":"445","title":"DAZN 1 Spain"},{"id":"446","title":"DAZN 2 Spain"},{"id":"447","title":"DAZN 3 Spain"},{"id":"448","title":"DAZN 4 Spain"},{"id":"537","title":"DAZN F1 ES"},{"id":"538","title":"DAZN LaLiga"},{"id":"43","title":"DAZN LaLiga 2"},{"id":"801","title":"DR1 Denmark"},{"id":"802","title":"DR2 Denmark"},{"id":"400","title":"Digi Sport 1 Romania"},{"id":"401","title":"Digi Sport 2 Romania"},{"id":"402","title":"Digi Sport 3 Romania"},{"id":"403","title":"Digi Sport 4 Romania"},{"id":"465","title":"Diema Sport Bulgaria"},{"id":"466","title":"Diema Sport 2 Bulgaria"},{"id":"467","title":"Diema Sport 3 Bulgaria"},{"id":"482","title":"Diema Bulgaria"},{"id":"485","title":"Diema Family Bulgaria"},{"id":"604","title":"Dubai Sports 1 UAE"},{"id":"605","title":"Dubai Sports 2 UAE"},{"id":"606","title":"Dubai Sports 3 UAE"},{"id":"607","title":"Dubai Racing 1 UAE"},{"id":"608","title":"Dubai Racing 2 UAE"},{"id":"786","title":"DSTV Mzansi Magic"},{"id":"827","title":"DSTV M-Net"},{"id":"828","title":"DSTV kykNET & kie"},{"id":"311","title":"Discovery Life Channel"},{"id":"312","title":"Disney Channel"},{"id":"313","title":"Discovery Channel"},{"id":"657","title":"Discovery Family"},{"id":"314","title":"Disney XD"},{"id":"651","title":"Destination America"},{"id":"652","title":"Disney JR"},{"id":"348","title":"Dave"},{"id":"44","title":"ESPN USA"},{"id":"45","title":"ESPN2 USA"},{"id":"316","title":"ESPNU USA"},{"id":"379","title":"ESPN 1 NL"},{"id":"386","title":"ESPN 2 NL"},{"id":"71","title":"Eleven Sports 1 Poland"},{"id":"72","title":"Eleven Sports 2 Poland"},{"id":"428","title":"Eleven Sports 3 Poland"},{"id":"455","title":"Eleven Sports 1 Portugal"},{"id":"456","title":"Eleven Sports 2 Portugal"},{"id":"457","title":"Eleven Sports 3 Portugal"},{"id":"458","title":"Eleven Sports 4 Portugal"},{"id":"459","title":"Eleven Sports 5 Portugal"},{"id":"41","title":"EuroSport 1 UK"},{"id":"42","title":"EuroSport 2 UK"},{"id":"57","title":"EuroSport 1 Poland"},{"id":"58","title":"EuroSport 2 Poland"},{"id":"524","title":"EuroSport 1 Spain"},{"id":"525","title":"EuroSport 2 Spain"},{"id":"878","title":"EuroSport 1 Italy"},{"id":"879","title":"EuroSport 2 Italy"},{"id":"469","title":"Eurosport 1 Bulgaria"},{"id":"470","title":"Eurosport 2 Bulgaria"},{"id":"387","title":"ESPN Premium Argentina"},{"id":"81","title":"ESPN Brasil"},{"id":"82","title":"ESPN2 Brasil"},{"id":"83","title":"ESPN3 Brasil"},{"id":"85","title":"ESPN4 Brasil"},{"id":"149","title":"ESPN SUR"},{"id":"150","title":"ESPN2 SUR"},{"id":"375","title":"ESPN Deportes"},{"id":"288","title":"ESPNews"},{"id":"315","title":"E! Entertainment Television"},{"id":"363","title":"E4 Channel"},{"id":"39","title":"Fox Sports 1 USA"},{"id":"758","title":"Fox Sports 2 USA"},{"id":"756","title":"FOX Soccer Plus"},{"id":"369","title":"Fox Cricket"},{"id":"643","title":"FOX Deportes USA"},{"id":"820","title":"FOX Sports 502 AU"},{"id":"821","title":"FOX Sports 503 AU"},{"id":"822","title":"FOX Sports 504 AU"},{"id":"823","title":"FOX Sports 505 AU"},{"id":"824","title":"FOX Sports 506 AU"},{"id":"825","title":"FOX Sports 507 AU"},{"id":"767","title":"Fox Sports Argentina"},{"id":"788","title":"Fox Sports 2 Argentina"},{"id":"789","title":"Fox Sports 3 Argentina"},{"id":"830","title":"Fox Sports Premium MX"},{"id":"568","title":"FilmBox Premium Poland"},{"id":"757","title":"Fight Network"},{"id":"297","title":"Fox Business"},{"id":"483","title":"FOX HD Bulgaria"},{"id":"54","title":"FOX USA"},{"id":"317","title":"FX USA"},{"id":"298","title":"FXX USA"},{"id":"301","title":"Freeform"},{"id":"347","title":"Fox News"},{"id":"381","title":"FX Movie Channel"},{"id":"665","title":"FYI"},{"id":"688","title":"Film4 UK"},{"id":"744","title":"Fashion TV"},{"id":"751","title":"FETV - Family Entertainment Television"},{"id":"768","title":"FOXNY USA"},{"id":"775","title":"Fox Weather Channel"},{"id":"530","title":"GOL PLAY Spain"},{"id":"318","title":"GOLF Channel USA"},{"id":"319","title":"Game Show Network"},{"id":"292","title":"Gol Mundial 1"},{"id":"687","title":"Gold UK"},{"id":"743","title":"Galavisi贸n USA"},{"id":"699","title":"CBC CA"},{"id":"752","title":"Grit Channel"},{"id":"760","title":"Globo SP"},{"id":"761","title":"Globo RIO"},{"id":"836","title":"Global CA"},{"id":"320","title":"The Hallmark Channel"},{"id":"296","title":"Hallmark Movies & Mysterie"},{"id":"321","title":"HBO USA"},{"id":"689","title":"HBO2 USA"},{"id":"690","title":"HBO Comedy USA"},{"id":"691","title":"HBO Family USA"},{"id":"692","title":"HBO Latino USA"},{"id":"693","title":"HBO Signature USA"},{"id":"694","title":"HBO Zone USA"},{"id":"569","title":"HBO Poland"},{"id":"322","title":"History USA"},{"id":"323","title":"Headline News"},{"id":"382","title":"HGTV"},{"id":"553","title":"HOT3 Israel"},{"id":"740","title":"HR Fernsehen DE"},{"id":"350","title":"ITV 1 UK"},{"id":"351","title":"ITV 2 UK"},{"id":"352","title":"ITV 3 UK"},{"id":"353","title":"ITV 4 UK"},{"id":"854","title":"Italia 1 Italy"},{"id":"324","title":"Investigation Discovery (ID USA)"},{"id":"325","title":"ION USA"},{"id":"656","title":"IFC TV USA"},{"id":"803","title":"Kanal 4 Denmark"},{"id":"804","title":"Kanal 5 Denmark"},{"id":"731","title":"Kabel Eins (Kabel 1) DE"},{"id":"539","title":"LaLiga SmartBank TV"},{"id":"645","title":"LEquipe France"},{"id":"534","title":"La Sexta Spain"},{"id":"826","title":"Liverpool TV (LFC TV)"},{"id":"326","title":"Lifetime Network"},{"id":"389","title":"Lifetime Movies Network"},{"id":"667","title":"Longhorn Network USA"},{"id":"855","title":"La7 Italy"},{"id":"856","title":"LA7d HD+ Italy"},{"id":"136","title":"Match Football 1 Russia"},{"id":"137","title":"Match Football 2 Russia"},{"id":"138","title":"Match Football 3 Russia"},{"id":"573","title":"Match Premier Russia"},{"id":"127","title":"Match TV Russia"},{"id":"395","title":"МАТЧ! БОЕЦ Russia"},{"id":"84","title":"Movistar Laliga"},{"id":"435","title":"Movistar Liga de Campeones"},{"id":"436","title":"Movistar Deportes Spain"},{"id":"438","title":"Movistar Deportes 2 Spain"},{"id":"526","title":"Movistar Deportes 3 Spain"},{"id":"527","title":"Movistar Deportes 4 Spain"},{"id":"528","title":"Movistar Golf Spain"},{"id":"563","title":"Motowizja Poland"},{"id":"765","title":"MSG USA"},{"id":"327","title":"MSNBC"},{"id":"299","title":"Magnolia Network"},{"id":"367","title":"MTV UK"},{"id":"371","title":"MTV USA"},{"id":"377","title":"MUTV UK"},{"id":"646","title":"MAVTV USA"},{"id":"779","title":"Max Sport 1 Croatia"},{"id":"780","title":"Max Sport 2 Croatia"},{"id":"770","title":"Marquee Sports Network"},{"id":"472","title":"Max Sport 1 Bulgaria"},{"id":"473","title":"Max Sport 2 Bulgaria"},{"id":"474","title":"Max Sport 3 Bulgaria"},{"id":"475","title":"Max Sport 4 Bulgaria"},{"id":"399","title":"MLB Network USA"},{"id":"829","title":"MASN USA"},{"id":"654","title":"MY9TV USA"},{"id":"661","title":"Motor Trend"},{"id":"662","title":"METV USA"},{"id":"733","title":"MDR DE"},{"id":"749","title":"Mundotoro TV Spain"},{"id":"806","title":"MTV Denmark"},{"id":"663","title":"NHL Network USA"},{"id":"468","title":"Nova Sport Bulgaria"},{"id":"582","title":"Nova Sport Serbia"},{"id":"631","title":"Nova Sports 1 Greece"},{"id":"632","title":"Nova Sports 2 Greece"},{"id":"633","title":"Nova Sports 3 Greece"},{"id":"634","title":"Nova Sports 4 Greece"},{"id":"635","title":"Nova Sports 5 Greece"},{"id":"636","title":"Nova Sports 6 Greece"},{"id":"599","title":"Nova Sports Premier League Greece"},{"id":"637","title":"Nova Sports Start Greece"},{"id":"638","title":"Nova Sports Prime Greece"},{"id":"639","title":"Nova Sports News Greece"},{"id":"762","title":"NESN USA"},{"id":"53","title":"NBC USA"},{"id":"404","title":"NBA TV USA"},{"id":"776","title":"NBC Sports Chicago"},{"id":"777","title":"NBC Sports Philadelphia"},{"id":"778","title":"NBC Sports Washington"},{"id":"405","title":"NFL Network"},{"id":"753","title":"NBC Sports Bay Area"},{"id":"754","title":"NBC Sports Boston"},{"id":"755","title":"NBC Sports California"},{"id":"769","title":"NBCNY USA"},{"id":"480","title":"Nova TV Bulgaria"},{"id":"328","title":"National Geographic (NGC)"},{"id":"329","title":"NICK JR"},{"id":"330","title":"NICK"},{"id":"666","title":"Nick Music"},{"id":"649","title":"Nicktoons"},{"id":"736","title":"NDR DE"},{"id":"292","title":"NewsNation USA"},{"id":"613","title":"Newsmax USA"},{"id":"745","title":"Nat Geo Wild USA"},{"id":"835","title":"Noovo CA"},{"id":"771","title":"New! CWPIX 11"},{"id":"611","title":"OnTime Sports"},{"id":"612","title":"OnTime Sports 2"},{"id":"541","title":"ONE 1 HD Israel"},{"id":"542","title":"ONE 2 HD Israel"},{"id":"439","title":"Orange Sport 1 Romania"},{"id":"440","title":"Orange Sport 2 Romania"},{"id":"441","title":"Orange Sport 3 Romania"},{"id":"442","title":"Orange Sport 4 Romania"},{"id":"331","title":"Oprah Winfrey Network (OWN)"},{"id":"332","title":"Oxygen True Crime"},{"id":"562","title":"Polsat Poland"},{"id":"47","title":"Polsat Sport Poland"},{"id":"50","title":"Polsat Sport Extra Poland"},{"id":"129","title":"Polsat Sport News Poland"},{"id":"443","title":"Polsat News Poland"},{"id":"564","title":"Polsat Film Poland"},{"id":"718","title":"Porto Canal Portugal"},{"id":"730","title":"ProSieben (PRO7) DE"},{"id":"450","title":"PTV Sports"},{"id":"88","title":"Premier Brasil"},{"id":"583","title":"Prima Sport 1"},{"id":"584","title":"Prima Sport 2"},{"id":"585","title":"Prima Sport 3"},{"id":"586","title":"Prima Sport 4"},{"id":"334","title":"Paramount Network"},{"id":"653","title":"POP TV USA"},{"id":"364","title":"RTE 1"},{"id":"365","title":"RTE 2"},{"id":"119","title":"RMC Sport 1 France"},{"id":"120","title":"RMC Sport 2 France"},{"id":"719","title":"RTP 1 Portugal"},{"id":"720","title":"RTP 2 Portugal"},{"id":"721","title":"RTP 3 Portugal"},{"id":"850","title":"Rai 1 Italy"},{"id":"851","title":"Rai 2 Italy"},{"id":"852","title":"Rai 3 Italy"},{"id":"853","title":"Rai 3 Italy"},{"id":"882","title":"Rai Sport Italy"},{"id":"858","title":"Rai Premium Italy"},{"id":"523","title":"Real Madrid TV Spain"},{"id":"839","title":"RDS CA"},{"id":"840","title":"RDS 2 CA"},{"id":"841","title":"RDS Info CA"},{"id":"471","title":"Ring Bulgaria"},{"id":"390","title":"RTL7 Netherland"},{"id":"555","title":"Racing Tv UK"},{"id":"293","title":"Reelz Channel"},{"id":"35","title":"Sky Sports Football UK"},{"id":"36","title":"Sky Sports Arena UK"},{"id":"37","title":"Sky Sports Action UK"},{"id":"38","title":"Sky Sports Main Event"},{"id":"130","title":"Sky sports Premier League"},{"id":"60","title":"Sky Sports F1 UK"},{"id":"65","title":"Sky Sports Cricket"},{"id":"70","title":"Sky Sports Golf UK"},{"id":"574","title":"Sky Sports Golf Italy"},{"id":"575","title":"Sky Sport MotoGP Italy"},{"id":"576","title":"Sky Sport Tennis Italy"},{"id":"577","title":"Sky Sport F1 Italy"},{"id":"366","title":"Sky Sports News UK"},{"id":"449","title":"Sky Sports MIX UK"},{"id":"556","title":"Sky Sport Top Event DE"},{"id":"557","title":"Sky Sport Mix DE"},{"id":"558","title":"Sky Sport Bundesliga 1 HD"},{"id":"559","title":"Sky Sport Austria 1 HD"},{"id":"759","title":"SportsNet New York (SNY)"},{"id":"460","title":"Sky Sport Football Italy"},{"id":"461","title":"Sky Sport UNO Italy"},{"id":"462","title":"Sky Sport Arena Italy"},{"id":"554","title":"Sky Sports Racing UK"},{"id":"881","title":"Sky UNO Italy"},{"id":"588","title":"Sky Sport 1 NZ"},{"id":"589","title":"Sky Sport 2 NZ"},{"id":"590","title":"Sky Sport 3 NZ"},{"id":"591","title":"Sky Sport 4 NZ"},{"id":"592","title":"Sky Sport 5 NZ"},{"id":"593","title":"Sky Sport 6 NZ"},{"id":"594","title":"Sky Sport 7 NZ"},{"id":"595","title":"Sky Sport 8 NZ"},{"id":"596","title":"Sky Sport 9 NZ"},{"id":"587","title":"Sky Sport Select NZ"},{"id":"49","title":"Sport TV1 Portugal"},{"id":"74","title":"Sport TV2 Portugal"},{"id":"289","title":"Sport TV4 Portugal"},{"id":"454","title":"Sport TV3 Portugal"},{"id":"290","title":"Sport TV5 Portugal"},{"id":"291","title":"Sport TV6 Portugal"},{"id":"722","title":"SIC Portugal"},{"id":"385","title":"SEC Network USA"},{"id":"78","title":"SporTV Brasil"},{"id":"79","title":"SporTV2 Brasil"},{"id":"80","title":"SporTV3 Brasil"},{"id":"101","title":"Sport Klub 1 Serbia"},{"id":"102","title":"Sport Klub 2 Serbia"},{"id":"103","title":"Sport Klub 3 Serbia"},{"id":"104","title":"Sport Klub 4 Serbia"},{"id":"453","title":"Sport Klub HD Serbia"},{"id":"406","title":"Sportsnet Ontario"},{"id":"411","title":"Sportsnet One"},{"id":"407","title":"Sportsnet West"},{"id":"408","title":"Sportsnet East"},{"id":"409","title":"Sportsnet 360"},{"id":"410","title":"Sportsnet World"},{"id":"412","title":"SuperSport Grandstand"},{"id":"413","title":"SuperSport PSL"},{"id":"414","title":"SuperSport Premier league"},{"id":"415","title":"SuperSport LaLiga"},{"id":"416","title":"SuperSport Variety 1"},{"id":"417","title":"SuperSport Variety 2"},{"id":"418","title":"SuperSport Variety 3"},{"id":"419","title":"SuperSport Variety 4"},{"id":"420","title":"SuperSport Action"},{"id":"421","title":"SuperSport Rugby"},{"id":"422","title":"SuperSport Golf"},{"id":"423","title":"SuperSport Tennis"},{"id":"424","title":"SuperSport Motorsport"},{"id":"56","title":"Supersport Football"},{"id":"368","title":"SuperSport Cricket"},{"id":"572","title":"SuperSport MaXimo 1"},{"id":"716","title":"Sporting TV Portugal"},{"id":"571","title":"SportDigital Fussball"},{"id":"764","title":"Spectrum Sportsnet LA"},{"id":"640","title":"Sport1+ Germany"},{"id":"641","title":"Sport1 Germany"},{"id":"670","title":"S4C UK"},{"id":"729","title":"SAT.1 DE"},{"id":"671","title":"Sky Cinema Premiere UK"},{"id":"672","title":"Sky Cinema Select UK"},{"id":"673","title":"Sky Cinema Hits UK"},{"id":"674","title":"Sky Cinema Greats UK"},{"id":"675","title":"Sky Cinema Animation UK"},{"id":"676","title":"Sky Cinema Family UK"},{"id":"677","title":"Sky Cinema Action UK"},{"id":"678","title":"The Hallmark"},{"id":"679","title":"Sky Cinema Thriller UK"},{"id":"680","title":"The Hallmark"},{"id":"681","title":"Sky Cinema Sci-Fi Horror UK"},{"id":"859","title":"Sky Cinema Collection Italy"},{"id":"860","title":"Sky Cinema Uno Italy"},{"id":"861","title":"Sky Cinema Action Italy"},{"id":"862","title":"8Sky Cinema Comedy Italy"},{"id":"863","title":"Sky Cinema Uno +24 Italy"},{"id":"864","title":"Sky Cinema Romance Italy"},{"id":"865","title":"Sky Cinema Family Italy"},{"id":"866","title":"Sky Cinema Due +24 Italy"},{"id":"867","title":"Sky Cinema Drama Italy"},{"id":"868","title":"8Sky Cinema Suspense Italy"},{"id":"869","title":"Sky Sport 24 Italy"},{"id":"870","title":"Sky Sport Calcio Italy"},{"id":"871","title":"Sky Calcio 1 (251) Italy"},{"id":"872","title":"Sky Calcio 2 (252) Italy"},{"id":"873","title":"Sky Calcio 3 (253) Italy"},{"id":"874","title":"Sky Calcio 4 (254) Italy"},{"id":"875","title":"Sky Calcio 5 (255) Italy"},{"id":"876","title":"Sky Calcio 6 (256) Italy"},{"id":"877","title":"Sky Calcio 7 (257) Italy"},{"id":"880","title":"Sky Serie Italy"},{"id":"284","title":"StarzPlay CricLife 1 HD"},{"id":"283","title":"StarzPlay CricLife 2 HD"},{"id":"282","title":"StarzPlay CricLife 3 HD"},{"id":"682","title":"Sky Showcase UK"},{"id":"683","title":"Sky Arts UK"},{"id":"684","title":"Sky Comedy UK"},{"id":"685","title":"Sky Crime"},{"id":"686","title":"Sky History"},{"id":"614","title":"SSC Sport 1"},{"id":"615","title":"SSC Sport 2"},{"id":"616","title":"SSC Sport 3"},{"id":"617","title":"SSC Sport 4"},{"id":"618","title":"SSC Sport 5"},{"id":"619","title":"SSC Sport Extra 1"},{"id":"620","title":"SSC Sport Extra 2"},{"id":"621","title":"SSC Sport Extra 3"},{"id":"140","title":"Sport 1 Israel"},{"id":"141","title":"Sport 2 Israel"},{"id":"142","title":"Sport 3 Israel"},{"id":"143","title":"Sport 4 Israel"},{"id":"144","title":"Sport 5 Israel"},{"id":"145","title":"Sport 5 PLUS Israel"},{"id":"146","title":"Sport 5 Live Israel"},{"id":"147","title":"Sport 5 Star Israel"},{"id":"148","title":"Sport 5 Gold Israel"},{"id":"294","title":"Science Channel"},{"id":"333","title":"Showtime USA"},{"id":"685","title":"Showtime SHOxBET USA"},{"id":"335","title":"Starz"},{"id":"361","title":"Sky Witness HD"},{"id":"732","title":"Sixx DE"},{"id":"362","title":"Sky Atlantic"},{"id":"373","title":"SYFY USA"},{"id":"658","title":"Sundance TV"},{"id":"735","title":"SWR DE"},{"id":"738","title":"SUPER RTL DE"},{"id":"739","title":"SR Fernsehen DE"},{"id":"601","title":"Smithsonian Channel"},{"id":"31","title":"TNT Sports 1 UK"},{"id":"32","title":"TNT Sports 2 UK"},{"id":"33","title":"TNT Sports 3 UK"},{"id":"34","title":"TNT Sports 4 UK"},{"id":"111","title":"TSN1"},{"id":"112","title":"TSN2"},{"id":"113","title":"TSN3"},{"id":"114","title":"TSN4"},{"id":"115","title":"TSN5"},{"id":"565","title":"TVN HD Poland"},{"id":"444","title":"TVN24 Poland"},{"id":"560","title":"TVP1 Poland"},{"id":"561","title":"TVP2 Poland"},{"id":"532","title":"Telecinco Spain"},{"id":"533","title":"TVE La 1 Spain"},{"id":"536","title":"TVE La 2 Spain"},{"id":"723","title":"TVI Portugal"},{"id":"724","title":"TVI Reality Portugal"},{"id":"529","title":"Teledeporte Spain (TDP)"},{"id":"746","title":"TYC Sports Argentina"},{"id":"128","title":"TVP Sport Poland"},{"id":"87","title":"TNT Brasil"},{"id":"388","title":"TNT Sports Argentina"},{"id":"642","title":"TNT Sports HD Chile"},{"id":"40","title":"Tennis Channel"},{"id":"741","title":"Ten Sports PK"},{"id":"66","title":"TUDN USA"},{"id":"131","title":"Telemundo"},{"id":"336","title":"TBS USA"},{"id":"337","title":"TLC"},{"id":"338","title":"TNT USA"},{"id":"833","title":"TVA Sports"},{"id":"834","title":"TVA Sports 2"},{"id":"340","title":"Travel Channel"},{"id":"341","title":"TruTV USA"},{"id":"342","title":"TVLAND"},{"id":"644","title":"TCM USA"},{"id":"698","title":"TMC Channel USA"},{"id":"384","title":"The Food Network"},{"id":"394","title":"The Weather Channel"},{"id":"452","title":"TVP INFO"},{"id":"650","title":"TeenNick"},{"id":"660","title":"TV ONE USA"},{"id":"807","title":"TV2 Bornholm Denmark"},{"id":"808","title":"TV2 Sport X Denmark"},{"id":"809","title":"TV3 Sport Denmark"},{"id":"810","title":"TV2 Sport Denmark"},{"id":"817","title":"TV2 Denmark"},{"id":"818","title":"TV2 Zulu"},{"id":"819","title":"TV3+ Denmark"},{"id":"842","title":"TVO CA"},{"id":"700","title":"Tennis+ 1"},{"id":"701","title":"Tennis+ 2"},{"id":"702","title":"Tennis+ 3"},{"id":"703","title":"Tennis+ 4"},{"id":"704","title":"Tennis+ 5"},{"id":"705","title":"Tennis+ 6"},{"id":"706","title":"Tennis+ 7"},{"id":"707","title":"Tennis+ 8"},{"id":"708","title":"Tennis+ 9"},{"id":"709","title":"Tennis+ 10"},{"id":"710","title":"Tennis+ 11"},{"id":"711","title":"Tennis+ 12"},{"id":"712","title":"Tennis+ 13"},{"id":"713","title":"Tennis+ 14"},{"id":"714","title":"Tennis+ 15"},{"id":"343","title":"USA Network"},{"id":"668","title":"Universal Kids USA"},{"id":"132","title":"Univision"},{"id":"133","title":"Unimas"},{"id":"451","title":"Viaplay Sports 1 UK"},{"id":"550","title":"Viaplay Sports 2 UK"},{"id":"597","title":"Viaplay Xtra UK"},{"id":"521","title":"#Vamos Spain"},{"id":"815","title":"V Film Premiere"},{"id":"816","title":"V Film Family"},{"id":"344","title":"VH1 USA"},{"id":"378","title":"Veronica NL Netherland"},{"id":"391","title":"VTV+ Uruguay"},{"id":"659","title":"VICE TV"},{"id":"346","title":"Willow Cricket"},{"id":"598","title":"Willow XTRA"},{"id":"376","title":"WWE Network"},{"id":"392","title":"Win Sports+ Columbia"},{"id":"655","title":"WETV USA"},{"id":"734","title":"WDR DE"},{"id":"763","title":"YES Network USA"},{"id":"543","title":"Yes Movies Action Israel"},{"id":"544","title":"Yes Movies Kids Israel"},{"id":"545","title":"Yes Movies Comedy Israel"},{"id":"609","title":"Yas TV UAE"},{"id":"837","title":"Yes TV CA"},{"id":"383","title":"Ziggo Sport Docu NL"},{"id":"393","title":"Ziggo Sport Select NL"},{"id":"396","title":"Ziggo Sport Racing NL"},{"id":"398","title":"Ziggo Sport Voetbal NL"},{"id":"727","title":"BBC 1 DE"},{"id":"728","title":"ZDF Info DE"},{"id":"857","title":"20 Mediaset Italy"},{"id":"800","title":"6eren Denmark"},{"id":"437","title":"#0 Spain"},{"id":"360","title":"5 USA"},{"id":"726","title":"3sat DE"},{"id":"501","title":"18+ (Player-01)"},{"id":"502","title":"18+ (Player-02)"},{"id":"503","title":"18+ (Player-03)"},{"id":"504","title":"18+ (Player-04)"},{"id":"505","title":"18+ (Player-05)"},{"id":"506","title":"18+ (Player-06)"},{"id":"507","title":"18+ (Player-07)"},{"id":"508","title":"18+ (Player-08)"},{"id":"509","title":"18+ (Player-09)"},{"id":"510","title":"18+ (Player-10)"},{"id":"511","title":"18+ (Player-11)"},{"id":"512","title":"18+ (Player-12)"},{"id":"513","title":"18+ (Player-13)"},{"id":"514","title":"18+ (Player-14)"},{"id":"515","title":"18+ (Player-15)"},{"id":"516","title":"18+ (Player-16)"},{"id":"517","title":"18+ (Player-17)"},{"id":"518","title":"18+ (Player-18)"},{"id":"519","title":"18+ (Player-19)"},{"id":"520","title":"18+ (Player-20)"},{"id":"51","title":"ABC USA"},{"id":"302","title":"A&E USA"},{"id":"303","title":"AMC USA"},{"id":"304","title":"Animal Planet"},{"id":"666","title":"ACC Network USA"},{"id":"123","title":"Astro SuperSport 1"},{"id":"124","title":"Astro SuperSport 2"},{"id":"125","title":"Astro SuperSport 3"},{"id":"126","title":"Astro SuperSport 4"},{"id":"134","title":"Arena Sport 1 Premium"},{"id":"135","title":"Arena Sport 2 Premium"},{"id":"139","title":"Arena Sport 3 Premium"},{"id":"429","title":"Arena Sport 1 Serbia"},{"id":"430","title":"Arena Sport 2 Serbia"},{"id":"431","title":"Arena Sport 3 Serbia"},{"id":"581","title":"Arena Sport 4 Serbia"},{"id":"432","title":"Arena Sport 1 Croatia"},{"id":"433","title":"Arena Sport 2 Croatia"},{"id":"434","title":"Arena Sport 3 Croatia"},{"id":"580","title":"Arena Sport 4 Croatia"},{"id":"781","title":"Alkass One"},{"id":"782","title":"Alkass Two"},{"id":"783","title":"Alkass Three"},{"id":"784","title":"Alkass Four"},{"id":"785","title":"ABS-CBN"},{"id":"579","title":"Arena Sport 1 BiH"},{"id":"600","title":"Abu Dhabi Sports 1 UAE"},{"id":"601","title":"Abu Dhabi Sports 2 UAE"},{"id":"609","title":"Abu Dhabi Sports 1 Premium"},{"id":"610","title":"Abu Dhabi Sports 2 Premium"},{"id":"370","title":"Astro Cricket"},{"id":"531","title":"Antena 3 Spain"},{"id":"664","title":"ACC Network USA"},{"id":"295","title":"Adult Swim"},{"id":"717","title":"AXN Movies Portugal"},{"id":"725","title":"Arte DE"},{"id":"742","title":"AXS TV USA"},{"id":"766","title":"ABCNY USA"},{"id":"923","title":"Altitude Sports"},{"id":"844","title":"Azteca 7 MX"},{"id":"269","title":"A Sport PK"},{"id":"61","title":"beIN Sports MENA English 1"},{"id":"90","title":"beIN Sports MENA English 2"},{"id":"46","title":"beIN Sports MENA English 3"},{"id":"91","title":"beIN Sports MENA 1"},{"id":"92","title":"beIN Sports MENA 2"},{"id":"93","title":"beIN Sports MENA 3"},{"id":"94","title":"beIN Sports MENA 4"},{"id":"95","title":"beIN Sports MENA 5"},{"id":"96","title":"beIN Sports MENA 6"},{"id":"97","title":"beIN Sports MENA 7"},{"id":"98","title":"beIN Sports MENA 8"},{"id":"99","title":"beIN Sports MENA 9"},{"id":"100","title":"beIN SPORTS XTRA 1"},{"id":"43","title":"beIN SPORTS XTRA 2"},{"id":"494","title":"beIN Sports MAX 4 France"},{"id":"495","title":"beIN Sports MAX 5 France"},{"id":"496","title":"beIN Sports MAX 6 France"},{"id":"497","title":"beIN Sports MAX 7 France"},{"id":"498","title":"beIN Sports MAX 8 France"},{"id":"499","title":"beIN Sports MAX 9 France"},{"id":"500","title":"beIN Sports MAX 10 France"},{"id":"116","title":"beIN SPORTS 1 France"},{"id":"117","title":"beIN SPORTS 2 France"},{"id":"118","title":"beIN SPORTS 3 France"},{"id":"62","title":"beIN SPORTS 1 Turkey"},{"id":"63","title":"beIN SPORTS 2 Turkey"},{"id":"64","title":"beIN SPORTS 3 Turkey"},{"id":"67","title":"beIN SPORTS 4 Turkey"},{"id":"578","title":"BeIN Sports HD Qatar"},{"id":"425","title":"BeIN SPORTS USA"},{"id":"372","title":"beIN SPORTS en Español"},{"id":"491","title":"beIN SPORTS Australia 1"},{"id":"492","title":"beIN SPORTS Australia 2"},{"id":"493","title":"beIN SPORTS Australia 3"},{"id":"522","title":"Barca TV Spain"},{"id":"380","title":"Benfica TV PT"},{"id":"890","title":"Bally Sports Arizona"},{"id":"891","title":"Bally Sports Detroit"},{"id":"892","title":"Bally Sports Florida"},{"id":"893","title":"Bally Sports Great Lakes"},{"id":"894","title":"Bally Sports Indiana"},{"id":"895","title":"Bally Sports Kansas City"},{"id":"896","title":"Bally Sports Midwest"},{"id":"897","title":"Bally Sports New Orleans"},{"id":"898","title":"Bally Sports North"},{"id":"899","title":"Bally Sports Ohio"},{"id":"900","title":"Bally Sports Oklahoma"},{"id":"901","title":"Bally Sports San Diego"},{"id":"902","title":"Bally Sports SoCal"},{"id":"903","title":"Bally Sports South"},{"id":"904","title":"Bally Sports Southeast"},{"id":"905","title":"Bally Sports Sun"},{"id":"906","title":"Bally Sports West"},{"id":"907","title":"Bally Sports Wisconsin"},{"id":"648","title":"Boomerang"},{"id":"476","title":"BNT 1 Bulgaria"},{"id":"477","title":"BNT 2 Bulgaria"},{"id":"478","title":"BNT 3 Bulgaria"},{"id":"737","title":"BR Fernsehen DE"},{"id":"479","title":"bTV Bulgaria"},{"id":"481","title":"bTV Action Bulgaria"},{"id":"484","title":"bTV Lady Bulgaria"},{"id":"305","title":"BBC America (BBCA)"},{"id":"306","title":"BET USA"},{"id":"307","title":"Bravo USA"},{"id":"349","title":"BBC News Channel HD"},{"id":"356","title":"BBC One UK"},{"id":"357","title":"BBC Two UK"},{"id":"358","title":"BBC Three UK"},{"id":"359","title":"BBC Four UK"},{"id":"397","title":"BIG TEN Network (BTN USA)"},{"id":"275","title":"Bandsports Brasil"},{"id":"535","title":"Cuatro Spain"},{"id":"354","title":"Channel 4 UK"},{"id":"355","title":"Channel 5 UK"},{"id":"308","title":"CBS Sports Network (CBSSN)"},{"id":"121","title":"Canal+ France"},{"id":"122","title":"Canal+ Sport France"},{"id":"463","title":"Canal+ Foot France"},{"id":"464","title":"Canal+ Sport360"},{"id":"271","title":"CANAL+ MotoGP France"},{"id":"273","title":"Canal+ Formula 1"},{"id":"540","title":"Canal 11 Portugal"},{"id":"48","title":"Canal+ Sport Poland"},{"id":"73","title":"Canal+ Sport 2 Poland"},{"id":"75","title":"CANAL+ SPORT 5 Poland"},{"id":"566","title":"Canal+ Premium Poland"},{"id":"567","title":"Canal+ Family Poland"},{"id":"570","title":"Canal+ Seriale Poland"},{"id":"486","title":"Canal+ Sport 1 Afrique"},{"id":"487","title":"Canal+ Sport 2 Afrique"},{"id":"488","title":"Canal+ Sport 3 Afrique"},{"id":"489","title":"Canal+ Sport 4 Afrique"},{"id":"490","title":"Canal+ Sport 5 Afrique"},{"id":"805","title":"CANAL9 Denmark"},{"id":"89","title":"Combate Brasil"},{"id":"747","title":"C More Football Sweden"},{"id":"622","title":"Cosmote Sport 1 HD"},{"id":"623","title":"Cosmote Sport 2 HD"},{"id":"624","title":"Cosmote Sport 3 HD"},{"id":"625","title":"Cosmote Sport 4 HD"},{"id":"626","title":"Cosmote Sport 5 HD"},{"id":"627","title":"Cosmote Sport 6 HD"},{"id":"628","title":"Cosmote Sport 7 HD"},{"id":"629","title":"Cosmote Sport 8 HD"},{"id":"630","title":"Cosmote Sport 9 HD"},{"id":"546","title":"Channel 9 Israel"},{"id":"547","title":"Channel 10 Israe"},{"id":"548","title":"Channel 11 Israel"},{"id":"549","title":"Channel 12 Israel"},{"id":"551","title":"Channel 13 Israel"},{"id":"552","title":"Channel 14 Israel"},{"id":"8111","title":"C More Stars Sweden"},{"id":"812","title":"C More First Sweden"},{"id":"813","title":"C More Hits Sweden"},{"id":"814","title":"C More Series Sweden"},{"id":"748","title":"COZI TV USA"},{"id":"647","title":"CMT USA"},{"id":"52","title":"CBS USA"},{"id":"300","title":"CW USA"},{"id":"280","title":"CW PIX 11 USA"},{"id":"309","title":"CNBC USA"},{"id":"310","title":"Comedy Central"},{"id":"339","title":"Cartoon Network"},{"id":"345","title":"CNN USA"},{"id":"374","title":"Cinemax USA"},{"id":"602","title":"CTV Canada"},{"id":"838","title":"CTV 2 Canada"},{"id":"669","title":"Crime+ Investigation USA"},{"id":"696","title":"Comet USA"},{"id":"697","title":"Cooking Channel USA"},{"id":"715","title":"Cleo TV"},{"id":"750","title":"C SPAN 1"},{"id":"767","title":"CBSNY USA"},{"id":"831","title":"Citytv"},{"id":"832","title":"CBC CA"},{"id":"910","title":"CBS Sports Golazo"},{"id":"790","title":"CMTV Portugal"},{"id":"911","title":"Cytavision Sports 1 Cyprus"},{"id":"912","title":"Cytavision Sports 2 Cyprus"},{"id":"913","title":"Cytavision Sports 3 Cyprus"},{"id":"914","title":"Cytavision Sports 4 Cyprus"},{"id":"915","title":"Cytavision Sports 5 Cyprus"},{"id":"916","title":"Cytavision Sports 6 Cyprus"},{"id":"917","title":"Cytavision Sports 7 Cyprus"},{"id":"281","title":"Court TV USA"},{"id":"426","title":"DAZN 1 Bar DE"},{"id":"427","title":"DAZN 2 Bar DE"},{"id":"445","title":"DAZN 1 Spain"},{"id":"446","title":"DAZN 2 Spain"},{"id":"447","title":"DAZN 3 Spain"},{"id":"448","title":"DAZN 4 Spain"},{"id":"537","title":"DAZN F1 ES"},{"id":"230","title":"DAZN 1 UK"},{"id":"538","title":"DAZN LaLiga"},{"id":"43","title":"DAZN LaLiga 2"},{"id":"801","title":"DR1 Denmark"},{"id":"802","title":"DR2 Denmark"},{"id":"400","title":"Digi Sport 1 Romania"},{"id":"401","title":"Digi Sport 2 Romania"},{"id":"402","title":"Digi Sport 3 Romania"},{"id":"403","title":"Digi Sport 4 Romania"},{"id":"465","title":"Diema Sport Bulgaria"},{"id":"466","title":"Diema Sport 2 Bulgaria"},{"id":"467","title":"Diema Sport 3 Bulgaria"},{"id":"482","title":"Diema Bulgaria"},{"id":"485","title":"Diema Family Bulgaria"},{"id":"604","title":"Dubai Sports 1 UAE"},{"id":"605","title":"Dubai Sports 2 UAE"},{"id":"606","title":"Dubai Sports 3 UAE"},{"id":"607","title":"Dubai Racing 1 UAE"},{"id":"608","title":"Dubai Racing 2 UAE"},{"id":"786","title":"DSTV Mzansi Magic"},{"id":"827","title":"DSTV M-Net"},{"id":"828","title":"DSTV kykNET & kie"},{"id":"311","title":"Discovery Life Channel"},{"id":"312","title":"Disney Channel"},{"id":"313","title":"Discovery Channel"},{"id":"657","title":"Discovery Family"},{"id":"314","title":"Disney XD"},{"id":"285","title":"Discovery Velocity CA"},{"id":"651","title":"Destination America"},{"id":"652","title":"Disney JR"},{"id":"348","title":"Dave"},{"id":"44","title":"ESPN USA"},{"id":"45","title":"ESPN2 USA"},{"id":"316","title":"ESPNU USA"},{"id":"379","title":"ESPN 1 NL"},{"id":"386","title":"ESPN 2 NL"},{"id":"71","title":"Eleven Sports 1 Poland"},{"id":"72","title":"Eleven Sports 2 Poland"},{"id":"428","title":"Eleven Sports 3 Poland"},{"id":"455","title":"Eleven Sports 1 Portugal"},{"id":"456","title":"Eleven Sports 2 Portugal"},{"id":"457","title":"Eleven Sports 3 Portugal"},{"id":"458","title":"Eleven Sports 4 Portugal"},{"id":"459","title":"Eleven Sports 5 Portugal"},{"id":"41","title":"EuroSport 1 UK"},{"id":"42","title":"EuroSport 2 UK"},{"id":"57","title":"EuroSport 1 Poland"},{"id":"58","title":"EuroSport 2 Poland"},{"id":"774","title":"ERT 1 Greece"},{"id":"524","title":"EuroSport 1 Spain"},{"id":"525","title":"EuroSport 2 Spain"},{"id":"878","title":"EuroSport 1 Italy"},{"id":"879","title":"EuroSport 2 Italy"},{"id":"469","title":"Eurosport 1 Bulgaria"},{"id":"470","title":"Eurosport 2 Bulgaria"},{"id":"772","title":"Eurosport 1 France"},{"id":"773","title":"Eurosport 2 France"},{"id":"387","title":"ESPN Premium Argentina"},{"id":"798","title":"ESPN Extra Argentina"},{"id":"81","title":"ESPN Brasil"},{"id":"82","title":"ESPN2 Brasil"},{"id":"83","title":"ESPN3 Brasil"},{"id":"85","title":"ESPN4 Brasil"},{"id":"149","title":"ESPN SUR"},{"id":"150","title":"ESPN2 SUR"},{"id":"375","title":"ESPN Deportes"},{"id":"288","title":"ESPNews"},{"id":"315","title":"E! Entertainment Television"},{"id":"363","title":"E4 Channel"},{"id":"39","title":"Fox Sports 1 USA"},{"id":"758","title":"Fox Sports 2 USA"},{"id":"756","title":"FOX Soccer Plus"},{"id":"369","title":"Fox Cricket"},{"id":"643","title":"FOX Deportes USA"},{"id":"820","title":"FOX Sports 502 AU"},{"id":"821","title":"FOX Sports 503 AU"},{"id":"822","title":"FOX Sports 504 AU"},{"id":"823","title":"FOX Sports 505 AU"},{"id":"824","title":"FOX Sports 506 AU"},{"id":"825","title":"FOX Sports 507 AU"},{"id":"767","title":"Fox Sports Argentina"},{"id":"788","title":"Fox Sports 2 Argentina"},{"id":"789","title":"Fox Sports 3 Argentina"},{"id":"830","title":"Fox Sports Premium MX"},{"id":"568","title":"FilmBox Premium Poland"},{"id":"757","title":"Fight Network"},{"id":"297","title":"Fox Business"},{"id":"483","title":"FOX HD Bulgaria"},{"id":"54","title":"FOX USA"},{"id":"317","title":"FX USA"},{"id":"298","title":"FXX USA"},{"id":"301","title":"Freeform"},{"id":"347","title":"Fox News"},{"id":"381","title":"FX Movie Channel"},{"id":"665","title":"FYI"},{"id":"688","title":"Film4 UK"},{"id":"744","title":"Fashion TV"},{"id":"751","title":"FETV - Family Entertainment Television"},{"id":"768","title":"FOXNY USA"},{"id":"775","title":"Fox Weather Channel"},{"id":"279","title":"FUSE TV USA"},{"id":"530","title":"GOL PLAY Spain"},{"id":"318","title":"GOLF Channel USA"},{"id":"319","title":"Game Show Network"},{"id":"292","title":"Gol Mundial 1"},{"id":"687","title":"Gold UK"},{"id":"743","title":"Galavisión USA"},{"id":"699","title":"CBC CA"},{"id":"752","title":"Grit Channel"},{"id":"760","title":"Globo SP"},{"id":"761","title":"Globo RIO"},{"id":"836","title":"Global CA"},{"id":"320","title":"The Hallmark Channel"},{"id":"296","title":"Hallmark Movies & Mysterie"},{"id":"321","title":"HBO USA"},{"id":"689","title":"HBO2 USA"},{"id":"690","title":"HBO Comedy USA"},{"id":"691","title":"HBO Family USA"},{"id":"692","title":"HBO Latino USA"},{"id":"693","title":"HBO Signature USA"},{"id":"694","title":"HBO Zone USA"},{"id":"569","title":"HBO Poland"},{"id":"322","title":"History USA"},{"id":"323","title":"Headline News"},{"id":"382","title":"HGTV"},{"id":"553","title":"HOT3 Israel"},{"id":"740","title":"HR Fernsehen DE"},{"id":"350","title":"ITV 1 UK"},{"id":"351","title":"ITV 2 UK"},{"id":"352","title":"ITV 3 UK"},{"id":"353","title":"ITV 4 UK"},{"id":"854","title":"Italia 1 Italy"},{"id":"324","title":"Investigation Discovery (ID USA)"},{"id":"325","title":"ION USA"},{"id":"656","title":"IFC TV USA"},{"id":"803","title":"Kanal 4 Denmark"},{"id":"804","title":"Kanal 5 Denmark"},{"id":"731","title":"Kabel Eins (Kabel 1) DE"},{"id":"276","title":"LaLigaTV UK"},{"id":"539","title":"LALIGA TV Hypermotion"},{"id":"645","title":"LEquipe France"},{"id":"534","title":"La Sexta Spain"},{"id":"826","title":"Liverpool TV (LFC TV)"},{"id":"326","title":"Lifetime Network"},{"id":"389","title":"Lifetime Movies Network"},{"id":"667","title":"Longhorn Network USA"},{"id":"855","title":"La7 Italy"},{"id":"856","title":"LA7d HD+ Italy"},{"id":"278","title":"Law & Crime Network"},{"id":"136","title":"Match Football 1 Russia"},{"id":"137","title":"Match Football 2 Russia"},{"id":"138","title":"Match Football 3 Russia"},{"id":"573","title":"Match Premier Russia"},{"id":"127","title":"Match TV Russia"},{"id":"395","title":"МАТЧ! БОЕЦ Russia"},{"id":"84","title":"Movistar Laliga"},{"id":"435","title":"Movistar Liga de Campeones"},{"id":"436","title":"Movistar Deportes Spain"},{"id":"438","title":"Movistar Deportes 2 Spain"},{"id":"526","title":"Movistar Deportes 3 Spain"},{"id":"527","title":"Movistar Deportes 4 Spain"},{"id":"528","title":"Movistar Golf Spain"},{"id":"924","title":"Monumental Sports Network"},{"id":"563","title":"Motowizja Poland"},{"id":"470","title":"M6 France"},{"id":"765","title":"MSG USA"},{"id":"327","title":"MSNBC"},{"id":"299","title":"Magnolia Network"},{"id":"367","title":"MTV UK"},{"id":"371","title":"MTV USA"},{"id":"377","title":"MUTV UK"},{"id":"646","title":"MAVTV USA"},{"id":"791","title":"MGM+ USA / Epix"},{"id":"779","title":"Max Sport 1 Croatia"},{"id":"780","title":"Max Sport 2 Croatia"},{"id":"770","title":"Marquee Sports Network"},{"id":"472","title":"Max Sport 1 Bulgaria"},{"id":"473","title":"Max Sport 2 Bulgaria"},{"id":"474","title":"Max Sport 3 Bulgaria"},{"id":"475","title":"Max Sport 4 Bulgaria"},{"id":"437","title":"Movistar Supercopa de Espa�a"},{"id":"399","title":"MLB Network USA"},{"id":"829","title":"MASN USA"},{"id":"654","title":"MY9TV USA"},{"id":"661","title":"Motor Trend"},{"id":"662","title":"METV USA"},{"id":"733","title":"MDR DE"},{"id":"749","title":"Mundotoro TV Spain"},{"id":"806","title":"MTV Denmark"},{"id":"663","title":"NHL Network USA"},{"id":"468","title":"Nova Sport Bulgaria"},{"id":"582","title":"Nova Sport Serbia"},{"id":"631","title":"Nova Sports 1 Greece"},{"id":"632","title":"Nova Sports 2 Greece"},{"id":"633","title":"Nova Sports 3 Greece"},{"id":"634","title":"Nova Sports 4 Greece"},{"id":"635","title":"Nova Sports 5 Greece"},{"id":"636","title":"Nova Sports 6 Greece"},{"id":"599","title":"Nova Sports Premier League Greece"},{"id":"637","title":"Nova Sports Start Greece"},{"id":"638","title":"Nova Sports Prime Greece"},{"id":"639","title":"Nova Sports News Greece"},{"id":"762","title":"NESN USA"},{"id":"53","title":"NBC USA"},{"id":"404","title":"NBA TV USA"},{"id":"776","title":"NBC Sports Chicago"},{"id":"777","title":"NBC Sports Philadelphia"},{"id":"778","title":"NBC Sports Washington"},{"id":"277","title":"NBC10 Philadelphia"},{"id":"405","title":"NFL Network"},{"id":"753","title":"NBC Sports Bay Area"},{"id":"754","title":"NBC Sports Boston"},{"id":"755","title":"NBC Sports California"},{"id":"769","title":"NBCNY USA"},{"id":"480","title":"Nova TV Bulgaria"},{"id":"328","title":"National Geographic (NGC)"},{"id":"329","title":"NICK JR"},{"id":"330","title":"NICK"},{"id":"666","title":"Nick Music"},{"id":"649","title":"Nicktoons"},{"id":"736","title":"NDR DE"},{"id":"292","title":"NewsNation USA"},{"id":"613","title":"Newsmax USA"},{"id":"745","title":"Nat Geo Wild USA"},{"id":"835","title":"Noovo CA"},{"id":"771","title":"New! CWPIX 11"},{"id":"611","title":"OnTime Sports"},{"id":"612","title":"OnTime Sports 2"},{"id":"541","title":"ONE 1 HD Israel"},{"id":"542","title":"ONE 2 HD Israel"},{"id":"439","title":"Orange Sport 1 Romania"},{"id":"440","title":"Orange Sport 2 Romania"},{"id":"441","title":"Orange Sport 3 Romania"},{"id":"442","title":"Orange Sport 4 Romania"},{"id":"331","title":"Oprah Winfrey Network (OWN)"},{"id":"332","title":"Oxygen True Crime"},{"id":"771","title":"Premier Sports Ireland 1"},{"id":"799","title":"Premier Sports Ireland 2"},{"id":"562","title":"Polsat Poland"},{"id":"47","title":"Polsat Sport Poland"},{"id":"50","title":"Polsat Sport Extra Poland"},{"id":"129","title":"Polsat Sport News Poland"},{"id":"443","title":"Polsat News Poland"},{"id":"564","title":"Polsat Film Poland"},{"id":"718","title":"Porto Canal Portugal"},{"id":"730","title":"ProSieben (PRO7) DE"},{"id":"843","title":"Prima TV RO"},{"id":"450","title":"PTV Sports"},{"id":"287","title":"Pac-12 Network USA"},{"id":"88","title":"Premier Brasil"},{"id":"583","title":"Prima Sport 1"},{"id":"584","title":"Prima Sport 2"},{"id":"585","title":"Prima Sport 3"},{"id":"586","title":"Prima Sport 4"},{"id":"334","title":"Paramount Network"},{"id":"653","title":"POP TV USA"},{"id":"210","title":"PBS USA USA"},{"id":"43","title":"PDC TV"},{"id":"364","title":"RTE 1"},{"id":"365","title":"RTE 2"},{"id":"119","title":"RMC Sport 1 France"},{"id":"120","title":"RMC Sport 2 France"},{"id":"719","title":"RTP 1 Portugal"},{"id":"720","title":"RTP 2 Portugal"},{"id":"721","title":"RTP 3 Portugal"},{"id":"850","title":"Rai 1 Italy"},{"id":"851","title":"Rai 2 Italy"},{"id":"852","title":"Rai 3 Italy"},{"id":"853","title":"Rai 3 Italy"},{"id":"882","title":"Rai Sport Italy"},{"id":"858","title":"Rai Premium Italy"},{"id":"523","title":"Real Madrid TV Spain"},{"id":"839","title":"RDS CA"},{"id":"840","title":"RDS 2 CA"},{"id":"607","title":"Rally Tv"},{"id":"841","title":"RDS Info CA"},{"id":"471","title":"Ring Bulgaria"},{"id":"390","title":"RTL7 Netherland"},{"id":"740","title":"RTL DE"},{"id":"555","title":"Racing Tv UK"},{"id":"293","title":"Reelz Channel"},{"id":"920","title":"Root Sports Northwest"},{"id":"35","title":"Sky Sports Football UK"},{"id":"36","title":"Sky Sports Arena UK"},{"id":"37","title":"Sky Sports Action UK"},{"id":"38","title":"Sky Sports Main Event"},{"id":"130","title":"Sky sports Premier League"},{"id":"60","title":"Sky Sports F1 UK"},{"id":"274","title":"Sky Sports F1 DE"},{"id":"65","title":"Sky Sports Cricket"},{"id":"70","title":"Sky Sports Golf UK"},{"id":"574","title":"Sky Sports Golf Italy"},{"id":"575","title":"Sky Sport MotoGP Italy"},{"id":"576","title":"Sky Sport Tennis Italy"},{"id":"46","title":"Sky Sports Tennis UK"},{"id":"884","title":"Sky Sports Tennis DE"},{"id":"577","title":"Sky Sport F1 Italy"},{"id":"366","title":"Sky Sports News UK"},{"id":"449","title":"Sky Sports MIX UK"},{"id":"556","title":"Sky Sport Top Event DE"},{"id":"557","title":"Sky Sport Mix DE"},{"id":"558","title":"Sky Sport Bundesliga 1 HD"},{"id":"559","title":"Sky Sport Austria 1 HD"},{"id":"759","title":"SportsNet New York (SNY)"},{"id":"460","title":"Sky Sport Football Italy"},{"id":"461","title":"Sky Sport UNO Italy"},{"id":"462","title":"Sky Sport Arena Italy"},{"id":"554","title":"Sky Sports Racing UK"},{"id":"881","title":"Sky UNO Italy"},{"id":"588","title":"Sky Sport 1 NZ"},{"id":"589","title":"Sky Sport 2 NZ"},{"id":"590","title":"Sky Sport 3 NZ"},{"id":"591","title":"Sky Sport 4 NZ"},{"id":"592","title":"Sky Sport 5 NZ"},{"id":"593","title":"Sky Sport 6 NZ"},{"id":"594","title":"Sky Sport 7 NZ"},{"id":"595","title":"Sky Sport 8 NZ"},{"id":"596","title":"Sky Sport 9 NZ"},{"id":"587","title":"Sky Sport Select NZ"},{"id":"883","title":"SBS6 NL"},{"id":"49","title":"Sport TV1 Portugal"},{"id":"74","title":"Sport TV2 Portugal"},{"id":"289","title":"Sport TV4 Portugal"},{"id":"454","title":"Sport TV3 Portugal"},{"id":"290","title":"Sport TV5 Portugal"},{"id":"291","title":"Sport TV6 Portugal"},{"id":"722","title":"SIC Portugal"},{"id":"811","title":"SEE Denmark"},{"id":"385","title":"SEC Network USA"},{"id":"78","title":"SporTV Brasil"},{"id":"79","title":"SporTV2 Brasil"},{"id":"80","title":"SporTV3 Brasil"},{"id":"101","title":"Sport Klub 1 Serbia"},{"id":"102","title":"Sport Klub 2 Serbia"},{"id":"103","title":"Sport Klub 3 Serbia"},{"id":"104","title":"Sport Klub 4 Serbia"},{"id":"453","title":"Sport Klub HD Serbia"},{"id":"406","title":"Sportsnet Ontario"},{"id":"411","title":"Sportsnet One"},{"id":"407","title":"Sportsnet West"},{"id":"408","title":"Sportsnet East"},{"id":"409","title":"Sportsnet 360"},{"id":"410","title":"Sportsnet World"},{"id":"412","title":"SuperSport Grandstand"},{"id":"413","title":"SuperSport PSL"},{"id":"414","title":"SuperSport Premier league"},{"id":"415","title":"SuperSport LaLiga"},{"id":"416","title":"SuperSport Variety 1"},{"id":"417","title":"SuperSport Variety 2"},{"id":"418","title":"SuperSport Variety 3"},{"id":"419","title":"SuperSport Variety 4"},{"id":"420","title":"SuperSport Action"},{"id":"421","title":"SuperSport Rugby"},{"id":"422","title":"SuperSport Golf"},{"id":"423","title":"SuperSport Tennis"},{"id":"424","title":"SuperSport Motorsport"},{"id":"56","title":"Supersport Football"},{"id":"368","title":"SuperSport Cricket"},{"id":"572","title":"SuperSport MaXimo 1"},{"id":"716","title":"Sporting TV Portugal"},{"id":"571","title":"SportDigital Fussball"},{"id":"764","title":"Spectrum Sportsnet LA"},{"id":"640","title":"Sport1+ Germany"},{"id":"641","title":"Sport1 Germany"},{"id":"670","title":"S4C UK"},{"id":"729","title":"SAT.1 DE"},{"id":"671","title":"Sky Cinema Premiere UK"},{"id":"672","title":"Sky Cinema Select UK"},{"id":"673","title":"Sky Cinema Hits UK"},{"id":"674","title":"Sky Cinema Greats UK"},{"id":"675","title":"Sky Cinema Animation UK"},{"id":"676","title":"Sky Cinema Family UK"},{"id":"677","title":"Sky Cinema Action UK"},{"id":"267","title":"Star Sports 1 IN"},{"id":"268","title":"Star Sports Hindi IN"},{"id":"678","title":"Sky Cinema Comedy UK"},{"id":"679","title":"Sky Cinema Thriller UK"},{"id":"680","title":"Sky Cinema Drama UK"},{"id":"681","title":"Sky Cinema Sci-Fi Horror UK"},{"id":"859","title":"Sky Cinema Collection Italy"},{"id":"860","title":"Sky Cinema Uno Italy"},{"id":"861","title":"Sky Cinema Action Italy"},{"id":"862","title":"8Sky Cinema Comedy Italy"},{"id":"863","title":"Sky Cinema Uno +24 Italy"},{"id":"864","title":"Sky Cinema Romance Italy"},{"id":"865","title":"Sky Cinema Family Italy"},{"id":"866","title":"Sky Cinema Due +24 Italy"},{"id":"867","title":"Sky Cinema Drama Italy"},{"id":"868","title":"8Sky Cinema Suspense Italy"},{"id":"869","title":"Sky Sport 24 Italy"},{"id":"870","title":"Sky Sport Calcio Italy"},{"id":"871","title":"Sky Calcio 1 (251) Italy"},{"id":"872","title":"Sky Calcio 2 (252) Italy"},{"id":"873","title":"Sky Calcio 3 (253) Italy"},{"id":"874","title":"Sky Calcio 4 (254) Italy"},{"id":"875","title":"Sky Calcio 5 (255) Italy"},{"id":"876","title":"Sky Calcio 6 (256) Italy"},{"id":"877","title":"Sky Calcio 7 (257) Italy"},{"id":"880","title":"Sky Serie Italy"},{"id":"284","title":"StarzPlay CricLife 1 HD"},{"id":"283","title":"StarzPlay CricLife 2 HD"},{"id":"282","title":"StarzPlay CricLife 3 HD"},{"id":"682","title":"Sky Showcase UK"},{"id":"683","title":"Sky Arts UK"},{"id":"684","title":"Sky Comedy UK"},{"id":"685","title":"Sky Crime"},{"id":"686","title":"Sky History"},{"id":"614","title":"SSC Sport 1"},{"id":"615","title":"SSC Sport 2"},{"id":"616","title":"SSC Sport 3"},{"id":"617","title":"SSC Sport 4"},{"id":"618","title":"SSC Sport 5"},{"id":"619","title":"SSC Sport Extra 1"},{"id":"620","title":"SSC Sport Extra 2"},{"id":"621","title":"SSC Sport Extra 3"},{"id":"140","title":"Sport 1 Israel"},{"id":"141","title":"Sport 2 Israel"},{"id":"142","title":"Sport 3 Israel"},{"id":"143","title":"Sport 4 Israel"},{"id":"144","title":"Sport 5 Israel"},{"id":"145","title":"Sport 5 PLUS Israel"},{"id":"146","title":"Sport 5 Live Israel"},{"id":"147","title":"Sport 5 Star Israel"},{"id":"148","title":"Sport 5 Gold Israel"},{"id":"294","title":"Science Channel"},{"id":"333","title":"Showtime USA"},{"id":"685","title":"Showtime SHOxBET USA"},{"id":"792","title":"Showtime 2 USA (SHO2) USA"},{"id":"793","title":"Showtime Showcase USA"},{"id":"794","title":"Showtime Extreme USA"},{"id":"795","title":"Showtime Family Zone (SHO Family Zone) USA"},{"id":"796","title":"Showtime Next (SHO Next) USA"},{"id":"797","title":"Showtime Women USA"},{"id":"335","title":"Starz"},{"id":"361","title":"Sky Witness HD"},{"id":"732","title":"Sixx DE"},{"id":"362","title":"Sky Atlantic"},{"id":"373","title":"SYFY USA"},{"id":"658","title":"Sundance TV"},{"id":"735","title":"SWR DE"},{"id":"738","title":"SUPER RTL DE"},{"id":"739","title":"SR Fernsehen DE"},{"id":"601","title":"Smithsonian Channel"},{"id":"921","title":"Space City Home Network"},{"id":"922","title":"SportsNet Pittsburgh"},{"id":"31","title":"TNT Sports 1 UK"},{"id":"32","title":"TNT Sports 2 UK"},{"id":"33","title":"TNT Sports 3 UK"},{"id":"34","title":"TNT Sports 4 UK"},{"id":"469","title":"TF1 France"},{"id":"111","title":"TSN1"},{"id":"112","title":"TSN2"},{"id":"113","title":"TSN3"},{"id":"114","title":"TSN4"},{"id":"115","title":"TSN5"},{"id":"565","title":"TVN HD Poland"},{"id":"444","title":"TVN24 Poland"},{"id":"560","title":"TVP1 Poland"},{"id":"561","title":"TVP2 Poland"},{"id":"532","title":"Telecinco Spain"},{"id":"533","title":"TVE La 1 Spain"},{"id":"536","title":"TVE La 2 Spain"},{"id":"723","title":"TVI Portugal"},{"id":"724","title":"TVI Reality Portugal"},{"id":"529","title":"Teledeporte Spain (TDP)"},{"id":"746","title":"TYC Sports Argentina"},{"id":"128","title":"TVP Sport Poland"},{"id":"87","title":"TNT Brasil"},{"id":"388","title":"TNT Sports Argentina"},{"id":"642","title":"TNT Sports HD Chile"},{"id":"40","title":"Tennis Channel"},{"id":"741","title":"Ten Sports PK"},{"id":"66","title":"TUDN USA"},{"id":"131","title":"Telemundo"},{"id":"336","title":"TBS USA"},{"id":"337","title":"TLC"},{"id":"338","title":"TNT USA"},{"id":"833","title":"TVA Sports"},{"id":"834","title":"TVA Sports 2"},{"id":"340","title":"Travel Channel"},{"id":"341","title":"TruTV USA"},{"id":"342","title":"TVLAND"},{"id":"644","title":"TCM USA"},{"id":"698","title":"TMC Channel USA"},{"id":"384","title":"The Food Network"},{"id":"394","title":"The Weather Channel"},{"id":"452","title":"TVP INFO"},{"id":"650","title":"TeenNick"},{"id":"660","title":"TV ONE USA"},{"id":"807","title":"TV2 Bornholm Denmark"},{"id":"808","title":"TV2 Sport X Denmark"},{"id":"809","title":"TV3 Sport Denmark"},{"id":"810","title":"TV2 Sport Denmark"},{"id":"817","title":"TV2 Denmark"},{"id":"818","title":"TV2 Zulu"},{"id":"819","title":"TV3+ Denmark"},{"id":"223","title":"TV3 Max Denmark"},{"id":"842","title":"TVO CA"},{"id":"270","title":"T Sports BD"},{"id":"700","title":"Tennis+ 1"},{"id":"701","title":"Tennis+ 2"},{"id":"702","title":"Tennis+ 3"},{"id":"703","title":"Tennis+ 4"},{"id":"704","title":"Tennis+ 5"},{"id":"705","title":"Tennis+ 6"},{"id":"706","title":"Tennis+ 7"},{"id":"707","title":"Tennis+ 8"},{"id":"708","title":"Tennis+ 9"},{"id":"709","title":"Tennis+ 10"},{"id":"710","title":"Tennis+ 11"},{"id":"711","title":"Tennis+ 12"},{"id":"712","title":"Tennis+ 13"},{"id":"713","title":"Tennis+ 14"},{"id":"714","title":"Tennis+ 15"},{"id":"343","title":"USA Network"},{"id":"668","title":"Universal Kids USA"},{"id":"132","title":"Univision"},{"id":"133","title":"Unimas"},{"id":"451","title":"Viaplay Sports 1 UK"},{"id":"550","title":"Viaplay Sports 2 UK"},{"id":"597","title":"Viaplay Xtra UK"},{"id":"260","title":"Vodafone Sport"},{"id":"521","title":"#Vamos Spain"},{"id":"272","title":"V Sport Motor Sweden"},{"id":"815","title":"V Film Premiere"},{"id":"816","title":"V Film Family"},{"id":"344","title":"VH1 USA"},{"id":"378","title":"Veronica NL Netherland"},{"id":"391","title":"VTV+ Uruguay"},{"id":"659","title":"VICE TV"},{"id":"346","title":"Willow Cricket"},{"id":"598","title":"Willow XTRA"},{"id":"376","title":"WWE Network"},{"id":"392","title":"Win Sports+ Columbia"},{"id":"655","title":"WETV USA"},{"id":"734","title":"WDR DE"},{"id":"763","title":"YES Network USA"},{"id":"543","title":"Yes Movies Action Israel"},{"id":"544","title":"Yes Movies Kids Israel"},{"id":"545","title":"Yes Movies Comedy Israel"},{"id":"609","title":"Yas TV UAE"},{"id":"837","title":"Yes TV CA"},{"id":"296","title":"YTV CA"},{"id":"383","title":"Ziggo Sport Docu NL"},{"id":"393","title":"Ziggo Sport Select NL"},{"id":"396","title":"Ziggo Sport Racing NL"},{"id":"398","title":"Ziggo Sport Voetbal NL"},{"id":"727","title":"BBC 1 DE"},{"id":"728","title":"ZDF Info DE"},{"id":"857","title":"20 Mediaset Italy"},{"id":"800","title":"6eren Denmark"},{"id":"437","title":"#0 Spain"},{"id":"360","title":"5 USA"},{"id":"726","title":"3sat DE"},{"id":"501","title":"18+ (Player-01)"},{"id":"502","title":"18+ (Player-02)"},{"id":"503","title":"18+ (Player-03)"},{"id":"504","title":"18+ (Player-04)"},{"id":"505","title":"18+ (Player-05)"},{"id":"506","title":"18+ (Player-06)"},{"id":"507","title":"18+ (Player-07)"},{"id":"508","title":"18+ (Player-08)"},{"id":"509","title":"18+ (Player-09)"},{"id":"510","title":"18+ (Player-10)"},{"id":"511","title":"18+ (Player-11)"},{"id":"512","title":"18+ (Player-12)"},{"id":"513","title":"18+ (Player-13)"},{"id":"514","title":"18+ (Player-14)"},{"id":"515","title":"18+ (Player-15)"},{"id":"516","title":"18+ (Player-16)"},{"id":"517","title":"18+ (Player-17)"},{"id":"518","title":"18+ (Player-18)"},{"id":"519","title":"18+ (Player-19)"},{"id":"520","title":"18+ (Player-20)"}]';
    return @json_decode($d, true);
}

// Coded by WingyCodes  //

?>