<?php
include("_@configs.php");
$allowedReferers = array(
"footfy.net",
"play.footfy.net",

);

$referer = isset($_SERVER['HTTP_REFERER']) ? parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) : '';

if (in_array($referer, $allowedReferers)) {
  // this refferer script created by shihab ahmed

} else {

    header("Location: https://footfy.net/");
    exit();
}



$channelID = "";
if (isset($_REQUEST['play'])) {
    $channelID = trim($_REQUEST['play']);
}

if (!empty($channelID)) {
    $tvname = getChannelName($channelID);
    $tvplayurl = "stream.m3u8?id=" . $channelID;
?>
<html>
<head>
    <title><?php print($tvname); ?> - <?php print($APP_CONFIGS['APP_NAME']); ?> | <?php print($APP_CONFIGS['APP_POWEREDBY']); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" type="text/css" href="assets/clap.css?v=1"/>
    <script src="https://cdn.jsdelivr.net/clappr/latest/clappr.min.js"></script>
	<script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool@latest'></script>
    <script src="https://cdn.jsdelivr.net/clappr.level-selector/latest/level-selector.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@clappr/hlsjs-playback@1.0.1/dist/hlsjs-playback.min.js"></script>
    <link rel="icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
    <link rel="shortcut icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>"/>
    <style>body { background-color: #000000; }</style>
</head>
<body>
    <div id="player" style="height: 100%; width: 100%;"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
    var player = new Clappr.Player({
        source: '<?php print($tvplayurl); ?>',
        width: '100%',
        height: '100%',
        autoPlay: false,
        plugins: [HlsjsPlayback, LevelSelector],
        mimeType: "application/x-mpegURL",
        mediacontrol: { seekbar: "#ff0000", buttons: "#eee" },
        parentId: "#player",
    });
    </script>
</body>
</html>
<?php
} else {
    echo "No Channel Selected.";
}
?>
