<?php

include("_@configs.php");

$action = "";
if(isset($_REQUEST['action'])) { $action = trim($_REQUEST['action']); }

//=============================================================//

$tvlist = getChannels();

if($action == "getChannels")
{
    if(!isset($tvlist[0])) { response("error", 404, "No Channels Found", ""); }
    response("success", 200, "Channels List", array("count" => count($tvlist), "list" => $tvlist));
}
elseif($action == "searchChannels")
{
    $query = ""; $resdata = array();
    if(isset($_REQUEST['query'])){ $query = trim($_REQUEST['query']); }
    if(empty($query)){ response("error", 400, "Please Enter Channel Name To Search", ""); }
    if(!isset($tvlist[0])) { response("error", 404, "No Channels Exist", ""); }
    foreach($tvlist as $vtl) {
        if(stripos($vtl['title'], $query) !== false) { $resdata[] = $vtl; }
    }
    if(!isset($resdata[0])){ response("error", 404, "No Matching Results Found", ""); }
    response("success", 200, "Total ".count($resdata)." Results Found", array("count" => count($resdata), "query" => $query, "list" => $resdata));
}
elseif($action == "m3u_playlist")
{
    if(isset($tvlist[0]))
    {
        if($_SERVER['SERVER_PORT'] !== "80" && $_SERVER['SERVER_PORT'] !== "443") { $playUrlBase = $streamenvproto."://".$plhoth.":".$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); } else { $playUrlBase = $streamenvproto."://".$plhoth.str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); }
        $logoURL = $playUrlBase."assets/daddylive.png";
        $playlistData = "#EXTM3U\n";
        $c = 0;
        foreach($tvlist as $otv)
        {
            $c++;
            $playlistData .= '#EXTINF:-1 tvg-id="'.$c.'" tvg-name="'.$otv['title'].'" tvg-country="US" tvg-logo="'.$logoURL.'" tvg-chno="'.$c.'" group-title="",'.$otv['title']."\n";
            $playlistData .= $playUrlBase."stream.m3u8?id=".$otv['id']."\n";
        }
        $file = str_replace(" ", "", $APP_CONFIGS['APP_NAME'])."_(WingyCodes)-".time().".m3u";
        header('Content-Disposition: attachment; filename="'.$file.'"');
        header("Content-Type: application/vnd.apple.mpegurl");
        exit($playlistData);
    }
    http_response_code(404); exit();

}
else
{
    response("error", 400, "Bad Request", "");
}

?>