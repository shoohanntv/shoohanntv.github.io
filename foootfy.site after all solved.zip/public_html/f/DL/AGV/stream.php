<?php

include("_@configs.php");

if (
    // Check if HTTP_REFERER and HTTP_ORIGIN match the domain
    (!isset($_SERVER['HTTP_REFERER']) || !preg_match('/footfy.net/', $_SERVER['HTTP_REFERER'])) &&
    (!isset($_SERVER['HTTP_ORIGIN']) || !preg_match('/footfy.net/', $_SERVER['HTTP_ORIGIN'])) ||
    // Check if the User-Agent is missing or does not contain "ExoPlayer"
    (!isset($_SERVER['HTTP_USER_AGENT']) || empty($_SERVER['HTTP_USER_AGENT']) || !preg_match('//', $_SERVER['HTTP_USER_AGENT']))
) {
    http_response_code(403);
    exit('<body style="background-color:black; color:yellow; font-family:sans-serif; text-align:center;">
            <h1>Access denied.</h1>
          </body>');
}

header("Access-Control-Allow-Origin: *");

$detail = array(); $streamURL = ""; $refererURL = ""; $originURL = "";
$id = ""; $cid = ""; $key = ""; $chunks = ""; $segment = ""; $vtoken = "";
if(isset($_REQUEST['id'])) { $id = trim($_REQUEST['id']); }
if(isset($_REQUEST['cid'])) { $cid = trim($_REQUEST['cid']); }
if(isset($_REQUEST['key'])) { $key = trim($_REQUEST['key']); }
if(isset($_REQUEST['chunks'])) { $chunks = trim($_REQUEST['chunks']); }
if(isset($_REQUEST['segment'])) { $segment = trim($_REQUEST['segment']); }
if(isset($_REQUEST['vtoken'])) { $vtoken = trim($_REQUEST['vtoken']); }

if(!empty($id)) { $detail = getChannelDetail($id); }
if(!empty($cid)) { $detail = getChannelDetail($cid); }
if(!empty($detail)) {
    $streamURL = $detail['u'];
    $refererURL = $detail['r'];
    $originURL = rtrim($detail['r'], "/");
    $strmHeader = array("Referer: ".$refererURL, "Origin: ".$originURL, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
} else {
    $strmHeader = array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
}

if(stripos($_SERVER['REQUEST_URI'], ".php?") !== false){ $HLS_EXT = $KEY_EXT = $TS_EXT = ".php"; } else { $HLS_EXT = ".m3u8"; $KEY_EXT = ".key"; $TS_EXT = ".ts"; }
$CSTRMFILE = str_replace(".php", "", basename($_SERVER['SCRIPT_NAME']));

//================================================//

if(!empty($id))
{
    if(!filter_var($streamURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest($streamURL, $strmHeader);
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") !== false)
    {
        updateChannelStreamURL($id, $fetch['url']);
        $tine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, 'URI="') !== false)
            {
                $orgURL = getXPURI($vine);
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($orgURL, "http://") !== false || stripos($orgURL, "https://") !== false){ $iBaseURL = ""; }
                $norgURL = $CSTRMFILE.$HLS_EXT."?cid=".$id."&chunks=".enc_dec('encrypt', $iBaseURL.$orgURL)."&vtoken=".$vtoken;
                $tine .= str_replace($orgURL, $norgURL, $vine)."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                $tine .= $CSTRMFILE.$HLS_EXT."?cid=".$id."&chunks=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
            }
            else
            {
                $tine .= $vine."\n";
            }
        }
        header("Content-Type: application/vnd.apple.mpegurl");
        print(trim($tine));
        exit();
    }
    echo $streamURL;
}
elseif(!empty($chunks))
{
    $playURL = enc_dec('decrypt', $chunks);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest__fget($playURL, $strmHeader);
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") !== false)
    {
        $tine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, 'URI="') !== false)
            {
                $orgURL = getXPURI($vine);
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($orgURL, "http://") !== false || stripos($orgURL, "https://") !== false){ $iBaseURL = ""; }
                $norgURL = $CSTRMFILE.$KEY_EXT."?cid=".$cid."&key=".enc_dec('encrypt', $iBaseURL.$orgURL)."&vtoken=".$vtoken;
                $tine .= str_replace($orgURL, $norgURL, $vine)."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                $tine .= $CSTRMFILE.$HLS_EXT."?cid=".$id."&chunks=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
            }
            elseif(stripos($vine, 'URI="') === false && stripos($vine, ".rtf") !== false || stripos($vine, ".webp") !== false || stripos($vine, ".doc") !== false || stripos($vine, ".txt") !== false || stripos($vine, ".ogg") !== false || stripos($vine, ".gif") !== false || stripos($vine, ".aspx") !== false || stripos($vine, ".jsp") !== false || stripos($vine, ".asp") !== false || stripos($vine, ".php") !== false || stripos($vine, ".ico") !== false || stripos($vine, ".bmp") !== false || stripos($vine, ".tif") !== false || stripos($vine, ".svg") !== false || stripos($vine, ".jar") !== false || stripos($vine, ".html") !== false || stripos($vine, ".xls") !== false || stripos($vine, ".webm") !== false || stripos($vine, ".exe") !== false || stripos($vine, ".apk") !== false || stripos($vine, ".ejs") !== false || stripos($vine, ".ts") !== false || stripos($vine, ".png") !== false || stripos($vine, ".css") !== false || stripos($vine, ".woff") !== false || stripos($vine, ".ttf") !== false || stripos($vine, ".zip") !== false || stripos($vine, ".rar") !== false || stripos($vine, ".pdf") !== false || stripos($vine, ".jpg") !== false || stripos($vine, ".jpeg") !== false)
            {
                $iBaseURL = getRelBase($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false){ $iBaseURL = ""; }
                $tine .= $CSTRMFILE.$TS_EXT."?cid=".$cid."&segment=".enc_dec('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."\n";
            }
            else
            {
                $tine .= $vine."\n";
            }
        }
        header("Content-Type: application/vnd.apple.mpegurl");
        print(trim($tine));
        exit();
    }
}
elseif(!empty($key))
{
    $playURL = enc_dec('decrypt', $key);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $playURL = str_replace(getRootBase($playURL), "https://key.mizhls.ru", $playURL);
    $fetch = getRequest__fget($playURL, $strmHeader);
    $return = $fetch['data'];
    if(!empty($return) && strlen($return) == 16)
    {
        header("Content-Type: application/binary");
        print($return);
        exit();
    }
    header("X-Kafka-Error: Key Fetch Failed");
    http_response_code(403);
    exit();
}
elseif(!empty($segment))
{
    $playURL = enc_dec('decrypt', $segment);
    if(!filter_var($playURL, FILTER_VALIDATE_URL)) {
        header("X-Kafka-Error: Channel Playback Data Unavailable");
        http_response_code(404);
        exit();
    }
    $fetch = getRequest__fget($playURL, $strmHeader);
    $return = $fetch['data'];
    header("Content-Type: video/m2ts");
    print($return);
    exit();
}
else
{
    http_response_code(400); exit();
}

?>