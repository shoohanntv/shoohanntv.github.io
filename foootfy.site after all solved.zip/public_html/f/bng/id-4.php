<?php

$allowedReferers = array(
"footfy.net",
"bokulsports.com",

);

$referer = isset($_SERVER['HTTP_REFERER']) ? parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) : '';

if (in_array($referer, $allowedReferers)) {
  // this refferer script created by shihab ahmed

} else {

    header("Location: https://footfy.net");
    exit();
}
?>


<html>
<style type="text/css">
  body {
    margin: 0;
    padding: 0;
    overflow: hidden;
    width: 100%;
    height: 100%;
  }

  .video-embed-container {
    position: relative;
    padding-bottom: 56.25%;
    padding-top: 0px;
    height: 0;
    overflow: hidden;
  }

  .video-embed-container iframe,
  .video-embed-container object,
  .video-embed-container embed {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
</style>

<body>
  <div class="video-embed-container">
    <iframe class="responsive-embed-item" src="https://bongls.com/live/?id=4" marginheight="0" marginwidth="0" scrolling="no"
      frameborder="0" sandbox="allow-scripts allow-same-origin" allowfullscreen="true" allow="encrypted-media"></iframe>
  </div>
</body>

</html>