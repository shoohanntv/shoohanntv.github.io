<?php
// Get the 'url' parameter from the query string
$url = isset($_GET['url']) ? $_GET['url'] : '';

// Validate the 'url' parameter
if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
    echo "Invalid or missing URL parameter.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Embed Page</title>
  <style type="text/css">
    body {
      margin: 0;
      padding: 0;
      overflow: hidden;
      width: 100%;
      height: 100%;
    }

    .video-embed-container {
      position: relative;
      padding-bottom: 56.25%;
      height: 0;
      overflow: hidden;
    }

    .video-embed-container iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  </style>
</head>
<body>
  <div class="video-embed-container">
    <iframe class="responsive-embed-item" src="<?php echo htmlspecialchars($url); ?>" marginheight="0" marginwidth="0" scrolling="no" frameborder="0" sandbox="allow-scripts allow-same-origin" allowfullscreen="true" allow="encrypted-media"></iframe>
  </div>
</body>
</html>
