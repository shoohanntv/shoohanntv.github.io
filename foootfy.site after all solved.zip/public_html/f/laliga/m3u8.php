<body>
<link rel="stylesheet" type="text/css" href="https://bdixtv.serverbd247.com/clap.css">
<script src="https://cdn.jsdelivr.net/npm/clappr@latest/dist/clappr.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/level-selector@0.2.0/dist/level-selector.min.js"></script>
<script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool@latest'></script>
<script src="https://cdn.jsdelivr.net/npm/@clappr/hlsjs-playback@1.0.1/dist/hlsjs-playback.min.js"></script>



  
  
</script><div id="player" style="height: 100%; width: 100%;"></div>
    <script>
      document.addEventListener("contextmenu", (event) => {
         event.preventDefault();
      });
   </script>
  
    


 </div>       
       

  
       
       
       
<script>
    var player = new Clappr.Player({ 
    source: 'https://zjdmi53knyt.a.trbcdn.net/dazn1/index.m3u8',
    width:'100%', 
    height:'100%', 
    autoPlay: true, 
    plugins: [HlsjsPlayback,LevelSelector],
    mimeType: "application/x-mpegURL", 
    mediacontrol: {seekbar: "#FF6800", buttons: "#eee"},  
    parentId: "#player"} ); 
</script>

</body>