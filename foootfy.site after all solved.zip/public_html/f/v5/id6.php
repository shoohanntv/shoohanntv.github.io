<!DOCTYPE html>

<html>

<head>

    <title>Footfy Live</title>

    <meta content="noindex, nofollow, noarchive" name="robots"/>

    <meta name="referrer" content="no-referrer" />

    <script src="https://content.jwplatform.com/libraries/KB5zFt7A.js"></script>

    <script>jwplayer.key = "XSuP4qMl+9tK17QNb+4+th2Pm9AWgMO/cYH8CI0HGGr7bdjo";</script>



    <style>

        body { margin: 0px; }

        .ViostreamIframe { overflow: hidden; padding-top: 56.25%; position: relative; }

        .ViostreamIframe iframe { border: 0; height: 100%; left: 0; position: absolute; top: 0; width: 100%; }

    </style>

</head>

<body>

    <div id="player" class="ViostreamIframe"></div>

<select id="channels"></select>

    <script>

jwplayer("player").setup({
      file: "https://sparkforge.store/live/6/chunks.m3u8?bongls.com"

    });
 
    </script>
    
    
    
    
    

</body>

</html>