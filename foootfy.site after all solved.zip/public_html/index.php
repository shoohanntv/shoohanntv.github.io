<?php
// Set refresh header to redirect after 3 seconds
header("Refresh:3; url=https://footfy.net");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>FOOTFY LIVE - Access Denied</title>
  <style>
    body {
      background-color: #111;
      color: #fff;
      font-family: Arial, sans-serif;
      text-align: center;
      padding-top: 20%;
    }
    h1 {
      font-size: 2.5rem;
      color: red;
    }
    p {
      font-size: 1.2rem;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <h1>Access Denied</h1>
  <p>Redirecting to <strong>FOOTFY LIVE</strong>...</p>
</body>
</html>
