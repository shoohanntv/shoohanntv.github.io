<?php

error_reporting(0);

$APP_CONFIGS['APP_NAME'] = "ZapSports";
$APP_CONFIGS['APP_FAVICON'] = "https://i.ibb.co/DDQSz6hC/zap-Favicon.png";
$APP_CONFIGS['APP_LOGO'] = "https://i.ibb.co/3mPBqvtk/zap-Banner.png";
$APP_CONFIGS['DEFAULT_APP_LOGO'] = "https://i.ibb.co/dJfysm3V/zap-Sports.png";

$APP_CONFIGS['BASE_API_URL'] = "https://streamtp4.com/";

//--------------------------------------------------------------//

$APP_CONFIGS['DATA_FOLDER'] = "__AppData__";
if(!is_dir($APP_CONFIGS['DATA_FOLDER'])) { mkdir($APP_CONFIGS['DATA_FOLDER']); }
if(!file_exists($APP_CONFIGS['DATA_FOLDER']."/index.html")) { @file_put_contents($APP_CONFIGS['DATA_FOLDER']."/index.html", ""); }
if(!file_exists($APP_CONFIGS['DATA_FOLDER']."/.htaccess")) { @file_put_contents($APP_CONFIGS['DATA_FOLDER']."/.htaccess", "deny from all"); }

$_SERVER['HTTP_HOST'] = strtok($_SERVER['HTTP_HOST'], ':'); $_SERVER['HTTP_HOST'] = str_ireplace('localhost', '127.0.0.1', $_SERVER['HTTP_HOST']);
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") { $streamenvproto = "https"; } elseif (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == "https") { $streamenvproto = "https"; } else { $streamenvproto = "http"; } $plhoth = ($_SERVER['SERVER_ADDR'] !== "127.0.0.1") ? $_SERVER['HTTP_HOST'] : getHostByName(php_uname('n'));
if(isset($_SERVER['HTTP_CF_VISITOR']) && !empty($_SERVER['HTTP_CF_VISITOR'])){ $htcfs = @json_decode($_SERVER['HTTP_CF_VISITOR'], true); if(isset($htcfs['scheme']) && !empty($htcfs['scheme'])){ $streamenvproto = $htcfs['scheme']; }}
if(isset($_SERVER['HTTP_CF_IPCOUNTRY']) && isset($_SERVER['HTTP_CF_CONNECTING_IP']) && isset($_SERVER['HTTP_CF_VISITOR']) && isset($_SERVER['HTTP_CF_RAY'])) { if(!empty($_SERVER['HTTP_CF_IPCOUNTRY']) && !empty($_SERVER['HTTP_CF_CONNECTING_IP']) && !empty($_SERVER['HTTP_CF_VISITOR']) && !empty($_SERVER['HTTP_CF_RAY'])){ $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];}}

//--------------------------------------------------------------//

function apiResponse($status, $code, $message, $data)
{
    header("Content-Type: application/json");
    $tres = json_encode(array("status" => $status, "code" => $code, "message" => $message, "data" => $data));
    print($tres);
    exit();
}

function GETRequest($url, $headers)
{
    if(empty($headers)) {
        $headers = array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36");
    }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $cxerror = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    return array("url" => $url, "code" => $httpCode, "content_type" => $contentType, "data" => $response, "error" => $cxerror);
}

function getRelativeBaseURL($url)
{
    if(stripos($url, "?") !== false)
    {
        $xrl = explode("?", $url);
        if(isset($xrl[0]) && !empty($xrl[0])) {
            $url = trim($xrl[0]);
        }
    }
    $base = str_replace(basename($url), "", $url);
    return $base;
}

function getURIFromM3U($data)
{
    if(stripos($data, 'URI="') !== false) {
        $on = explode('URI="', $data);
        if(isset($on[1])) {
            $ox = explode('"', $on[1]);
            if(isset($ox[0]) && !empty($ox[0])) {
                return trim($ox[0]);
            }
        }
    }
    return "";
}

function encrypt_decrypt($action, $data)
{
    $output = "";
    $ky = "2bMweIg4jPuskDKR";
    $iv = "Zi1noyYcyA8JgV3c";
    if ($action == "encrypt")
    {
        $encrypted = openssl_encrypt($data, "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
        if (!empty($encrypted)) {
            $output = rtrim(strtr(base64_encode($encrypted), '+/', '-_'), '=');
        }
    }
    if ($action == "decrypt") {
        $b64 = strtr($data, '-_', '+/');
        $b64 .= str_repeat('=', 3 - (3 + strlen($b64)) % 4);

        $decoded = base64_decode($b64, true);
        if ($decoded !== false) {
            $decrypted = openssl_decrypt($decoded, "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
            if (!empty($decrypted)) { $output = $decrypted; }
        }
    }
    return $output;
}

function cache_manager($file, $action, $data)
{
    global $APP_CONFIGS;
    $cache_file = $APP_CONFIGS['DATA_FOLDER']."/cache-".trim(str_replace(" ", "_", strtolower(strip_tags($file)))).".enc";
    if($action === "get" || $action === "read")
    {
        if(file_exists($cache_file))
        {
            $getCache = json_decode(file_get_contents($cache_file), true);
            if(isset($getCache['exp']) && isset($getCache['data']) && !empty($getCache['data']) && time() < $getCache['exp'])
            {
                return $getCache['data'];
            }
        }
    }
    if($action === "save" || $action == "write")
    {
        if(file_put_contents($cache_file, json_encode($data))) {
            return true;
        } else {
            return false;
        }
    }
}

function extractFlussonicTokenEXP($url)
{
    $token = "";
    $output = time() + 120;

    if (stripos($url, "token=") !== false) {
        $tel = explode("token=", $url);

        if (isset($tel[1]) && !empty($tel[1])) {
            if (stripos($tel[1], "&") === false) {
                $token = trim($tel[1]);
            } else {
                $kel = explode("&", $tel[1]);
                if (isset($kel[0]) && !empty($kel[0])) {
                    $token = trim($kel[0]);
                }
            }
        }
    }

    if (!empty($token)) {
        $qel = explode("-", $token);
        if (isset($qel[2]) && !empty($qel[2]) && is_numeric(trim($qel[2]))) {
            $output = trim($qel[2]) - 120;
        }
    }

    return $output;
}

function xor_encrypt($data)
{
    $key = "3eWUxJzzpbx7tVvbmNBc"; $output = "";
    for ($i = 0; $i < strlen($data); $i++) {
        $output .= $data[$i] ^ $key[$i % strlen($key)];
    }
    $encoded = base64_encode($output);
    $urlSafe = rtrim(strtr($encoded, '+/', '-_'), '=');
    return $urlSafe;
}

function xor_decrypt($data)
{
    $key = "3eWUxJzzpbx7tVvbmNBc";
    $data = strtr($data, '-_', '+/');
    $data = base64_decode($data);
    $output = "";
    for ($i = 0; $i < strlen($data); $i++) {
        $output .= $data[$i] ^ $key[$i % strlen($key)];
    }
    return $output;
}


if($_SERVER['SERVER_PORT'] !== "80" && $_SERVER['SERVER_PORT'] !== "443") { $playUrlBase = $streamenvproto."://".$plhoth.":".$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); } else { $playUrlBase = $streamenvproto."://".$plhoth.str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF'])); }

//--------------------------------------------------------------//

function spt_channels()
{
    global $APP_CONFIGS;
    $getCache = cache_manager("tv_list", "read", ""); if(!empty($getCache)) { return $getCache; }
    $live_Channel = array();
    $flink = $APP_CONFIGS['BASE_API_URL'];
    $fetch = GETRequest($flink, "");
    $return = $fetch['data'];
    if(stripos($return, "const channels = {") !== false) {
        $vA = explode("const channels = {", $return);
        if(isset($vA[1])) {
            $vB = explode("}", $vA[1]);
            if(isset($vB[0])) {
                $vC = explode(",", $vB[0]);
                if(isset($vC[1]))
                {
                    array_shift($vC);
                    foreach($vC as $vvO)
                    {
                        $channel_Name = ""; $channel_Embed = "";
                        $sto = explode("':", $vvO);
                        if(isset($sto[0]) && !empty($sto[0])) { $channel_Name = trim(str_replace("'", "", strip_tags($sto[0]))); }
                        if(isset($sto[1]) && !empty($sto[1])) { $channel_Embed = trim(str_replace("'", "", strip_tags($sto[1]))); }
                        if(!empty($channel_Name) && !empty($channel_Embed))
                        {
                            $live_Channel[] = array("id" => substr(md5($channel_Name.$channel_Embed), 0, 6), "title" => $channel_Name, "embed" => $channel_Embed);
                        }
                    }
                }
            }
        }
    }
    if(empty($live_Channel))
    {
        $lvo = '[{"id":"b45e4e99","title":"Gran Hermano CAM 2","embed":"https://streamtp4.com/global1.php?stream=grahermanocam2"},{"id":"6bbf0cb9","title":"Gran Hermano CAM 3","embed":"https://streamtp4.com/global1.php?stream=grahermanocam3"},{"id":"ce302511","title":"Gran Hermano CAM 24H","embed":"https://streamtp4.com/global1.php?stream=granhermanocamara24horas"},{"id":"ba5dc15d","title":"Gran Hermano MultiCAM","embed":"https://streamtp4.com/global1.php?stream=granhermanomulticam"},{"id":"5128d619","title":"ESPN 1","embed":"https://streamtp4.com/global1.php?stream=espn"},{"id":"3900150b","title":"ESPN 1","embed":"https://streamtp4.com/global1.php?stream=espn"},{"id":"163ca2cf","title":"ESPN 2","embed":"https://streamtp4.com/global1.php?stream=espn2"},{"id":"c53bad47","title":"ESPN 3","embed":"https://streamtp4.com/global1.php?stream=espn3"},{"id":"fda9a820","title":"ESPN 4","embed":"https://streamtp4.com/global1.php?stream=espn4"},{"id":"5cbba8bc","title":"ESPN 5","embed":"https://streamtp4.com/global1.php?stream=espn5"},{"id":"59880025","title":"ESPN 6","embed":"https://streamtp4.com/global1.php?stream=espn6"},{"id":"cf633ad7","title":"ESPN 7","embed":"https://streamtp4.com/global1.php?stream=espn7"},{"id":"b0ab3e5a","title":"Win Sports +","embed":"https://streamtp4.com/global1.php?stream=winplus"},{"id":"c570340d","title":"Win Sports + (Op2)","embed":"https://streamtp4.com/global1.php?stream=winplus2"},{"id":"8ab95471","title":"Win Sports","embed":"https://streamtp4.com/global1.php?stream=winsports"},{"id":"97288eb8","title":"Win Play +","embed":"https://streamtp4.com/global1.php?stream=winplusonline1"},{"id":"aef8d9d8","title":"Fox Sports 1 (Argentina)","embed":"https://streamtp4.com/global1.php?stream=fox1ar"},{"id":"e5b95287","title":"Fox Sports 2 (Argentina)","embed":"https://streamtp4.com/global1.php?stream=fox2ar"},{"id":"0ad6de20","title":"Fox Sports 3 (Argentina)","embed":"https://streamtp4.com/global1.php?stream=fox3ar"},{"id":"9f5f3d62","title":"Dsports","embed":"https://streamtp4.com/global1.php?stream=dsports"},{"id":"4dba574b","title":"Dsports 2","embed":"https://streamtp4.com/global1.php?stream=dsports2"},{"id":"8a2bbfda","title":"Dsports +","embed":"https://streamtp4.com/global1.php?stream=dsportsplus"},{"id":"dffd2103","title":"TNT Sports Chile","embed":"https://streamtp4.com/global1.php?stream=tntsportschile"},{"id":"f90691b8","title":"TNT Sports Argentina","embed":"https://streamtp4.com/global1.php?stream=tntsports"},{"id":"bbc5823b","title":"ESPN Premium Argentina","embed":"https://streamtp4.com/global1.php?stream=espnpremium"},{"id":"2180c1e9","title":"TyC Sports","embed":"https://streamtp4.com/global1.php?stream=tycsports"},{"id":"ef4a8c2b","title":"Telefe","embed":"https://streamtp4.com/global1.php?stream=telefe"},{"id":"33e11c60","title":"TV Pública","embed":"https://streamtp4.com/global1.php?stream=tv_publica"},{"id":"e92e06be","title":"Liga 1 MAX","embed":"https://streamtp4.com/global1.php?stream=liga1max"},{"id":"c07e78a2","title":"GolTV","embed":"https://streamtp4.com/global1.php?stream=goltv"},{"id":"9bec576f","title":"VTV +","embed":"https://streamtp4.com/global1.php?stream=vtvplus"},{"id":"df6e3a17","title":"GolPeru","embed":"https://streamtp4.com/global1.php?stream=golperu"},{"id":"4a1db2f6","title":"ESPN Deportes USA","embed":"https://streamtp4.com/global1.php?stream=espndeportes"},{"id":"a1ab2577","title":"TUDN USA","embed":"https://streamtp4.com/global1.php?stream=tudn_usa"},{"id":"8b79ae75","title":"Fox Sports 1 USA","embed":"https://streamtp4.com/global1.php?stream=fox_1_usa"},{"id":"8771d338","title":"Fox Sports 2 USA","embed":"https://streamtp4.com/global1.php?stream=fox_2_usa"},{"id":"88ddd132","title":"Universo USA","embed":"https://streamtp4.com/global1.php?stream=universo_usa"},{"id":"417b1078","title":"Univisíon USA","embed":"https://streamtp4.com/global1.php?stream=univision_usa"},{"id":"64a2db36","title":"Universo USA","embed":"https://streamtp4.com/global1.php?stream=universo_usa"},{"id":"3a5a47e0","title":"Fox Deportes USA","embed":"https://streamtp4.com/global1.php?stream=fox_deportes_usa"},{"id":"f3fce54b","title":"Azteca Deportes MX","embed":"https://streamtp4.com/global1.php?stream=azteca_deportes"},{"id":"4f059236","title":"Fox Sports 1 MX","embed":"https://streamtp4.com/global1.php?stream=foxsportsmx"},{"id":"b1e4cbd6","title":"Fox Sports 2 MX","embed":"https://streamtp4.com/global1.php?stream=foxsports2mx"},{"id":"bb4c8b49","title":"Fox Sports 3 MX","embed":"https://streamtp4.com/global1.php?stream=foxsports3mx"},{"id":"5ace6e44","title":"Fox Sports Premium","embed":"https://streamtp4.com/global1.php?stream=foxsportspremium"},{"id":"1591430d","title":"ESPN MX","embed":"https://streamtp4.com/global1.php?stream=espnmx"},{"id":"6994f10f","title":"ESPN 2 MX","embed":"https://streamtp4.com/global1.php?stream=espn2mx"},{"id":"26afb346","title":"ESPN 3 MX","embed":"https://streamtp4.com/global1.php?stream=espn3mx"},{"id":"65114d03","title":"TVC Deportes MX","embed":"https://streamtp4.com/global1.php?stream=tvc_deportes"},{"id":"65e35041","title":"HI! Sports MX","embed":"https://streamtp4.com/global1.php?stream=hisports"},{"id":"4dfde0aa","title":"DAZN 1 ES","embed":"https://streamtp4.com/global1.php?stream=dazn1"},{"id":"97d8ab50","title":"DAZN 2 ES","embed":"https://streamtp4.com/global1.php?stream=dazn2"},{"id":"c8a73c46","title":"DAZN LaLiga","embed":"https://streamtp4.com/global1.php?stream=dazn_laliga"},{"id":"72470681","title":"Movistar+ LaLiga","embed":"https://streamtp4.com/global1.php?stream=movistarlaliga"},{"id":"7bd0d355","title":"Movistar Liga de Campeones","embed":"https://streamtp4.com/global1.php?stream=movistarligadecampeones"},{"id":"e6aa5063","title":"Caracol TV","embed":"https://streamtp4.com/global1.php?stream=caracoltv"},{"id":"214f21cc","title":"TNT 1 GB","embed":"https://streamtp4.com/global1.php?stream=tnt_1_gb"},{"id":"144db099","title":"TNT 2 GB","embed":"https://streamtp4.com/global1.php?stream=tnt_2_gb"},{"id":"2c5b8a9e","title":"TNT 3 GB","embed":"https://streamtp4.com/global1.php?stream=tnt_3_gb"},{"id":"387bd0f9","title":"TNT 4 GB","embed":"https://streamtp4.com/global1.php?stream=tnt_4_gb"},{"id":"d90dfaeb","title":"Sky Sports Bundesliga 1","embed":"https://streamtp4.com/global1.php?stream=sky_bundesliga1"},{"id":"bac009ee","title":"Sky Sports Bundesliga 2","embed":"https://streamtp4.com/global1.php?stream=sky_bundesliga2"},{"id":"3e4deed1","title":"Sky Sports Bundesliga 3","embed":"https://streamtp4.com/global1.php?stream=sky_bundesliga3"},{"id":"b70e0943","title":"Sky Sports Bundesliga 4","embed":"https://streamtp4.com/global1.php?stream=sky_bundesliga4"},{"id":"64ce54d5","title":"Sky Sports Bundesliga 5","embed":"https://streamtp4.com/global1.php?stream=sky_bundesliga5"},{"id":"f115be8c","title":"Eleven Sports 1 PT","embed":"https://streamtp4.com/global1.php?stream=eleven1_pt"},{"id":"46571a05","title":"Eleven Sports 2 PT","embed":"https://streamtp4.com/global1.php?stream=eleven2_pt"},{"id":"7b38e7f0","title":"Eleven Sports 3 PT","embed":"https://streamtp4.com/global1.php?stream=eleven3_pt"},{"id":"50ac1234","title":"Eleven Sports 4 PT","embed":"https://streamtp4.com/global1.php?stream=eleven4_pt"},{"id":"97e5ec5d","title":"Eleven Sports 5 PT","embed":"https://streamtp4.com/global1.php?stream=eleven5_pt"},{"id":"d66def96","title":"Canal 11 PT","embed":"https://streamtp4.com/global1.php?stream=canal11_pt"},{"id":"2f39fb2d","title":"Sport TV 1 PT","embed":"https://streamtp4.com/global1.php?stream=sportv_1pt"},{"id":"66293e55","title":"Sport TV 2 PT","embed":"https://streamtp4.com/global1.php?stream=sportv_2pt"},{"id":"7860d487","title":"Sport TV 3 PT","embed":"https://streamtp4.com/global1.php?stream=sportv_3pt"},{"id":"e0973c31","title":"Sport TV 4 PT","embed":"https://streamtp4.com/global1.php?stream=sportv_4pt"},{"id":"8e222fdc","title":"Sport TV 5 PT","embed":"https://streamtp4.com/global1.php?stream=sporttv5"},{"id":"3e052759","title":"Sport TV 6 PT","embed":"https://streamtp4.com/global1.php?stream=sporttv6"},{"id":"75618ee2","title":"Sport TV 1 BR","embed":"https://streamtp4.com/global1.php?stream=sporttvbr1"},{"id":"2ca4868b","title":"Sport TV 2 BR","embed":"https://streamtp4.com/global1.php?stream=sporttvbr2"},{"id":"8b1267a0","title":"Sport TV 3 BR","embed":"https://streamtp4.com/global1.php?stream=sporttvbr3"},{"id":"1e0aa372","title":"Premiere 1 BR","embed":"https://streamtp4.com/global1.php?stream=premiere1"},{"id":"a82d65a4","title":"Premiere 2 BR","embed":"https://streamtp4.com/global1.php?stream=premiere2"},{"id":"44ffc4f7","title":"Premiere 3 BR","embed":"https://streamtp4.com/global1.php?stream=premiere3"},{"id":"4b16039e","title":"Premier Sports 1 Irlanda","embed":"https://streamtp4.com/global1.php?stream=premiersports1_irl"},{"id":"90370157","title":"Premier Sports 2 Irlanda","embed":"https://streamtp4.com/global1.php?stream=premiersports2_irl"},{"id":"3c74b7f7","title":"ESPN 1 NL","embed":"https://streamtp4.com/global1.php?stream=espn_nl1"},{"id":"48d1d1d4","title":"ESPN 2 NL","embed":"https://streamtp4.com/global1.php?stream=espn_nl2"},{"id":"61449024","title":"ESPN 3 NL","embed":"https://streamtp4.com/global1.php?stream=espn_nl3"},{"id":"c73a79ce","title":"Caliente TV","embed":"https://streamtp4.com/global1.php?stream=calientetvmx"},{"id":"4cddc03a","title":"TSN 1","embed":"https://streamtp4.com/global1.php?stream=tsn1"},{"id":"8a71646e","title":"TSN 2","embed":"https://streamtp4.com/global1.php?stream=tsn2"},{"id":"d45253bb","title":"TSN 3","embed":"https://streamtp4.com/global1.php?stream=tsn3"},{"id":"74e7131e","title":"TSN 4","embed":"https://streamtp4.com/global1.php?stream=tsn4"},{"id":"3f78b98f","title":"TSN 5","embed":"https://streamtp4.com/global1.php?stream=tsn5"},{"id":"7dbcf3f3","title":"Vamos ES","embed":"https://streamtp4.com/global1.php?stream=vamoses"},{"id":"5cbb0993","title":"USA Network","embed":"https://streamtp4.com/global1.php?stream=usa_network"},{"id":"77d5968e","title":"SporstNet EAST","embed":"https://streamtp4.com/global1.php?stream=sportnet_east"},{"id":"1ff8bbee","title":"SN360","embed":"https://streamtp4.com/global1.php?stream=sn360"},{"id":"87a5f069","title":"TyC Sports Internacional","embed":"https://streamtp4.com/global1.php?stream=tycinternacional"},{"id":"fe0e0a29","title":"Canal 5 MX","embed":"https://streamtp4.com/global1.php?stream=canal5mx"},{"id":"74e7b1eb","title":"TUDN MX","embed":"https://streamtp4.com/global1.php?stream=TUDNMX"},{"id":"82905dfa","title":"Sky Sports Main Event","embed":"https://streamtp4.com/global1.php?stream=skymain"},{"id":"664a8d36","title":"Sky Sports Premier League","embed":"https://streamtp4.com/global1.php?stream=skypremierleague"},{"id":"3ec1f466","title":"Sky Sports Football","embed":"https://streamtp4.com/global1.php?stream=skyfootball"},{"id":"66356b53","title":"Sky Sports Cricket","embed":"https://streamtp4.com/global1.php?stream=skycricket"},{"id":"16b5df29","title":"Sky Sports Golf","embed":"https://streamtp4.com/global1.php?stream=skygolf"},{"id":"d1b9db70","title":"Sky Sports F1","embed":"https://streamtp4.com/global1.php?stream=skyf1"},{"id":"c4961d95","title":"Sky Sports Tennis","embed":"https://streamtp4.com/global1.php?stream=skytennis"},{"id":"509b19af","title":"CBS Sports Golazo!","embed":"https://streamtp4.com/global1.php?stream=cbs_sportsnetwork"},{"id":"942362ef","title":"FUTV (EV)","embed":"https://streamtp4.com/global1.php?stream=futv"},{"id":"313f2579","title":"ESPN 1 BR","embed":"https://streamtp4.com/global1.php?stream=espn1br"},{"id":"7613974e","title":"ESPN 2 BR","embed":"https://streamtp4.com/global1.php?stream=espn2br"},{"id":"0be82a99","title":"ESPN 3 BR","embed":"https://streamtp4.com/global1.php?stream=espn3br"},{"id":"b41aeb5e","title":"ESPN 4 BR","embed":"https://streamtp4.com/global1.php?stream=espn4br"},{"id":"0341b0ef","title":"LaLiga Hypermotion","embed":"https://streamtp4.com/global1.php?stream=laligahypermotion"},{"id":"eaed8ebc","title":"Fox Deportes TUBI","embed":"https://streamtp4.com/global1.php?stream=tubitv1"}]';
        $live_Channel = json_decode($lvo, true);
    }
    if(!empty($live_Channel)) { cache_manager("tv_list", "write", array("exp" => time() + (86400 * 7), "data" => $live_Channel)); }
    return $live_Channel;
}

function spt_channel_detail($id)
{
    foreach(spt_channels() as $sop) {
        if($id == $sop['id']) {
            return $sop;
        }
    }
    return array();
}

function spt_channel_stream($id)
{
    global $APP_CONFIGS;
    $getCache = cache_manager("stream_".$id, "read", ""); if(!empty($getCache)) { return $getCache; }
    $output = ""; $playbackURL = "";
    $XembedDTL = spt_channel_detail($id);
    if(!isset($XembedDTL['embed']) || empty($XembedDTL['embed'])) {
        return "";
    }
    $url = $XembedDTL['embed'];
    $ambed = array("Referer: ".$APP_CONFIGS['BASE_API_URL'], "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36");
    $amFetch = GETRequest($url, $ambed);
    $html = $amFetch['data'];
    $x_aidn = ""; $xrm = "";
    if (stripos($html, 'playbackURL="",') !== false) {
        $arm = explode('playbackURL="",', $html);
        if (isset($arm[1])) {
            $brm = explode('=', $arm[1]);
            if (isset($brm[0]) && !empty($brm[0])) {
                $x_aidn = trim($brm[0]);
            }
        }
    }
    $tdf = $x_aidn."=[";
    $urm = explode($tdf, $html);
    if(isset($urm[2]))
    {
        $krm = explode("]];", $urm[2]);
        if(isset($krm[0]) && !empty($krm[0]))
        {
            $xrm = "[" . trim($krm[0]) . "]]";
        }
    }
    // Decode JSON and Throw Error
    $pp_array = json_decode($xrm, true);
    if (!is_array($pp_array)) {
        header("X-Stream-Error: Bad Json Received");
        http_response_code(400);
        exit();
    }
    // Sort Array By Ascending (Using First Element)
    usort($pp_array, function ($a, $b) { return $a[0] - $b[0]; });
    
    //============================================================================//
    //          E   X   T   R   A   C   T          K   E   Y
    //============================================================================//
    
    //First Key
    $firstKey = "";
    $frm = explode('var k=', $html);
    if(isset($frm[1])) { $grm = explode('+', $frm[1]); }
    if(isset($grm[0])) { $hrm = trim($grm[0]); }
    if(isset($hrm) && !empty($hrm)) { $irm = "function ".$hrm; }
    if(isset($irm)) { $jrm = explode($irm, $html); }
    if(isset($jrm[1])) { $wrm = explode('return', $jrm[1]); }
    if(isset($wrm[1])) { $orm = explode(';', $wrm[1]); }
    if(isset($orm[0]) && !empty($orm[0])) { $firstKey = trim($orm[0]); }
    
    //Second Key
    $secondKey = "";
    if(isset($frm[1])) { $aip = explode('+', $frm[1]); }
    if(isset($aip[1])) { $bip = explode(';', $aip[1]); }
    if(isset($bip[0])) { $cip = "function ".trim($bip[0]); }
    if(isset($cip)) { $dip = explode($cip, $html); }
    if(isset($dip[1])) { $eip = explode('return', $dip[1]); }
    if(isset($eip[1])) { $fip = explode(';', $eip[1]); }
    if(isset($fip[0]) && !empty($fip[0])) { $secondKey = trim($fip[0]); }
    
    $k = "";
    if(!empty($firstKey) && !empty($secondKey)) { $k = $k = $firstKey + $secondKey; }
    
    //============================================================================//
    //          D E C O D E     A N D       B U I L D       U R L
    //============================================================================//
    foreach ($pp_array as $item)
    {
        if (!isset($item[1])) continue;
        $decoded = base64_decode($item[1]);
        if ($decoded === false) continue;
        $numeric_value = preg_replace('/\D/', '', $decoded);
        if (!is_numeric($numeric_value)) continue;
        $char_code = intval($numeric_value) - $k;
        $playbackURL .= chr($char_code);
    }
    if(filter_var($playbackURL, FILTER_VALIDATE_URL)) {
        $output = $playbackURL;
        cache_manager("stream_".$id, "write", array("exp" => extractFlussonicTokenEXP($output), "data" => $output));
    }

    return $output;
}

?>