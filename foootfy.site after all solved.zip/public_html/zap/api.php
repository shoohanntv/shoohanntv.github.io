<?php

include("_engine.php");

$action = "";
if(isset($_REQUEST['action'])) {
    $action = trim($_REQUEST['action']);
}

//-------------------------------------------------------//

if($action == "get_channels")
{
    $mlist = array();
    foreach(spt_channels() as $chn)
    {
        if(!isset($chn['logo']) || empty($chn['logo'])) { $chn['logo'] = $APP_CONFIGS['DEFAULT_APP_LOGO']; }
        $mlist[] = array("id" => $chn['id'], "title" => $chn['title'], "logo" => $chn['logo']);
    }
    if(empty($mlist)) { apiResponse("error", 404, "No Data Found", ""); }
    apiResponse("success", 200, "All Channels List", array("count" => count($mlist), "list" => $mlist));
}
elseif($action == "search_channels")
{
    $mlist = array(); $query = "";
    if(isset($_REQUEST['query'])) { $query = trim(strip_tags($_REQUEST['query'])); }
    if(empty($query)) {
        apiResponse("error", 400, "Please Enter Channel Name to Search", "");
    }
    foreach(spt_channels() as $chn)
    {
        if(stripos($chn['title'], $query) !== false) {
            if(!isset($chn['logo']) || empty($chn['logo'])) { $chn['logo'] = $APP_CONFIGS['DEFAULT_APP_LOGO']; }
            $mlist[] = array("id" => $chn['id'], "title" => $chn['title'], "logo" => $chn['logo']);
        }      
    }
    if(empty($mlist)) { apiResponse("error", 404, "No Search Results Found", ""); }
    apiResponse("success", 200, "Total ".count($mlist)." Channels Found", array("query" => $query, "count" => count($mlist), "list" => $mlist));
}
elseif($action == "getIPTVPlaylist")
{
    $MPLine = "#EXTM3U\n";
    $vxn = 0;
    foreach(spt_channels() as $mtv)
    {
        $vxn++;
        $MPLine .= '#EXTINF:-1 tvg-id="'.$vxn.'" tvg-name="'.$mtv['title'].'" tvg-language="English" tvg-country="US" tvg-logo="'.$APP_CONFIGS['DEFAULT_APP_LOGO'].'" group-title="",'.$mtv['title']."\n";
        $MPLine .= $streamenvproto.'://'.$_SERVER['HTTP_HOST'].str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME'])."watch.php?id=".xor_encrypt($mtv['id'])."&format=.m3u8\n";
    }
    print(trim($MPLine));
    exit();
}
else
{
    apiResponse("error", 404, "No Module Found", "");
}

?>