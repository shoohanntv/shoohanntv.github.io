<?php include("_engine.php"); ?>
<!doctype html>
<html lang="en">
<head>
<title><?php print($APP_CONFIGS['APP_NAME']); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>" />
<link rel="shortcut icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
<style>
body
{
    font-family: "Montserrat", sans-serif;
    background-color: black;
}
#txtCSearch {
    border-top-left-radius: 24px;
    border-bottom-left-radius: 24px;
    padding-left: 28px;
}
#downloadPlaylistBtn {
    border-top-right-radius: 24px;
    border-bottom-right-radius: 24px;
}
.card {
    color: #FFFFFF;
    border-radius:2rem .3rem ;
    background-color: #202020 !important;
    text-align: center;
    justify-content: center;
    item-align: center;
    border:2px solid black;
}
.card:hover {
    background-color: rgba(165, 42, 42, 0.521);
	border-color:white;
	border:2px solid white;
}
.card:hover .card-text {
    color:white;
}
.card a {
    text-decoration: none;
    color: #FFFFFF;
}
.tvimage {
    border-radius: 12px;
    padding: 8px;
    background-color: #FFFFFF;
}
</style>
</head>
<body>
    
<div class="container">
    <!-- Logo Holder -->
        <div class="mt-5 mb-4"><img src="<?php print($APP_CONFIGS['APP_LOGO']); ?>" alt="" class="img-fluid" width="140" height="80" /></div>
    <!-- //Logo Holder -->
    <div class="mb-4">
        <div class="input-group">
        <input class="form-control" type="text" id="txtCSearch" placeholder="Search Channels Here ..." autocomplete="off" />
        <button class="btn btn-secondary" id="initCSearch"><i class="fa-solid fa-magnifying-glass"></i></button>
        <a href="api.php?action=getIPTVPlaylist" class="btn btn-dark" id="downloadPlaylistBtn" title="Click To Download IPTV M3U-Playlist"><i class="fa-solid fa-download"></i></a>
        </div>
    </div>
    <div class="tv_catalog">
        <div class="mt-5 px-3"><div class="spinner-border text-light" style="width: 3rem; height: 3rem;" role="status"><span class="visually-hidden">Loading...</span></div></div>
    </div>
</div>

<br/>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function(){ loadChannels(); });
function loadChannels()
{
    $.ajax({
        "url": "api.php",
        "type": "GET",
        "data": "action=get_channels",
        "success": function(data) {
            try { data = JSON.parse(data); }catch(error){}
            if(data.status == "success")
            {
                let utml = '';
                utml = utml + '<div class="row">';
                $.each(data.data.list, function(k,v)
                {   
                    utml += `<div class="col-6 col-sm-4 col-lg-3 col-xl-2" data-id="` + v.id + `" title="Watch ` + v.title + ` Live Stream" onclick="openPlayer(this)">`;
		            utml += `<a href="player.php?id=` + v.id + `" style="text-decoration: none;">`;
                    utml += `<div align="center" class="card mt-2" title="Watch - ` + v.title + `">`;
                    utml += `<div class="mt-2"><img src="` + v.logo + `" alt="` + v.title + `" onerror="this.src='https://i.ibb.co/V3rMvKz/000.png'" width="120" height="90" class="tvimage" /></div>`;
                    utml += `<div class="card-body">`;
                    utml += `<div style="user-select: none;"><b><small>` + v.title + `</small></b></div>`;
                    utml += `</div>`;
		            utml += `</div>`;
                    utml += `</a>`;
		            utml += `</div>`;
                });
                utml = utml + '</div>';
                $(".tv_catalog").html(utml);
            }
            else
            {
                if(data.status == "error")
                {
                    $(".tv_catalog").html('<div class="text-warning"><b>Error: ' + data.message + '</b></div>');
                }
                else
                {
                    $(".tv_catalog").html('<div class="text-warning"><b>SOMETHING WENT WRONG</b></div>');
                }
            }
        },
        "error": function(data) {
            $(".tv_catalog").html('<div class="text-warning"><b>NETWORK OR INTERNAL SERVER ERROR</b></div>');
        }
    });
}
function searchChannels()
{
    $("#initCSearch").html('<span class="spinner-border spinner-border-sm" aria-hidden="true"></span>');
    $.ajax({
        "url": "api.php",
        "type": "GET",
        "data": "action=search_channels&query=" + $("#txtCSearch").val(),
        "success": function(data)
        {
            $("#initCSearch").html('<i class="fa-solid fa-magnifying-glass"></i>');
            try { data = JSON.parse(data); }catch(error){}
            if(data.status == "success")
            {
                let utml = '';
                utml = utml + '<div class="row">';
                $.each(data.data.list, function(k,v){
                    utml += `<div class="col-6 col-sm-4 col-lg-3 col-xl-2" data-id="` + v.id + `" title="Watch ` + v.title + ` Live Stream" onclick="openPlayer(this)">`;
		            utml += `<a href="player.php?id=` + v.id + `" style="text-decoration: none;">`;
                    utml += `<div align="center" class="card mt-2" title="Watch - ` + v.title + `">`;
                    utml += `<div class="mt-2"><img src="` + v.logo + `" alt="` + v.title + `" onerror="this.src='https://i.ibb.co/V3rMvKz/000.png'" width="120" height="90" class="tvimage" /></div>`;
                    utml += `<div class="card-body">`;
                    utml += `<div style="user-select: none;"><b><small>` + v.title + `</small></b></div>`;
                    utml += `</div>`;
		            utml += `</div>`;
                    utml += `</a>`;
		            utml += `</div>`;
                });
                utml = utml + '</div>';
                $(".tv_catalog").html(utml);
            }
            else
            {
                loadChannels();
            }
        },
        "error": function(data) {
            loadChannels();
            $("#initCSearch").html('<i class="fa-solid fa-magnifying-glass"></i>');
        }
    });
}
$("#initCSearch").on("click", function(){
    searchChannels();
});
$("#txtCSearch").on('keypress', function(e) {
    if (e.which === 13 || e.key === 'Enter') { 
        e.preventDefault();
        searchChannels();
    }
});
$("#txtCSearch").on('input', function(e) {
    searchChannels();
});
</script>
</body>
</html>