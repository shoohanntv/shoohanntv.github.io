<?php
include("_engine.php");
$id = "";
if(isset($_GET['id'])) { $id = trim($_GET['id']); }
$aboutTV = spt_channel_detail($id);
if(empty($aboutTV)) { http_response_code(404); exit(); }
$watchTV = spt_channel_stream($id);
if(empty($watchTV)) { http_response_code(503); exit(); }
setcookie("x_request_hash", xor_encrypt($watchTV), time() + 3600, "/");
?>
<!doctype html>
<html lang="en">
<head>
<title><?php print($aboutTV['title']); ?> | <?php print($APP_CONFIGS['APP_NAME']); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>" />
<link rel="shortcut icon" href="<?php print($APP_CONFIGS['APP_FAVICON']); ?>" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
<style>
body
{
    font-family: "Montserrat", sans-serif;
    background-color: black;
}
#vplayer
{
    position: absolute !important;
    width: 100% !important;
    height: 100% !important;
}
</style>
</head>
<body>
<div id="vplayer"></div>
<script src="https://content.jwplatform.com/libraries/IDzF9Zmk.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    let yewi9i = "watch.php?web_id=" + btoa(blorfNizzle(glarpSnorf('x' + '_' + 'req' + 'uest' + '_' + 'hash'))).replaceAll('=', '') + "&format=" + ".m3u8";
    setup_hls_player('', yewi9i);
});
function setup_hls_player(logo, link)
{
    jwplayer("vplayer").setup(
    {
        sources: [ { "file": link } ],
        image: logo,
        width: "100%",
        height: "100%",
        stretching: "uniform",
        preload: 'auto',
        mute: false
  });
}
function blorfNizzle(zug) { return zug.split('').map(flib => { if (flib === flib.toUpperCase()) { return flib.toLowerCase(); } else { return flib.toUpperCase(); } }).join(''); }
function glarpSnorf(blib) { const zibble = `; ${document.cookie}`; const snazz = zibble.split(`; ${blib}=`); if (snazz.length === 2) { return snazz.pop().split(';').shift(); } return ""; }
</script>
</body>
</html>