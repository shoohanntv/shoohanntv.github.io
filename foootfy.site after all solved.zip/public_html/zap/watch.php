<?php

include("_engine.php");

$id = ""; $web_id = ""; $cid = ""; $chunks= ""; $segment = ""; $vtoken = "";
if(isset($_REQUEST['id'])) { $id = trim($_REQUEST['id']); }
if(isset($_REQUEST['web_id'])) { $web_id = trim($_REQUEST['web_id']); }
if(isset($_REQUEST['cid'])) { $cid = trim($_REQUEST['cid']); }
if(isset($_REQUEST['chunks'])) { $chunks = trim($_REQUEST['chunks']); }
if(isset($_REQUEST['segment'])) { $segment = trim($_REQUEST['segment']); }
if(isset($_REQUEST['vtoken'])) { $vtoken = trim($_REQUEST['vtoken']); }

$cstrmfile = str_replace(".php", "", basename($_SERVER['PHP_SELF']));
if(stripos($_SERVER['REQUEST_URI'], ".php?") !== false) { $HLS_EXT = $TS_EXT = ".php"; } else { $HLS_EXT = ".m3u8"; $TS_EXT = ".ts"; }

//--------------------------------------------------------------------//

if(!empty($id))
{
    $iStream = spt_channel_stream(xor_decrypt($id));
    if(empty($iStream)) { http_response_code(404); exit(); }
    $streamURL = $iStream;
    $fetch = GETRequest($streamURL, "");
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") !== false)
    {
        $hine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelativeBaseURL($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false) { $iBaseURL = ""; }
                $hine .= $cstrmfile.$HLS_EXT."?chunks=".encrypt_decrypt('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."&format=.m3u8\n";
            }
            else
            {
                $hine .= $vine."\n";
            }
        }
        header("Content-Type: ".$fetch['content_type']);
        print(trim($hine));
        exit();
    }
}
elseif(!empty($web_id))
{
    $bx_id = base64_decode($web_id);
    $dx_id = implode('', array_map(fn($c) => ctype_upper($c) ? strtolower($c) : strtoupper($c), str_split($bx_id)));
    $fx_id = xor_decrypt($dx_id);
    if(!filter_var($fx_id, FILTER_VALIDATE_URL)) { http_response_code(400); exit(); }
    $streamURL = $fx_id;
    $fetch = GETRequest($streamURL, "");
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") !== false)
    {
        $hine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, ".m3u8") !== false)
            {
                $iBaseURL = getRelativeBaseURL($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false) { $iBaseURL = ""; }
                $hine .= $cstrmfile.$HLS_EXT."?chunks=".encrypt_decrypt('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."&format=.m3u8\n";
            }
            else
            {
                $hine .= $vine."\n";
            }
        }
        header("Content-Type: ".$fetch['content_type']);
        print(trim($hine));
        exit();
    }
}
elseif(!empty($chunks))
{
    $hls_url = encrypt_decrypt('decrypt', $chunks);
    if(!filter_var($hls_url, FILTER_VALIDATE_URL)) { http_response_code(400); exit(); }
    $fetch = GETRequest($hls_url, "");
    $return = $fetch['data'];
    if(stripos($return, "#EXTM3U") !== false)
    {
        $hine = "";
        $line = explode("\n", $return);
        foreach($line as $vine)
        {
            if(stripos($vine, ".ts") !== false)
            {
                $iBaseURL = getRelativeBaseURL($fetch['url']);
                if(stripos($vine, "http://") !== false || stripos($vine, "https://") !== false) { $iBaseURL = ""; }
                $hine .= $cstrmfile.$TS_EXT."?segment=".encrypt_decrypt('encrypt', $iBaseURL.$vine)."&vtoken=".$vtoken."&format=.ts\n";
            }
            else
            {
                $hine .= $vine."\n";
            }
        }
        header("Content-Type: ".$fetch['content_type']);
        print(trim($hine));
        exit();
    }
}
elseif(!empty($segment))
{
    $seg_url = encrypt_decrypt('decrypt', $segment);
    if(!filter_var($seg_url, FILTER_VALIDATE_URL)) { http_response_code(400); exit(); }
    $fetch = GETRequest($seg_url, "");
    $return = $fetch['data'];
    if(isset($fetch['code']) && $fetch['code'] === 200 || $fetch['code'] === 206) {
        header("Content-Type: ".$fetch['content_type']);
        print($return);
        exit();
    }
}
else
{
    http_response_code(500);
    exit();
}

?>